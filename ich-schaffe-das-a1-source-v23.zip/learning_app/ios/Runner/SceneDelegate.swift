import Flutter
import UIKit

class SceneDelegate: FlutterSceneDelegate, UIGestureRecognizerDelegate {
  private var shortSwipeChannel: FlutterMethodChannel?
  private var shortPan: UIPanGestureRecognizer?

  override func scene(
    _ scene: UIScene,
    willConnectTo session: UISceneSession,
    options connectionOptions: UIScene.ConnectionOptions
  ) {
    super.scene(scene, willConnectTo: session, options: connectionOptions)
    installShortSwipeBridge()
  }

  override func sceneDidBecomeActive(_ scene: UIScene) {
    super.sceneDidBecomeActive(scene)
    installShortSwipeBridge()
  }

  private func installShortSwipeBridge() {
    guard shortSwipeChannel == nil,
          let window = window,
          let controller = window.rootViewController as? FlutterViewController else {
      return
    }

    let channel = FlutterMethodChannel(
      name: "de.ichschaffedas.a1/short_swipe",
      binaryMessenger: controller.binaryMessenger
    )
    shortSwipeChannel = channel
    channel.setMethodCallHandler { [weak self] call, result in
      guard call.method == "setEnabled", let enabled = call.arguments as? Bool else {
        result(FlutterMethodNotImplemented)
        return
      }
      self?.shortPan?.isEnabled = enabled
      result(nil)
    }

    let pan = UIPanGestureRecognizer(target: self, action: #selector(handleShortPan(_:)))
    pan.cancelsTouchesInView = false
    pan.delaysTouchesBegan = false
    pan.delegate = self
    pan.isEnabled = false
    window.addGestureRecognizer(pan)
    shortPan = pan
  }

  @objc private func handleShortPan(_ recognizer: UIPanGestureRecognizer) {
    guard recognizer.state == .ended, let view = recognizer.view else { return }
    let movement = recognizer.translation(in: view)
    guard abs(movement.y) >= 55, abs(movement.y) > abs(movement.x) else { return }
    shortSwipeChannel?.invokeMethod("shortSwipe", arguments: movement.y < 0 ? 1 : -1)
  }

  func gestureRecognizer(
    _ gestureRecognizer: UIGestureRecognizer,
    shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer
  ) -> Bool {
    true
  }
}
