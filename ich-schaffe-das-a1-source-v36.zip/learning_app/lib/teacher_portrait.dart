import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TeacherPortraitSpec {
  const TeacherPortraitSpec({
    required this.id,
    required this.asset,
    required this.mouthX,
    required this.mouthY,
    required this.mouthWidth,
  });

  final String id;
  final String asset;
  final double mouthX;
  final double mouthY;
  final double mouthWidth;

  factory TeacherPortraitSpec.fromJson(Map<String, dynamic> json) {
    double fraction(String key, double fallback) =>
        ((json[key] as num?)?.toDouble() ?? fallback).clamp(0.0, 1.0);
    return TeacherPortraitSpec(
      id: json['id'] as String,
      asset: json['asset'] as String,
      mouthX: fraction('mouth_x', 0.5),
      mouthY: fraction('mouth_y', 0.7),
      mouthWidth: fraction('mouth_width', 0.16),
    );
  }
}

class TeacherPortraitStore {
  static Future<TeacherPortraitStore>? _cache;

  TeacherPortraitStore._(
    this._portraits,
    this._assignments,
    this._cycle,
    this._defaultId,
  );

  final Map<String, TeacherPortraitSpec> _portraits;
  final Map<String, String> _assignments;
  final List<String> _cycle;
  final String? _defaultId;

  static Future<TeacherPortraitStore> load() => _cache ??= _read();

  static Future<TeacherPortraitStore> _read() async {
    final json = jsonDecode(
      await rootBundle.loadString('assets/teacher_portraits.json'),
    ) as Map<String, dynamic>;
    final portraits = <String, TeacherPortraitSpec>{};
    for (final raw in json['portraits'] as List<dynamic>) {
      final spec = TeacherPortraitSpec.fromJson(raw as Map<String, dynamic>);
      if (spec.asset.startsWith('assets/teacher_portraits/')) {
        portraits[spec.id] = spec;
      }
    }
    return TeacherPortraitStore._(
      portraits,
      (json['assignments'] as Map<String, dynamic>).map(
        (key, value) => MapEntry(key, value as String),
      ),
      (json['cycle'] as List<dynamic>).cast<String>(),
      json['default_portrait'] as String?,
    );
  }

  TeacherPortraitSpec? forCard(String slug, int index) {
    final id =
        _assignments[slug] ??
        (_cycle.isEmpty ? _defaultId : _cycle[index % _cycle.length]);
    return _portraits[id];
  }
}

class MouthRegion {
  const MouthRegion(this.x, this.y, this.width);
  final double x;
  final double y;
  final double width;

  /// Vision reports coordinates in the uncropped image; BoxFit.cover crops it.
  static MouthRegion forSquare(Map<dynamic, dynamic> data) {
    final sourceWidth = (data['imageWidth'] as num).toDouble();
    final sourceHeight = (data['imageHeight'] as num).toDouble();
    final x = (data['x'] as num).toDouble();
    final y = (data['y'] as num).toDouble();
    final width = (data['width'] as num).toDouble();
    if (sourceHeight > sourceWidth) {
      final scale = sourceHeight / sourceWidth;
      return MouthRegion(x, y * scale - (scale - 1) / 2, width);
    }
    final scale = sourceWidth / sourceHeight;
    return MouthRegion(x * scale - (scale - 1) / 2, y, width * scale);
  }
}

class TeacherPortrait extends StatefulWidget {
  const TeacherPortrait({
    super.key,
    required this.spec,
    required this.speaking,
    required this.mouthOpen,
  });

  final TeacherPortraitSpec spec;
  final bool speaking;
  final double mouthOpen;

  @override
  State<TeacherPortrait> createState() => _TeacherPortraitState();
}

class _TeacherPortraitState extends State<TeacherPortrait> {
  static const _landmarks = MethodChannel('de.ichschaffedas.a1/face_landmarks');
  static final Map<String, Future<MouthRegion?>> _cache = {};
  MouthRegion? _mouth;

  @override
  void initState() {
    super.initState();
    _findMouth();
  }

  @override
  void didUpdateWidget(covariant TeacherPortrait oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.spec.asset != widget.spec.asset) _findMouth();
  }

  Future<void> _findMouth() async {
    final asset = widget.spec.asset;
    final result = await _cache.putIfAbsent(asset, () async {
      try {
        final bytes = await rootBundle.load(asset);
        final result = await _landmarks.invokeMapMethod<String, dynamic>(
          'detectMouth',
          bytes.buffer.asUint8List(),
        );
        return result == null ? null : MouthRegion.forSquare(result);
      } catch (_) {
        return null;
      }
    });
    if (mounted && widget.spec.asset == asset) setState(() => _mouth = result);
  }

  @override
  Widget build(BuildContext context) {
    final mouth =
        _mouth ??
        MouthRegion(
          widget.spec.mouthX,
          widget.spec.mouthY,
          widget.spec.mouthWidth,
        );
    return Semantics(
      label: widget.speaking ? 'Teacher speaking' : 'Teacher portrait',
      child: AspectRatio(
        aspectRatio: 1,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(widget.spec.asset, fit: BoxFit.cover),
              if (widget.speaking && widget.mouthOpen > 0.04)
                CustomPaint(painter: _MouthPainter(mouth, widget.mouthOpen)),
            ],
          ),
        ),
      ),
    );
  }
}

class _MouthPainter extends CustomPainter {
  const _MouthPainter(this.mouth, this.openness);
  final MouthRegion mouth;
  final double openness;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * mouth.x, size.height * mouth.y);
    final width = size.width * mouth.width.clamp(0.06, 0.3);
    final height = math.max(2.0, width * (0.08 + 0.52 * openness));
    final opening = Rect.fromCenter(
      center: center,
      width: width,
      height: height,
    );
    canvas.drawOval(opening, Paint()..color = const Color(0xFF331A24));
    final lip = Paint()
      ..color = const Color(0xFFAF646A).withValues(alpha: 0.82)
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.0, width * 0.065);
    canvas.drawArc(opening, math.pi, math.pi, false, lip);
    canvas.drawArc(opening, 0, math.pi, false, lip);
    if (openness > 0.5) {
      canvas.drawOval(
        Rect.fromCenter(
          center: center.translate(0, height * 0.22),
          width: width * 0.56,
          height: height * 0.2,
        ),
        Paint()..color = const Color(0xFFE3B3AC),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _MouthPainter oldDelegate) =>
      mouth != oldDelegate.mouth || openness != oldDelegate.openness;
}
