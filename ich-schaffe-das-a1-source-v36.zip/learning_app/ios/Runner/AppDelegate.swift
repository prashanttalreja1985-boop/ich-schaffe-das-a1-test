import Flutter
import UIKit
import Vision
import AVFoundation

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {
  private var speechService: TeacherSpeechService?

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)
    let messenger = engineBridge.applicationRegistrar.messenger()
    let faceChannel = FlutterMethodChannel(
      name: "de.ichschaffedas.a1/face_landmarks", binaryMessenger: messenger)
    faceChannel.setMethodCallHandler { call, result in
      guard call.method == "detectMouth",
            let bytes = (call.arguments as? FlutterStandardTypedData)?.data else {
        result(FlutterMethodNotImplemented)
        return
      }
      DispatchQueue.global(qos: .userInitiated).async {
        let mouth = Self.detectMouth(in: bytes)
        DispatchQueue.main.async { result(mouth) }
      }
    }
    let voiceChannel = FlutterMethodChannel(
      name: "de.ichschaffedas.a1/teacher_voice", binaryMessenger: messenger)
    let service = TeacherSpeechService(channel: voiceChannel)
    speechService = service
    voiceChannel.setMethodCallHandler { call, result in
      switch call.method {
      case "speak":
        service.speak(call.arguments as? String ?? "")
        result(nil)
      case "stop":
        service.stop()
        result(nil)
      default:
        result(FlutterMethodNotImplemented)
      }
    }
  }

  private static func detectMouth(in data: Data) -> [String: Double]? {
    guard let image = UIImage(data: data), let cgImage = image.cgImage else { return nil }
    let request = VNDetectFaceLandmarksRequest()
    do {
      try VNImageRequestHandler(cgImage: cgImage, options: [:]).perform([request])
    } catch { return nil }
    guard let face = request.results?.max(by: {
      $0.boundingBox.width * $0.boundingBox.height <
        $1.boundingBox.width * $1.boundingBox.height
    }), let lips = face.landmarks?.outerLips else { return nil }
    let points = lips.normalizedPoints
    guard !points.isEmpty else { return nil }
    let left = points.map(\.x).min() ?? 0
    let right = points.map(\.x).max() ?? 0
    let bottom = points.map(\.y).min() ?? 0
    let top = points.map(\.y).max() ?? 0
    let box = face.boundingBox
    return [
      "x": Double(box.minX + box.width * (left + right) / 2),
      "y": Double(1 - (box.minY + box.height * (bottom + top) / 2)),
      "width": Double(box.width * (right - left)),
      "imageWidth": Double(cgImage.width),
      "imageHeight": Double(cgImage.height)
    ]
  }
}

private final class TeacherSpeechService: NSObject, AVSpeechSynthesizerDelegate {
  private let synthesizer = AVSpeechSynthesizer()
  private let channel: FlutterMethodChannel

  init(channel: FlutterMethodChannel) {
    self.channel = channel
    super.init()
    synthesizer.delegate = self
  }

  func speak(_ text: String) {
    synthesizer.stopSpeaking(at: .immediate)
    guard !text.isEmpty else {
      channel.invokeMethod("finished", arguments: nil)
      return
    }
    try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
    try? AVAudioSession.sharedInstance().setActive(true)
    let utterance = AVSpeechUtterance(string: text)
    utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
    utterance.rate = 0.52
    synthesizer.speak(utterance)
  }

  func stop() {
    synthesizer.stopSpeaking(at: .immediate)
  }

  func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer,
                         willSpeakRangeOfSpeechString characterRange: NSRange,
                         utterance: AVSpeechUtterance) {
    channel.invokeMethod("word", arguments: nil)
  }

  func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer,
                         didFinish utterance: AVSpeechUtterance) {
    channel.invokeMethod("finished", arguments: nil)
  }

  func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer,
                         didCancel utterance: AVSpeechUtterance) {
    channel.invokeMethod("finished", arguments: nil)
  }
}
