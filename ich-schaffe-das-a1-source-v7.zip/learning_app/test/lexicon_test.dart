import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/lexicon.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('A1 and A1+ have separate noun and verb lexicons with clickable forms',
      () async {
    final data = jsonDecode(await rootBundle.loadString('assets/lexicon.json'))
        as Map<String, dynamic>;
    final a1 = Lexicon.fromJson(data, 'original-a1-starter');
    final a1Plus = Lexicon.fromJson(data, 'ich-schaffe-das-a1-plus');

    expect(a1.entries.where((entry) => entry.type == 'noun').length,
        greaterThan(200));
    expect(a1.entries.where((entry) => entry.type == 'verb').length,
        greaterThan(100));
    expect(a1Plus.entries.where((entry) => entry.type == 'noun').length,
        greaterThan(100));
    expect(a1Plus.entries.where((entry) => entry.type == 'verb').length,
        greaterThan(100));

    expect(a1.find('der Name')?.meaning, isNotEmpty);
    expect(a1.find('bin')?.lemma, 'sein');
    expect(a1.find('wohne')?.lemma, 'wohnen');
    expect(a1Plus.find('der Arm')?.meaning, 'arm');
    expect(a1Plus.find('die Hand')?.meaning, 'hand');
    expect(a1.find('die Hand')?.article, 'die');
  });

  test('longest complete noun form is matched before shorter forms', () async {
    final data = jsonDecode(await rootBundle.loadString('assets/lexicon.json'))
        as Map<String, dynamic>;
    final lexicon = Lexicon.fromJson(data, 'original-a1-starter');

    final parts = lexicon.split('Ich kaufe den Apfel heute.');
    final linked = parts.where((part) => part.lexeme != null).toList();
    expect(linked.map((part) => part.text), contains('den Apfel'));
    expect(
        linked.firstWhere((part) => part.text == 'den Apfel').lexeme?.lemma,
        'Apfel');
  });
}
