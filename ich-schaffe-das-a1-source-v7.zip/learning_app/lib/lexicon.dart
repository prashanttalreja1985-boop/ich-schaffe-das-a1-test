import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';

class Lexeme {
  const Lexeme({
    required this.bookSlug,
    required this.lemma,
    required this.type,
    required this.meaning,
    required this.forms,
    this.article,
  });

  final String bookSlug;
  final String lemma;
  final String type;
  final String meaning;
  final String? article;
  final List<String> forms;

  String get key => '$bookSlug:$type:$lemma';

  factory Lexeme.fromJson(Map<String, dynamic> json) => Lexeme(
        bookSlug: json['book_slug'] as String,
        lemma: json['lemma'] as String,
        type: json['word_type'] as String,
        meaning: json['meaning_en'] as String,
        article: json['article'] as String?,
        forms: (json['forms'] as List<dynamic>).cast<String>(),
      );
}

class Lexicon {
  Lexicon(Iterable<Lexeme> entries)
      : entries = List.unmodifiable(entries) {
    final byForm = <String, Lexeme>{};
    for (final entry in this.entries) {
      for (final form in entry.forms) {
        final key = _normalize(form);
        final previous = byForm[key];
        if (previous == null ||
            (entry.type == 'noun' && entry.article != null &&
                previous.article == null)) {
          byForm[key] = entry;
        }
      }
    }
    _byForm = byForm;
    final forms = byForm.keys.toList()
      ..sort((a, b) => b.length.compareTo(a.length));
    _pattern = forms.isEmpty
        ? null
        : RegExp(
            r'(?<![A-Za-zÄÖÜäöüß])(?:' +
                forms.map(RegExp.escape).join('|') +
                r')(?![A-Za-zÄÖÜäöüß])',
            caseSensitive: false,
          );
  }

  final List<Lexeme> entries;
  late final Map<String, Lexeme> _byForm;
  late final RegExp? _pattern;

  factory Lexicon.fromJson(Map<String, dynamic> json, String bookSlug) =>
      Lexicon((json['entries'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .where((entry) => entry['book_slug'] == bookSlug)
          .map(Lexeme.fromJson));

  Lexeme? find(String text) => _byForm[_normalize(text)];

  List<LexicalPart> split(String text) {
    final pattern = _pattern;
    if (pattern == null) return [LexicalPart(text, null)];
    final parts = <LexicalPart>[];
    var cursor = 0;
    for (final match in pattern.allMatches(text)) {
      if (match.start > cursor) {
        parts.add(LexicalPart(text.substring(cursor, match.start), null));
      }
      final visible = text.substring(match.start, match.end);
      final lexeme = _byForm[_normalize(visible)];
      parts.add(LexicalPart(visible, lexeme));
      cursor = match.end;
    }
    if (cursor < text.length) parts.add(LexicalPart(text.substring(cursor), null));
    return parts.isEmpty ? [LexicalPart(text, null)] : parts;
  }

  static String _normalize(String value) =>
      value.toLowerCase().trim();
}

class LexicalPart {
  const LexicalPart(this.text, this.lexeme);
  final String text;
  final Lexeme? lexeme;
}

class LexicalText extends StatefulWidget {
  const LexicalText(
    this.text, {
    required this.lexicon,
    this.style,
    this.textAlign,
    this.maxLines,
    this.overflow,
  });

  final String text;
  final Lexicon lexicon;
  final TextStyle? style;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;

  @override
  State<LexicalText> createState() => _LexicalTextState();
}

class _LexicalTextState extends State<LexicalText> {
  final Map<String, TapGestureRecognizer> _recognizers = {};

  @override
  void didUpdateWidget(covariant LexicalText oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.lexicon != widget.lexicon) _disposeRecognizers();
  }

  void _disposeRecognizers() {
    for (final recognizer in _recognizers.values) {
      recognizer.dispose();
    }
    _recognizers.clear();
  }

  TapGestureRecognizer _recognizer(Lexeme lexeme) =>
      _recognizers.putIfAbsent(lexeme.key, () {
        return TapGestureRecognizer()
          ..onTap = () => _showMeaning(lexeme);
      });

  void _showMeaning(Lexeme lexeme) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(lexeme.type == 'noun' && lexeme.article != null
            ? '${lexeme.article} ${lexeme.lemma}'
            : lexeme.lemma),
        content: Text(lexeme.meaning),
        actions: [TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Close'),
        )],
      ),
    );
  }

  @override
  void dispose() {
    _disposeRecognizers();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = widget.style ?? DefaultTextStyle.of(context).style;
    final spans = widget.lexicon.split(widget.text).map((part) {
      final lexeme = part.lexeme;
      if (lexeme == null) return TextSpan(text: part.text);
      final isNoun = lexeme.type == 'noun';
      return TextSpan(
        text: part.text,
        recognizer: _recognizer(lexeme),
        style: TextStyle(
          color: isNoun ? const Color(0xFFF5C85B) : const Color(0xFF70D6AB),
          fontWeight: isNoun ? FontWeight.w700 : FontWeight.bold,
          decoration: TextDecoration.underline,
          decorationColor: (isNoun
                  ? const Color(0xFFF5C85B)
                  : const Color(0xFF70D6AB))
              .withValues(alpha: 0.35),
        ),
      );
    }).toList();
    return RichText(
      text: TextSpan(style: base, children: spans),
      textAlign: widget.textAlign ?? TextAlign.start,
      maxLines: widget.maxLines,
      overflow: widget.overflow ?? TextOverflow.clip,
    );
  }
}
