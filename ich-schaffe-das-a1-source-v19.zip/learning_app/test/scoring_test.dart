import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('every quiz tap is saved as a distinct, ordered attempt', () async {
    SharedPreferences.setMockInitialValues({});
    final activity = Activity(
      slug: 'test-quiz', kind: 'quiz', title: 'Test', lessonTitle: 'One',
      lessonNumber: 1, cardNumber: 1, lessonCardCount: 1,
      payload: {'answer': 1},
    );
    final curriculum = Curriculum('A1', 'test', 'original-a1-starter',
        [activity]);
    final store = LearningStore('', curriculum.slug, 'alice');

    expect(await store.recordAnswer(curriculum, activity, 0), isFalse);
    expect(await store.recordAnswer(curriculum, activity, 1), isFalse);

    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList(
        'answers:alice:original-a1-starter')!.map((row) =>
        jsonDecode(row) as Map<String, dynamic>).toList();
    expect(saved, hasLength(2));
    expect(saved.map((row) => row['is_correct']), [false, true]);
    expect(saved[0]['attempt_key'], isNot(saved[1]['attempt_key']));
  });
}
