import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/lines_game.dart';
import 'package:ich_schaffe_das/mini_games.dart';

void main() {
  test('both games have twenty progressively denser levels', () {
    final planks = plankLevels();
    final lines = LinesLevel.all();
    expect(planks, hasLength(20));
    expect(lines, hasLength(20));
    expect(planks.first.pieces.where((piece) => !piece.target), hasLength(1));
    expect(planks.last.pieces.length, greaterThan(planks.first.pieces.length));
    expect(lines.last.points.length, greaterThan(lines.first.points.length));
  });

  test('every Lines level has a winning starting point', () {
    for (final level in LinesLevel.all()) {
      var hasWinningPoint = false;
      for (var point = 0; point < level.points.length; point++) {
        final game = LinesGameState(level);
        if (!game.start(point)) continue;
        while (game.advance()) {}
        if (game.outcome == LinesOutcome.won) {
          hasWinningPoint = true;
          break;
        }
      }
      expect(hasWinningPoint, isTrue, reason: 'Lines level ${level.number}');
    }
  });

  testWidgets('plank drag stays in the game; outside swipe changes card',
      (tester) async {
    var nextCards = 0;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: SizedBox(
      width: 390, height: 780,
      child: GameBreakCard(kind: MiniGameKind.planks, startLevel: 1,
        onLevelCompleted: (_) {},
        onPreviousCard: () {},
        onNextCard: () => nextCards++),
    ))));
    final piece = find.byKey(const ValueKey('plank-block-0'));
    final before = tester.getTopLeft(piece);
    await tester.drag(piece, const Offset(0, 85));
    await tester.pump();
    expect(nextCards, 0);
    expect(tester.getTopLeft(piece).dy, greaterThan(before.dy));

    await tester.drag(find.text('WOODEN ESCAPE'), const Offset(0, -90));
    await tester.pump();
    expect(nextCards, 1);
  });
}
