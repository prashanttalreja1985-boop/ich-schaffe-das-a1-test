import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('reset clears only the selected profile progress and preserves settings', () async {
    SharedPreferences.setMockInitialValues({
      'done:alice:original-a1-starter': ['a1-card-1'],
      'done:alice:ich-schaffe-das-a1-plus': ['plus-card-1'],
      'answers:alice:original-a1-starter': ['quiz-answer'],
      'game-level:alice:planks': 7,
      'game-level:alice:territory': 4,
      'game-level:alice:lines': 3,
      'done:bob:original-a1-starter': ['bob-card-1'],
      'reels:alice': true,
      'keywords:alice': 'travel, cooking',
      'legacy_progress_owner': 'alice',
      'done:original-a1-starter': ['old-card'],
    });
    final store = LearningStore('', 'original-a1-starter', 'alice');

    final synced = await store.resetProfileProgress();

    final prefs = await SharedPreferences.getInstance();
    expect(synced, isFalse);
    expect(prefs.getStringList('done:alice:original-a1-starter'), isNull);
    expect(prefs.getStringList('done:alice:ich-schaffe-das-a1-plus'), isNull);
    expect(prefs.getStringList('answers:alice:original-a1-starter'), isNull);
    expect(prefs.getInt('game-level:alice:planks'), isNull);
    expect(prefs.getInt('game-level:alice:territory'), isNull);
    expect(prefs.getInt('game-level:alice:lines'), isNull);
    expect(prefs.getStringList('done:bob:original-a1-starter'), ['bob-card-1']);
    expect(prefs.getBool('reels:alice'), isTrue);
    expect(prefs.getString('keywords:alice'), 'travel, cooking');
    expect(prefs.getStringList('done:original-a1-starter'), isNull);
    expect(prefs.getBool('reset-pending:alice'), isTrue);
  });
}
