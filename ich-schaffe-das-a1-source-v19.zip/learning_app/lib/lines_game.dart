import 'dart:collection';
import 'dart:math';

import 'package:flutter/painting.dart';

/// A sampled, connected drawing. Each point represents an equal piece of line.
class LinesLevel {
  const LinesLevel(this.number, this.points, this.neighbors, this.opponentSeeds);

  final int number;
  final List<Offset> points;
  final List<List<int>> neighbors;
  final List<int> opponentSeeds;

  static List<LinesLevel> all() => List.generate(20, (index) {
    final random = Random(509 + index * 97);
    final columns = 4 + index ~/ 5;
    final rows = 3 + index ~/ 7;
    final points = <Offset>[];
    final neighbors = <List<int>>[];
    int add(Offset point) {
      points.add(point);
      neighbors.add([]);
      return points.length - 1;
    }
    void join(int a, int b) {
      if (!neighbors[a].contains(b)) neighbors[a].add(b);
      if (!neighbors[b].contains(a)) neighbors[b].add(a);
    }

    final nodes = List.generate(rows, (row) => List.generate(columns, (col) {
      final x = .09 + .82 * col / (columns - 1) + (random.nextDouble() - .5) * .055;
      final y = .12 + .76 * row / (rows - 1) + (random.nextDouble() - .5) * .085;
      return add(Offset(x, y));
    }));

    void curve(int from, int to) {
      final a = points[from];
      final b = points[to];
      final middle = (a + b) / 2;
      final bend = (random.nextDouble() - .5) * .075;
      final control = Offset(middle.dx + (b.dy - a.dy) * bend,
          middle.dy - (b.dx - a.dx) * bend);
      var last = from;
      for (var step = 1; step < 10; step++) {
        final t = step / 10;
        final point = a * pow(1 - t, 2).toDouble() +
            control * (2 * t * (1 - t)) + b * pow(t, 2).toDouble();
        final next = add(point);
        join(last, next);
        last = next;
      }
      join(last, to);
    }

    for (var row = 0; row < rows; row++) {
      for (var col = 0; col < columns - 1; col++) {
        curve(nodes[row][col], nodes[row][col + 1]);
      }
    }
    for (var col = 0; col < columns; col++) {
      for (var row = 0; row < rows - 1; row++) {
        if ((row + col + index) % 3 != 0 || row == 0) {
          curve(nodes[row][col], nodes[row + 1][col]);
        }
      }
    }
    final opponentSeeds = <int>[
      nodes[rows - 1][columns - 1],
      if (index >= 7) nodes[0][columns - 1],
      if (index >= 15) nodes[rows - 1][columns ~/ 2],
    ];
    return LinesLevel(index + 1, points, neighbors, opponentSeeds);
  });
}

enum LinesOutcome { waiting, racing, won, lost }

class LinesGameState {
  LinesGameState(this.level) : owners = List.filled(level.points.length, 0);

  final LinesLevel level;
  final List<int> owners;
  LinesOutcome outcome = LinesOutcome.waiting;
  int? playerSeed;
  int tick = 0;
  late List<int> _playerDistances;
  late List<int> _opponentDistances;

  int get playerCount => owners.where((owner) => owner == 1).length;
  int get opponentCount => owners.where((owner) => owner == 2).length;
  int get majority => owners.length ~/ 2 + 1;

  int? nearest(Offset position, {double tolerance = .09}) {
    int? closest;
    var distance = tolerance;
    for (var i = 0; i < level.points.length; i++) {
      final candidate = (level.points[i] - position).distance;
      if (candidate < distance) {
        distance = candidate;
        closest = i;
      }
    }
    return closest;
  }

  bool start(int point) {
    if (outcome != LinesOutcome.waiting || point < 0 ||
        point >= owners.length || level.opponentSeeds.contains(point)) {
      return false;
    }
    playerSeed = point;
    _playerDistances = _distances([point]);
    _opponentDistances = _distances(level.opponentSeeds);
    outcome = LinesOutcome.racing;
    advance();
    return true;
  }

  bool advance() {
    if (outcome != LinesOutcome.racing) return false;
    for (var i = 0; i < owners.length; i++) {
      if (owners[i] != 0) continue;
      final player = _playerDistances[i];
      final opponent = _opponentDistances[i];
      final arrival = min(player, opponent);
      if (arrival <= tick) owners[i] = player < opponent ? 1 : 2;
    }
    tick++;
    if (!owners.contains(0)) {
      outcome = playerCount >= majority ? LinesOutcome.won : LinesOutcome.lost;
      return false;
    }
    return true;
  }

  List<int> _distances(List<int> seeds) {
    final result = List.filled(owners.length, 1 << 20);
    final queue = Queue<int>();
    for (final seed in seeds) {
      result[seed] = 0;
      queue.add(seed);
    }
    while (queue.isNotEmpty) {
      final current = queue.removeFirst();
      for (final next in level.neighbors[current]) {
        if (result[next] > result[current] + 1) {
          result[next] = result[current] + 1;
          queue.add(next);
        }
      }
    }
    return result;
  }
}
