import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'lines_game.dart';

enum MiniGameKind { planks, lines }

extension MiniGameKindLabel on MiniGameKind {
  String get title => this == MiniGameKind.planks
      ? 'Wooden escape'
      : 'Lines';
  String get subtitle => this == MiniGameKind.planks
      ? 'Clear a path and slide the marked plank out.'
      : 'Place a teal dot. Win more than half the drawing.';
  IconData get icon => this == MiniGameKind.planks
      ? Icons.view_module_rounded
      : Icons.timeline_rounded;
}

class PlankPiece {
  const PlankPiece({required this.id, required this.row, required this.column,
    required this.length, required this.horizontal, this.target = false});
  final String id;
  final int row;
  final int column;
  final int length;
  final bool horizontal;
  final bool target;

  PlankPiece moveTo(int nextRow, int nextColumn) => PlankPiece(
        id: id,
        row: nextRow,
        column: nextColumn,
        length: length,
        horizontal: horizontal,
        target: target,
      );
}

class PlankLevel {
  const PlankLevel(this.number, this.pieces);
  final int number;
  final List<PlankPiece> pieces;
}

/// Twenty layouts add blockers through level eight, then add decoys and vary
/// the exit lane to keep the later boards crowded without overlapping planks.
List<PlankLevel> plankLevels() => List.generate(20, (index) {
      final number = index + 1;
      final targetRow = 1 + (index % 4);
      final blockers = min(8, 1 + index);
      final pieces = <PlankPiece>[
        PlankPiece(id: 'target', row: targetRow, column: 0,
            length: 2, horizontal: true, target: true),
      ];
      final occupied = <String>{'$targetRow:0', '$targetRow:1'};
      for (var obstacle = 0; obstacle < blockers; obstacle++) {
        final column = 2 + obstacle % 4;
        final candidateRows = <int>[
          targetRow - 1,
          targetRow + 1,
          0,
          2,
          4,
          1,
          3,
        ];
        final row = candidateRows.firstWhere((candidate) =>
            candidate >= 0 && candidate + 1 < 6 &&
            !occupied.contains('$candidate:$column') &&
            !occupied.contains('${candidate + 1}:$column'));
        pieces.add(PlankPiece(id: 'block-$obstacle', row: row,
            column: column, length: 2, horizontal: false));
        occupied
          ..add('$row:$column')
          ..add('${row + 1}:$column');
      }
      // Later boards add short decoy planks in any remaining free lanes.
      final decoys = min(6, max(0, index - 7));
      for (var decoy = 0; decoy < decoys; decoy++) {
        final candidates = [
          for (var row = 0; row < 6; row++)
            for (var column = 0; column < 5; column++) (row, column),
        ];
        final position = candidates.firstWhere((position) =>
            !occupied.contains('${position.$1}:${position.$2}') &&
            !occupied.contains('${position.$1}:${position.$2 + 1}'));
        pieces.add(PlankPiece(id: 'decoy-$decoy', row: position.$1,
            column: position.$2, length: 2, horizontal: true));
        occupied
          ..add('${position.$1}:${position.$2}')
          ..add('${position.$1}:${position.$2 + 1}');
      }
      return PlankLevel(number, List.unmodifiable(pieces));
    });

class GameBreakCard extends StatefulWidget {
  const GameBreakCard({super.key, required this.kind, required this.startLevel,
    required this.onLevelCompleted, required this.onPreviousCard,
    required this.onNextCard});
  final MiniGameKind kind;
  final int startLevel;
  final ValueChanged<int> onLevelCompleted;
  final VoidCallback onPreviousCard;
  final VoidCallback onNextCard;

  @override
  State<GameBreakCard> createState() => _GameBreakCardState();
}

class _GameBreakCardState extends State<GameBreakCard> {
  late int _level;
  late final List<PlankLevel> _plankLevels;
  late final List<LinesLevel> _linesLevels;
  late List<PlankPiece> _pieces;
  late LinesGameState _lines;
  Timer? _raceTimer;
  final GlobalKey _boardKey = GlobalKey();
  Offset? _outsideSwipeStart;
  String? _dragging;
  double _dragDistance = 0;
  bool _cleared = false;

  @override
  void initState() {
    super.initState();
    _level = widget.startLevel.clamp(1, 20).toInt();
    _plankLevels = plankLevels();
    _linesLevels = LinesLevel.all();
    _resetLevel();
  }

  @override
  void didUpdateWidget(covariant GameBreakCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.kind != oldWidget.kind) {
      _level = widget.startLevel.clamp(1, 20).toInt();
      _resetLevel();
    } else if (!_cleared && widget.startLevel > _level) {
      _level = widget.startLevel.clamp(1, 20).toInt();
      _resetLevel();
    }
  }

  void _resetLevel() {
    _raceTimer?.cancel();
    _pieces = List.of(_plankLevels[_level - 1].pieces);
    _lines = LinesGameState(_linesLevels[_level - 1]);
    _cleared = false;
    _dragging = null;
    _dragDistance = 0;
  }

  @override
  void dispose() {
    _raceTimer?.cancel();
    super.dispose();
  }

  bool _insideBoard(Offset globalPosition) {
    final box = _boardKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return false;
    return (box.localToGlobal(Offset.zero) & box.size).contains(globalPosition);
  }

  void _finishOutsideSwipe(PointerUpEvent event) {
    final start = _outsideSwipeStart;
    _outsideSwipeStart = null;
    if (start == null) return;
    final delta = event.position - start;
    if (delta.dy.abs() < 55 || delta.dy.abs() <= delta.dx.abs()) return;
    if (delta.dy < 0) {
      widget.onNextCard();
    } else {
      widget.onPreviousCard();
    }
  }

  bool _canMove(PlankPiece piece, int row, int column) {
    if (piece.horizontal && (row != piece.row || column < 0 ||
        column + piece.length > 7)) {
      return false;
    }
    if (!piece.horizontal && (column != piece.column || row < 0 ||
        row + piece.length > 6)) {
      return false;
    }
    for (var offset = 0; offset < piece.length; offset++) {
      final cellRow = row + (piece.horizontal ? 0 : offset);
      final cellColumn = column + (piece.horizontal ? offset : 0);
      if (cellColumn >= 6) continue;
      for (final other in _pieces) {
        if (other.id == piece.id) continue;
        for (var otherOffset = 0; otherOffset < other.length; otherOffset++) {
          final otherRow = other.row + (other.horizontal ? 0 : otherOffset);
          final otherColumn = other.column + (other.horizontal ? otherOffset : 0);
          if (cellRow == otherRow && cellColumn == otherColumn) return false;
        }
      }
    }
    return true;
  }

  void _moveSelected(DragUpdateDetails details, double cellSize) {
    final id = _dragging;
    if (id == null || _cleared) return;
    final pieceIndex = _pieces.indexWhere((piece) => piece.id == id);
    if (pieceIndex < 0) return;
    final piece = _pieces[pieceIndex];
    final delta = piece.horizontal ? details.delta.dx : details.delta.dy;
    _dragDistance += delta;
    while (_dragDistance.abs() >= cellSize * 0.55) {
      final direction = _dragDistance > 0 ? 1 : -1;
      final row = piece.row + (piece.horizontal ? 0 : direction);
      final column = piece.column + (piece.horizontal ? direction : 0);
      if (!_canMove(piece, row, column)) {
        _dragDistance = 0;
        break;
      }
      setState(() {
        _pieces[pieceIndex] = piece.moveTo(row, column);
        _dragDistance -= direction * cellSize;
        if (piece.target && column + piece.length > 6) {
          _cleared = true;
          widget.onLevelCompleted(_level);
        }
      });
      break;
    }
  }

  void _nextLevel() {
    if (_level >= 20) return;
    setState(() {
      _level++;
      _resetLevel();
    });
  }

  void _placeLineDot(Offset localPosition, Size size) {
    final point = _lines.nearest(Offset(
        localPosition.dx / size.width, localPosition.dy / size.height));
    if (point == null || !_lines.start(point)) return;
    setState(() {});
    _raceTimer = Timer.periodic(const Duration(milliseconds: 75), (timer) {
      if (!mounted) { timer.cancel(); return; }
      setState(() {
        if (!_lines.advance()) {
          timer.cancel();
          if (_lines.outcome == LinesOutcome.won) {
            _cleared = true;
            widget.onLevelCompleted(_level);
          }
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) => Listener(
    behavior: HitTestBehavior.opaque,
    onPointerDown: (event) => _outsideSwipeStart =
        _insideBoard(event.position) ? null : event.position,
    onPointerUp: _finishOutsideSwipe,
    onPointerCancel: (_) => _outsideSwipeStart = null,
    child: Container(
    decoration: BoxDecoration(
      color: const Color(0xFF1D2940),
      borderRadius: BorderRadius.circular(26),
    ),
    padding: const EdgeInsets.fromLTRB(22, 96, 22, 22),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Icon(widget.kind.icon, color: const Color(0xFFF5C85B)),
        const SizedBox(width: 10),
        Expanded(child: Text(widget.kind.title.toUpperCase(),
            style: const TextStyle(color: Color(0xFFF5C85B),
                fontWeight: FontWeight.w800, letterSpacing: 1.2))),
        Text('LEVEL $_level / 20', style: const TextStyle(color: Colors.white70,
            fontWeight: FontWeight.w700)),
      ]),
      const SizedBox(height: 12),
      Text(widget.kind.subtitle, style: const TextStyle(
          color: Colors.white70, fontSize: 16)),
      const SizedBox(height: 16),
      Expanded(child: widget.kind == MiniGameKind.planks
          ? _buildPlankBoard()
          : _buildLinesBoard()),
      const SizedBox(height: 12),
      if (widget.kind == MiniGameKind.planks) ...[
        Text(_cleared ? 'Path clear!' : 'Drag each plank along its length.',
            style: const TextStyle(color: Colors.white70)),
        if (_cleared) _nextButton(),
      ] else ...[
        const SizedBox(height: 6),
        LinearProgressIndicator(
          value: _lines.playerCount / _lines.owners.length,
          color: const Color(0xFF16A8B0),
          backgroundColor: Colors.white24,
          minHeight: 7,
        ),
        const SizedBox(height: 4),
        LinearProgressIndicator(
          value: _lines.opponentCount / _lines.owners.length,
          color: const Color(0xFFBE8B14),
          backgroundColor: Colors.white24,
          minHeight: 7,
        ),
        const SizedBox(height: 6),
        Text('Teal: ${_lines.playerCount} / ${_lines.majority} · '
            'Gold: ${_lines.opponentCount}',
            style: const TextStyle(color: Colors.white70)),
        if (_lines.outcome == LinesOutcome.won ||
            _lines.outcome == LinesOutcome.lost) ...[
          const SizedBox(height: 8),
          Text(_lines.outcome == LinesOutcome.won
              ? 'More than half the lines are yours!'
              : 'Gold took the majority. Try another starting point.',
              style: const TextStyle(fontWeight: FontWeight.w700)),
          if (_lines.outcome == LinesOutcome.won) _nextButton(),
          if (_lines.outcome == LinesOutcome.lost)
            TextButton(onPressed: () => setState(_resetLevel),
                child: const Text('Try this level again')),
        ] else
          const Text('Tap a grey line to place your teal starting dot.',
              style: TextStyle(color: Colors.white70)),
      ],
    ]),
    ),
  );

  Widget _nextButton() => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: FilledButton.icon(
      onPressed: _level < 20 ? _nextLevel : null,
      icon: const Icon(Icons.arrow_forward_rounded),
      label: Text(_level < 20 ? 'Next level' : 'All 20 levels complete'),
    ),
  );

  Widget _buildPlankBoard() => LayoutBuilder(builder: (context, constraints) {
    final boardSize = min(constraints.maxWidth, constraints.maxHeight);
    final cell = boardSize / 6;
    return Center(child: SizedBox(key: _boardKey, width: boardSize, height: boardSize,
      child: Container(
        decoration: BoxDecoration(color: const Color(0xFF111827),
          border: Border.all(color: Colors.white24, width: 2),
          borderRadius: BorderRadius.circular(14)),
        child: Stack(children: [
          for (var row = 0; row < 6; row++)
            for (var column = 0; column < 6; column++)
              Positioned(left: column * cell, top: row * cell,
                width: cell, height: cell,
                child: Container(margin: const EdgeInsets.all(2),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.035),
                    borderRadius: BorderRadius.circular(5)))),
          for (final piece in _pieces)
            Positioned(
              left: piece.column * cell + 2,
              top: piece.row * cell + 2,
              width: (piece.horizontal ? piece.length : 1) * cell - 4,
              height: (piece.horizontal ? 1 : piece.length) * cell - 4,
              child: GestureDetector(
                key: ValueKey('plank-${piece.id}'),
                onPanStart: (_) => setState(() {
                  _dragging = piece.id;
                  _dragDistance = 0;
                }),
                onPanUpdate: (details) => _moveSelected(details, cell),
                onPanEnd: (_) => setState(() { _dragging = null; _dragDistance = 0; }),
                child: AnimatedContainer(duration: const Duration(milliseconds: 90),
                  decoration: BoxDecoration(
                    color: piece.target ? const Color(0xFFF5C85B)
                        : const Color(0xFF9B6846),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: piece.target
                        ? Colors.white : const Color(0xFFD3A47E), width: 2),
                    boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .3),
                        blurRadius: 6, offset: const Offset(0, 3))],
                  ),
                  child: Center(child: Icon(piece.target ? Icons.star_rounded
                      : piece.horizontal ? Icons.drag_handle_rounded
                          : Icons.drag_indicator_rounded,
                    color: piece.target ? const Color(0xFF4A3510) : Colors.white70)),
                ),
              ),
            ),
          Positioned(right: -2, top: 2 * cell + cell * .25,
            height: cell * .5, width: 15,
            child: const Icon(Icons.chevron_right, color: Color(0xFFF5C85B))),
        ]),
      ),
    ));
  });

  Widget _buildLinesBoard() => LayoutBuilder(builder: (context, constraints) {
    final side = min(constraints.maxWidth, constraints.maxHeight);
    return Center(child: SizedBox.square(
      key: _boardKey,
      dimension: side,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: _lines.outcome == LinesOutcome.waiting
            ? (details) => _placeLineDot(details.localPosition, Size.square(side))
            : null,
        child: DecoratedBox(
          decoration: BoxDecoration(color: const Color(0xFFF2F0EA),
              border: Border.all(color: const Color(0xFF1AADB4), width: 5)),
          child: CustomPaint(painter: _LinesPainter(_lines)),
        ),
      ),
    ));
  });
}

class _LinesPainter extends CustomPainter {
  const _LinesPainter(this.game);
  final LinesGameState game;

  @override
  void paint(Canvas canvas, Size size) {
    final level = game.level;
    Offset scale(Offset point) => Offset(point.dx * size.width,
        point.dy * size.height);
    final grey = Paint()..color = const Color(0xFFC8C8C6)
        ..strokeWidth = 7 ..strokeCap = StrokeCap.round;
    final teal = Paint()..color = const Color(0xFF16A8B0)
        ..strokeWidth = 8 ..strokeCap = StrokeCap.round;
    final gold = Paint()..color = const Color(0xFFBE8B14)
        ..strokeWidth = 8 ..strokeCap = StrokeCap.round;
    for (var i = 0; i < level.points.length; i++) {
      for (final next in level.neighbors[i]) {
        if (next <= i) continue;
        final owner = game.owners[i] == game.owners[next]
            ? game.owners[i] : 0;
        canvas.drawLine(scale(level.points[i]), scale(level.points[next]),
            owner == 1 ? teal : owner == 2 ? gold : grey);
      }
    }
    final dot = Paint()..color = const Color(0xFFBE8B14);
    for (final seed in level.opponentSeeds) {
      canvas.drawCircle(scale(level.points[seed]), 6, dot);
    }
    if (game.playerSeed case final seed?) {
      canvas.drawCircle(scale(level.points[seed]), 7,
          Paint()..color = const Color(0xFF16A8B0));
    }
  }

  @override
  bool shouldRepaint(covariant _LinesPainter oldDelegate) => true;
}
