alter table public.learner_game_progress
  drop constraint learner_game_progress_game_slug_check;

alter table public.learner_game_progress
  add constraint learner_game_progress_game_slug_check
  check (game_slug in ('planks', 'territory', 'lines'));
