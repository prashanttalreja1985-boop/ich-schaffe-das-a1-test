-- One immutable award per completed activity. Quiz awards use the number of
-- answer taps recorded before completion; clients cannot write scores.
alter table public.learner_answers
  add column if not exists attempt_key text;
alter table public.learner_answers
  add constraint learner_answers_attempt_key_key unique (attempt_key);

create table if not exists public.learner_score_events (
  user_id uuid not null,
  profile_key text not null,
  book_slug text not null,
  activity_slug text not null,
  language_level text not null,
  points integer not null check (points between 0 and 2),
  earned_at timestamptz not null,
  primary key (user_id, profile_key, book_slug, activity_slug),
  foreign key (user_id, profile_key, book_slug, activity_slug)
    references public.learner_activity_progress
      (user_id, profile_key, book_slug, activity_slug) on delete cascade
);
create index if not exists learner_score_events_month_idx
  on public.learner_score_events (user_id, earned_at, profile_key);
alter table public.learner_score_events enable row level security;
create policy "read own score events" on public.learner_score_events
  for select to authenticated using ((select auth.uid()) = user_id);
grant select on public.learner_score_events to authenticated;

create schema if not exists app_private;
revoke all on schema app_private from public, anon, authenticated;

create or replace function app_private.award_activity_points()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  activity_kind text;
  course_level text;
  attempts integer;
  answered_correctly boolean;
  award integer;
begin
  select a.kind, b.level into activity_kind, course_level
    from public.learning_activities a
    join public.learning_lessons l on l.id = a.lesson_id
    join public.learning_books b on b.id = l.book_id
    where a.slug = new.activity_slug and b.slug = new.book_slug;

  if activity_kind = 'quiz' then
    select count(*), coalesce(bool_or(is_correct), false)
      into attempts, answered_correctly
      from public.learner_answers
      where user_id = new.user_id and profile_key = new.profile_key
        and book_slug = new.book_slug and activity_slug = new.activity_slug;
    award := case
      when not answered_correctly then 0
      when attempts = 1 then 2
      when attempts = 2 then 1
      else 0 end;
  else
    award := 1;
  end if;

  insert into public.learner_score_events
    (user_id, profile_key, book_slug, activity_slug,
     language_level, points, earned_at)
  values (new.user_id, new.profile_key, new.book_slug, new.activity_slug,
          course_level, award, new.completed_at)
  on conflict do nothing;
  return new;
end;
$$;
revoke all on function app_private.award_activity_points()
  from public, anon, authenticated;

create trigger award_completed_activity_points
  after insert on public.learner_activity_progress
  for each row execute function app_private.award_activity_points();

-- Existing completion rows receive their original completion month.
insert into public.learner_score_events
  (user_id, profile_key, book_slug, activity_slug,
   language_level, points, earned_at)
select p.user_id, p.profile_key, p.book_slug, p.activity_slug, b.level,
  case when a.kind <> 'quiz' then 1
       when coalesce(q.correct, false) = false then 0
       when q.attempts = 1 then 2
       when q.attempts = 2 then 1
       else 0 end,
  p.completed_at
from public.learner_activity_progress p
join public.learning_activities a on a.slug = p.activity_slug
join public.learning_lessons l on l.id = a.lesson_id
join public.learning_books b on b.id = l.book_id and b.slug = p.book_slug
left join lateral (
  select count(*) as attempts, bool_or(ans.is_correct) as correct
  from public.learner_answers ans
  where ans.user_id = p.user_id and ans.profile_key = p.profile_key
    and ans.book_slug = p.book_slug and ans.activity_slug = p.activity_slug
) q on true
on conflict do nothing;

create or replace view public.learner_profile_points
  with (security_invoker = true) as
select user_id, profile_key, language_level,
  sum(points)::integer as lifetime_points,
  coalesce(sum(points) filter (where earned_at >=
    date_trunc('month', now())), 0)::integer as current_month_points
from public.learner_score_events
group by user_id, profile_key, language_level;
grant select on public.learner_profile_points to authenticated;
