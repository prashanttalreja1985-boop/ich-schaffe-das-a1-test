import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('reset replaces a quiz page with lesson one card one', (
    tester,
  ) async {
    final raw = await tester.runAsync(
      () => rootBundle.loadString('assets/starter_content.json'),
    );
    final curriculum = Curriculum.fromJson(jsonDecode(raw!));
    final firstQuiz = curriculum.activities.indexWhere((a) => a.kind == 'quiz');
    SharedPreferences.setMockInitialValues({
      'done:reset-screen:${curriculum.slug}': curriculum.activities
          .take(firstQuiz)
          .map((card) => card.slug)
          .toList(),
    });
    Widget screen(String revision) => MaterialApp(
      home: LearningScreen(
        key: ValueKey(revision),
        courseAsset: 'assets/starter_content.json',
        bookSlug: 'original-a1-starter',
        profileKey: 'reset-screen',
        profileName: 'Test learner',
        enableTeacherAudio: false,
        enableTeacherPortrait: false,
      ),
    );
    await tester.pumpWidget(screen('before-reset'));
    await tester.runAsync(() async {
      await Future<void>.delayed(const Duration(seconds: 3));
    });
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('QUICK CHECK'), findsOneWidget);

    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(screen('after-reset'));
    await tester.runAsync(() async {
      await Future<void>.delayed(const Duration(seconds: 3));
    });
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('GRAMMAR'), findsOneWidget);
    expect(find.text('QUICK CHECK'), findsNothing);
    expect(find.textContaining('LESSON 1  ·  CARD 1/'), findsOneWidget);
  });
}
