import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/feedback_voice.dart';
import 'package:ich_schaffe_das/lip_motion.dart';
import 'package:ich_schaffe_das/teacher_portrait.dart';

void main() {
  test(
    'quiz feedback waits for a choice and speaks a friendly explanation',
    () {
      expect(
        friendlyQuizFeedback('der is masculine.', correct: false),
        "That's not right. Give it another try.",
      );
      expect(
        friendlyQuizFeedback('der is masculine.', correct: true),
        "Yes, that's it! der is masculine.",
      );
    },
  );

  test('mouth movement stops at the ends of a prerecorded lesson', () {
    const script = 'Hallo, ich bin hier.';
    const duration = Duration(seconds: 4);
    expect(narrationMouthOpen(script, Duration.zero, duration), 0);
    expect(
      narrationMouthOpen(script, const Duration(seconds: 1), duration),
      greaterThan(0),
    );
    expect(narrationMouthOpen(script, duration, duration), 0);
  });

  test('face landmarks remain aligned after portrait-to-square cropping', () {
    final mouth = MouthRegion.forSquare({
      'x': 0.5,
      'y': 0.7,
      'width': 0.16,
      'imageWidth': 200,
      'imageHeight': 320,
    });
    expect(mouth.x, closeTo(0.5, 0.001));
    expect(mouth.y, closeTo(0.82, 0.001));
    expect(mouth.width, closeTo(0.16, 0.001));
  });
}
