import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('a reset account opens the first teaching card', (tester) async {
    await tester.runAsync(
      () => rootBundle.loadString('assets/starter_content.json'),
    );
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(
        home: LearningScreen(
          courseAsset: 'assets/starter_content.json',
          bookSlug: 'original-a1-starter',
          profileKey: 'fresh-account',
          profileName: 'Fresh learner',
          enableTeacherAudio: false,
          enableTeacherPortrait: false,
        ),
      ),
    );
    await tester.runAsync(() async {
      await Future<void>.delayed(const Duration(seconds: 3));
    });
    for (
      var frame = 0;
      frame < 30 && find.text('GRAMMAR').evaluate().isEmpty;
      frame++
    ) {
      await tester.pump(const Duration(milliseconds: 100));
    }
    expect(find.text('GRAMMAR'), findsOneWidget);
    expect(find.text('QUICK CHECK'), findsNothing);
    expect(find.textContaining('LESSON 1'), findsOneWidget);
  });
}
