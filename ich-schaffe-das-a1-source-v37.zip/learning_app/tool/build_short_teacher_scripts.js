const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..', 'assets');
const existing = JSON.parse(fs.readFileSync(path.join(root, 'teacher_scripts_a1_01_20.json'), 'utf8'));
const lines = [
  'Hey, ich bin means I am; du bist is you are, and polite Sie sind works the same.',
  'Want someone\'s name? Ask wie heißt du, or politely wie heißen Sie; reply ich heiße.',
  'For where you\'re from, ask woher kommst du, then say ich komme aus and your town.',
  'Quick heads-up: German nouns get a capital letter, and the alphabet has ä, ö, ü, and ß.',
  'These little umlauts change the sound; and ß is a sharp s, like in Straße.',
  'Morning is guten Morgen, daytime guten Tag, evening guten Abend; tschüss is your easy goodbye.',
  'Need a spelling rescue? Say wie schreibt man das, or politely können Sie das bitte buchstabieren.',
  'For how many, say wie viele; and twenty-one flips around to einundzwanzig, one and twenty.',
  'Question hack: put the question word first, then the verb, like wo wohnst du.',
  'Yes-or-no question? Start with the verb; nicht means not, while kein means not a.',
  'You can already do a mini chat: wie geht es dir; mir geht es gut, danke.',
  'Mein is my and dein is your; before feminine words, add e: meine Mutter.',
  'Plural alert: learn each noun with its plural; the plural article is die here.',
  'Tiny intro pack: hallo, guten Morgen, tschüss, and der Name; say mein Name ist with your name.',
  'Die Stadt is city, das Land is country; ich wohne in says where you live.',
  'German nouns come with a buddy: der, die, or das; learn the article with the word.',
  'If someone speaks too fast, just say sprechen Sie bitte langsam; honestly, lifesaver.',
  'Numbers zero to five go null, eins, zwei, drei, vier, fünf; you\'ve got this.',
  'Zehn is ten, zwanzig is twenty, hundert is hundred; Telefonnummer is your phone number.',
  'Wer, was, wo, wohin, woher, wann: six tiny words to kick off a German question.',
];
if (existing.cards.length !== lines.length) throw new Error('Expected twenty teacher cards');
existing.style = 'Warm, relaxed friend. One short sentence per card, light modern slang, no long explanation.';
existing.cards.forEach((card, index) => { card.script = lines[index]; });
fs.writeFileSync(path.join(root, 'teacher_scripts_a1_01_20.json'), JSON.stringify(existing, null, 2) + '\n');

const reactions = {
  voice: 'af_heart',
  clips: [
    {id:'welcome_back', category:'welcome', text:'Welcome back!'},
    {id:'lets_learn', category:'welcome', text:'Let\'s get to learning German!'},
    {id:'not_quite_right', category:'wrong', text:'That\'s not quite right.'},
    {id:'nooo', category:'wrong', text:'Nooo! Try another one.'},
    {id:'not_that', category:'wrong', text:'Not that one, dude.'},
    {id:'thats_right', category:'correct', text:'That\'s right!'},
    {id:'you_are_awesome', category:'correct', text:'You\'re awesome!'},
    {id:'great', category:'correct', text:'Great!'},
    {id:'super', category:'correct', text:'Super!'},
    {id:'wow', category:'correct', text:'Wow!'},
    {id:'aha_nice', category:'correct', text:'Aha, nice!'},
    {id:'dude', category:'correct', text:'Dude, you got it!'},
    {id:'man_oh_man', category:'correct', text:'Man oh man, nice one!'},
    {id:'damn_good', category:'correct', text:'Damn, you\'re good!'},
    {id:'phew_close', category:'correct', text:'Phew, that was close!'},
  ],
};
fs.writeFileSync(path.join(root, 'teacher_reactions.json'), JSON.stringify(reactions, null, 2) + '\n');
