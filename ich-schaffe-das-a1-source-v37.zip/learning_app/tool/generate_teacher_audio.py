"""One-time Kokoro batch for short A1 narrations and reaction phrases.

Run on the existing ClipStudio pod that has kokoro-onnx, soundfile, and ffmpeg.
The generated MP3s are bundled with the app; no TTS service runs in the app.
"""

import argparse
import json
from pathlib import Path
import subprocess

import onnxruntime as ort
import soundfile as sf
from kokoro_onnx import Kokoro


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scripts", type=Path, required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--reactions", type=Path)
    parser.add_argument("--count", type=int, default=20)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    cards = json.loads(args.scripts.read_text(encoding="utf-8"))["cards"]
    assert len(cards) == 20
    args.output.mkdir(parents=True, exist_ok=True)
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    session = ort.InferenceSession(
        str(args.model_dir / "kokoro-v1.0.onnx"),
        sess_options=options,
        providers=["CPUExecutionProvider"],
    )
    voice = Kokoro.from_session(session, str(args.model_dir / "voices-v1.0.bin"))
    jobs = [(f"a1_{card['number']:02d}.mp3", card["script"])
            for card in cards[: args.count]]
    if args.reactions:
        reactions = json.loads(args.reactions.read_text(encoding="utf-8"))["clips"]
        jobs.extend((f"reaction_{clip['id']}.mp3", clip["text"])
                    for clip in reactions)
    for filename, script in jobs:
        output = args.output / filename
        if not args.overwrite and output.exists() and output.stat().st_size > 1000:
            print(f"kept {output}", flush=True)
            continue
        samples, rate = voice.create(
            script, voice="af_heart", speed=1.08, lang="en-us"
        )
        temporary = output.with_suffix(".wav")
        sf.write(temporary, samples, rate)
        subprocess.run(
            [
                "ffmpeg", "-v", "error", "-y", "-i", str(temporary),
                "-ac", "1", "-ar", "24000", "-b:a", "64k", str(output),
            ],
            check=True,
        )
        temporary.unlink()
        print(f"{filename}: {output.stat().st_size} bytes", flush=True)


if __name__ == "__main__":
    main()
