import 'dart:async';

import 'package:flutter/services.dart';

/// Uses the iPhone's offline speech voice for quiz feedback on every card.
class FeedbackVoice {
  FeedbackVoice() {
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'word') onWord?.call();
      if (call.method == 'finished') {
        onFinished?.call();
        _pending?.complete();
        _pending = null;
      }
    });
  }

  static const _channel = MethodChannel('de.ichschaffedas.a1/teacher_voice');
  Completer<void>? _pending;
  void Function()? onWord;
  void Function()? onFinished;

  Future<void> speak(String text) async {
    await stop();
    final pending = Completer<void>();
    _pending = pending;
    try {
      await _channel.invokeMethod<void>('speak', text);
      await pending.future.timeout(const Duration(seconds: 45));
    } on MissingPluginException {
      // The test host has no iOS speech engine.
    } on TimeoutException {
      // A voice download or audio interruption must not lock the lesson.
    } finally {
      if (identical(_pending, pending)) _pending = null;
      onFinished?.call();
    }
  }

  Future<void> stop() async {
    final pending = _pending;
    _pending = null;
    if (pending != null && !pending.isCompleted) pending.complete();
    try {
      await _channel.invokeMethod<void>('stop');
    } on MissingPluginException {
      // Widget tests have no platform speech engine.
    }
  }

  Future<void> dispose() async {
    await stop();
    _channel.setMethodCallHandler(null);
  }
}

String friendlyQuizFeedback(String explanation, {required bool correct}) {
  if (!correct) return "That's not right. Give it another try.";
  final detail = explanation.trim();
  if (detail.isEmpty) return "Yes, that's it. Nice work!";
  return "Yes, that's it! $detail";
}
