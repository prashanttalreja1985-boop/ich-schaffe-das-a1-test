import 'dart:convert';

import 'package:flutter/services.dart';

class TeacherNarration {
  const TeacherNarration({
    required this.activitySlug,
    required this.script,
    required this.audioAsset,
  });

  final String activitySlug;
  final String script;
  final String audioAsset;
}

class TeacherNarrationStore {
  static Future<Map<String, TeacherNarration>>? _cache;

  static Future<Map<String, TeacherNarration>> load(String bookSlug) async {
    if (bookSlug != 'original-a1-starter') return {};
    return _cache ??= _loadBundled();
  }

  static Future<Map<String, TeacherNarration>> _loadBundled() async {
    final source = jsonDecode(
      await rootBundle.loadString('assets/teacher_scripts_a1_01_20.json'),
    ) as Map<String, dynamic>;
    final cards = source['cards'] as List<dynamic>;
    return {
      for (final value in cards)
        if (value is Map<String, dynamic>)
          value['activity_slug'] as String: TeacherNarration(
            activitySlug: value['activity_slug'] as String,
            script: value['script'] as String,
            audioAsset:
                'teacher_audio/a1_${(value['number'] as int).toString().padLeft(2, '0')}.mp3',
          ),
    };
  }
}

class TeacherReaction {
  const TeacherReaction(this.id, this.category, this.text, this.audioAsset);
  final String id;
  final String category;
  final String text;
  final String audioAsset;
}

class TeacherReactionStore {
  static Future<List<TeacherReaction>>? _cache;

  static Future<List<TeacherReaction>> load() => _cache ??= _read();

  static Future<List<TeacherReaction>> _read() async {
    final source = jsonDecode(
      await rootBundle.loadString('assets/teacher_reactions.json'),
    ) as Map<String, dynamic>;
    return [
      for (final raw in source['clips'] as List<dynamic>)
        if (raw is Map<String, dynamic>)
          TeacherReaction(
            raw['id'] as String,
            raw['category'] as String,
            raw['text'] as String,
            'teacher_audio/reaction_${raw['id']}.mp3',
          ),
    ];
  }
}
