import 'dart:math' as math;

/// Estimates syllable timing from a prerecorded script. Only the current
/// position is sampled, so the portrait has no continuous animation loop.
double narrationMouthOpen(String script, Duration position, Duration duration) {
  if (duration <= Duration.zero || script.trim().isEmpty) return 0;
  final words = RegExp(
    r"[\p{L}']+",
    unicode: true,
  ).allMatches(script).map((match) => match.group(0)!).toList();
  if (words.isEmpty) return 0;
  final weights = [for (final word in words) math.max(1, word.length ~/ 3 + 1)];
  final total = weights.fold<int>(0, (a, b) => a + b);
  final progress = position.inMilliseconds / duration.inMilliseconds;
  if (progress <= 0 || progress >= 1) return 0;
  final target = progress * total;
  var cursor = 0.0;
  for (var i = 0; i < words.length; i++) {
    final end = cursor + weights[i];
    if (target < end) {
      final phase = (target - cursor) / weights[i];
      final syllables = weights[i];
      final wave = math.sin(phase * math.pi * syllables).abs();
      final vowel = RegExp('[aeiouäöüyAEIOUÄÖÜY]').hasMatch(words[i]);
      final pause = phase > 0.86 ? (1 - phase) / 0.14 : 1.0;
      return ((vowel ? 0.28 : 0.15) + wave * (vowel ? 0.7 : 0.48)) * pause;
    }
    cursor = end;
  }
  return 0;
}
