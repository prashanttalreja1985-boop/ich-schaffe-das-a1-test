// Assign the existing, human-reviewed cutout library to every course card.
// No lesson text or answer is changed. Run from learning_app/ with Node.
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const source = path.resolve(root, '../apps/ClipStudio/backend/cutouts');
const target = path.join(root, 'assets/visuals');
const catalog = JSON.parse(fs.readFileSync(path.join(source, 'catalog.json')));
const books = ['starter_content.json', 'a1_plus_content.json'].map((name) =>
  JSON.parse(fs.readFileSync(path.join(root, 'assets', name))));

const rules = [
  { words: /train|zug|bahnhof|station|fahrkarte|ticket|platform/i, set: 'train station', role: 'commuter', prop: 'receipt' },
  { words: /doctor|arzt|ärzt|krank|health|gesund|schmerz|medicine/i, set: 'bedroom', role: 'doctor', prop: 'glass' },
  { words: /teacher|lehrer|schule|school|unterricht|classroom/i, set: 'school', role: 'teacher', prop: 'pencil' },
  { words: /market|shop|laden|kaufen|verkauf|preis|cost|shopping|einkauf/i, set: 'market', role: 'shopper', prop: 'receipt' },
  { words: /restaurant|café|cafe|essen|trinken|speise|menu|bestell|dinner/i, set: 'bistro', role: 'waiter', prop: 'menu' },
  { words: /cook|kochen|kitchen|küche|breakfast|frühstück|food/i, set: 'kitchen', role: 'cook', prop: 'plate' },
  { words: /office|büro|arbeit|work|job|kolleg|meeting/i, set: 'office', role: 'office worker', prop: 'pencil' },
  { words: /park|spazier|walk|tree|baum|garden/i, set: 'park', role: 'friend', prop: 'tree' },
  { words: /street|straße|direction|weg|route|links|rechts|geradeaus|city|stadt/i, set: 'street', role: 'tourist', prop: 'house' },
  { words: /travel|reise|urlaub|hotel|flughafen|airport|flieg|flight/i, set: 'downtown', role: 'tourist', prop: 'receipt' },
  { words: /family|familie|mutter|vater|eltern|kind|child|sister|brother/i, set: 'living room', role: 'parent', prop: 'house' },
  { words: /music|musik|singen|song|instrument/i, set: 'living room', role: 'musician', prop: 'chair' },
  { words: /sport|spiel|game|fußball|football|laufen|run|schwimm/i, set: 'park', role: 'athlete', prop: 'tree' },
  { words: /haus|home|wohnung|room|zimmer|möbel|furniture|chair/i, set: 'living room', role: 'neighbor', prop: 'chair' },
  { words: /wetter|weather|sonne|rain|regen|cloud|wolke/i, set: 'street', role: 'friend', prop: 'tree' },
];
const lessonDefaults = [
  ['street', 'friend', 'house'], ['living room', 'parent', 'chair'],
  ['kitchen', 'friend', 'table'], ['street', 'commuter', 'house'],
  ['market', 'shopper', 'plate'], ['train station', 'tourist', 'receipt'],
  ['office', 'office worker', 'pencil'], ['park', 'friend', 'tree'],
  ['living room', 'friend', 'table'], ['street', 'neighbor', 'house'],
];
const castByRole = new Map();
for (const item of catalog.cast) {
  if (!castByRole.has(item.role)) castByRole.set(item.role, item.brief);
}
const used = new Set();
function asset(name) {
  const file = `${name}.webp`;
  if (!fs.existsSync(path.join(source, file))) throw Error(`Missing cutout: ${file}`);
  used.add(file);
  return file;
}
function captionFor(activity) {
  const value = activity.kind === 'quiz'
    ? activity.question
    : activity.kind === 'vocabulary'
      ? activity.items?.[0]?.example || activity.items?.[0]?.de
      : activity.example || activity.title;
  return String(value || activity.title).replace(/\s+/g, ' ').trim().slice(0, 105);
}
function sceneFor(activity, lesson, bookSlug, index) {
  // Quiz answers/options are excluded so the visual never discloses the answer.
  const cue = [activity.title, activity.kind === 'quiz' ? activity.question :
    activity.kind === 'vocabulary' ? activity.items?.[0]?.en : activity.example,
    activity.kind === 'quiz' ? '' : activity.body].filter(Boolean).join(' ');
  const matched = rules.find((rule) => rule.words.test(cue));
  const fallback = lessonDefaults[(lesson.number - 1) % lessonDefaults.length];
  const set = matched?.set || fallback[0];
  const role = matched?.role || fallback[1];
  const prop = matched?.prop || fallback[2];
  const brief = String(castByRole.get(role) ?? castByRole.get('friend')).padStart(2, '0');
  const person = index % 4;
  const frames = [0, 1, 2, 3].map((pose) => asset(`cast-${brief}-${person}-${pose}`));
  return {
    book_slug: bookSlug,
    activity_slug: activity.slug,
    backdrop: asset(`${set}-backdrop`),
    actor_frames: frames,
    prop: asset(prop),
    caption: captionFor(activity),
    visual_kind: activity.kind,
  };
}

const rows = [];
for (const book of books) {
  let index = 0;
  for (const lesson of book.lessons) {
    for (const activity of lesson.activities) {
      rows.push(sceneFor(activity, lesson, book.book.slug, index++));
    }
  }
}
fs.mkdirSync(target, { recursive: true });
for (const file of used) fs.copyFileSync(path.join(source, file), path.join(target, file));
for (const file of fs.readdirSync(target)) {
  if (!used.has(file)) fs.unlinkSync(path.join(target, file));
}
fs.writeFileSync(path.join(root, 'assets/visual_scenes.json'),
  JSON.stringify({ version: 1, scenes: rows }));
const sql = rows.map((row) =>
  `('${row.book_slug.replaceAll("'", "''")}','${row.activity_slug.replaceAll("'", "''")}',` +
  `'${JSON.stringify(row).replaceAll("'", "''")}'::jsonb)`).join(',\n');
fs.writeFileSync(path.join(root, 'tool/visual_scenes_import.sql'),
  'insert into public.learning_visual_scenes(book_slug, activity_slug, scene) values\n' +
  sql + '\non conflict (book_slug, activity_slug) do update set scene = excluded.scene;\n');
console.log(`${rows.length} card scenes, ${used.size} cutout images`);
