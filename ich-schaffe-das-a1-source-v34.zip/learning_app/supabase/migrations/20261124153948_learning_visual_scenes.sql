-- Scene directions are separate from the existing lesson and quiz payloads.
-- Images named in a scene are bundled from ClipStudio's reviewed cutout pack.
create table if not exists public.learning_visual_scenes (
  book_slug text not null references public.learning_books(slug) on delete cascade,
  activity_slug text not null references public.learning_activities(slug) on delete cascade,
  scene jsonb not null check (jsonb_typeof(scene) = 'object'),
  updated_at timestamptz not null default now(),
  primary key (book_slug, activity_slug)
);

alter table public.learning_visual_scenes enable row level security;
revoke all on public.learning_visual_scenes from anon, authenticated;
grant select on public.learning_visual_scenes to authenticated;

create policy "read visual scenes for published books"
  on public.learning_visual_scenes for select to authenticated
  using (exists (
    select 1 from public.learning_books b
    where b.slug = learning_visual_scenes.book_slug
      and b.source_status = 'published'
  ));
