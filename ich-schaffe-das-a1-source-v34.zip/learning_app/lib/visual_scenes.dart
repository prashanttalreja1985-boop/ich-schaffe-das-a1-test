import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class VisualScene {
  const VisualScene({
    required this.activitySlug,
    required this.backdrop,
    required this.actorFrames,
    required this.prop,
    required this.caption,
  });

  final String activitySlug;
  final String backdrop;
  final List<String> actorFrames;
  final String prop;
  final String caption;

  factory VisualScene.fromJson(Map<String, dynamic> json) => VisualScene(
    activitySlug: json['activity_slug'] as String,
    backdrop: json['backdrop'] as String,
    actorFrames: (json['actor_frames'] as List).cast<String>(),
    prop: json['prop'] as String,
    caption: json['caption'] as String,
  );

  Iterable<String> get files => [backdrop, ...actorFrames, prop];
}

class VisualSceneStore {
  static Future<Map<String, Map<String, VisualScene>>>? _bundledCache;

  static Future<Map<String, Map<String, VisualScene>>> _loadBundled() async {
    final document = jsonDecode(
      await rootBundle.loadString('assets/visual_scenes.json'),
    ) as Map<String, dynamic>;
    final books = <String, Map<String, VisualScene>>{};
    for (final raw in document['scenes'] as List) {
      final row = raw as Map<String, dynamic>;
      final scene = VisualScene.fromJson(row);
      books.putIfAbsent(row['book_slug'] as String, () => {})[scene.activitySlug] = scene;
    }
    return books;
  }

  static Future<Map<String, VisualScene>> load(
    String bookSlug, {
    SupabaseClient? client,
  }) async {
    final all = await (_bundledCache ??= _loadBundled());
    final bundled = all[bookSlug] ?? <String, VisualScene>{};
    if (client == null || bundled.isEmpty) return bundled;

    // The lesson and test content is independent of the visual scene table.
    // A missing or offline table uses the packaged scenes immediately.
    try {
      final allowedFiles = bundled.values
          .expand((scene) => scene.files)
          .toSet();
      final result = Map<String, VisualScene>.of(bundled);
      for (var offset = 0; offset < bundled.length; offset += 1000) {
        final rows = await client
            .from('learning_visual_scenes')
            .select('activity_slug,scene')
            .eq('book_slug', bookSlug)
            .order('activity_slug')
            .range(offset, offset + 999)
            .timeout(const Duration(seconds: 3));
        for (final row in rows) {
          final scene = VisualScene.fromJson(
            row['scene'] as Map<String, dynamic>,
          );
          if (scene.activitySlug == row['activity_slug'] &&
              bundled.containsKey(scene.activitySlug) &&
              scene.actorFrames.length == 4 &&
              scene.files.every(allowedFiles.contains)) {
            result[scene.activitySlug] = scene;
          }
        }
        if (rows.length < 1000) break;
      }
      return result;
    } catch (_) {
      return bundled;
    }
  }
}

class VisualScenePanel extends StatefulWidget {
  const VisualScenePanel({
    super.key,
    required this.scene,
    required this.active,
  });

  final VisualScene scene;
  final bool active;

  @override
  State<VisualScenePanel> createState() => _VisualScenePanelState();
}

class _VisualScenePanelState extends State<VisualScenePanel>
    with SingleTickerProviderStateMixin {
  late final AnimationController _motion = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 3600),
  );

  @override
  void initState() {
    super.initState();
    if (widget.active) _motion.repeat();
  }

  @override
  void didUpdateWidget(covariant VisualScenePanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active && !_motion.isAnimating) _motion.repeat();
    if (!widget.active && _motion.isAnimating) _motion.stop();
  }

  @override
  void dispose() {
    _motion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.of(context).disableAnimations;
    return Semantics(
      label: 'Scene: ${widget.scene.caption}',
      child: ClipRRect(
        borderRadius: BorderRadius.circular(21),
        child: SizedBox(
          height: math.min(205, MediaQuery.sizeOf(context).height * 0.24),
          width: double.infinity,
          child: AnimatedBuilder(
            animation: _motion,
            builder: (context, _) {
              final progress = widget.active && !reduceMotion
                  ? _motion.value
                  : 0.25;
              final bob = math.sin(progress * math.pi * 2);
              final pose = widget.active && !reduceMotion
                  ? (progress * widget.scene.actorFrames.length).floor().clamp(
                      0,
                      3,
                    )
                  : 0;
              return Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    'assets/visuals/${widget.scene.backdrop}',
                    fit: BoxFit.cover,
                    excludeFromSemantics: true,
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xA810182A),
                          Color(0x1510182A),
                          Color(0xC810182A),
                        ],
                        stops: [0, 0.48, 1],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 5 + bob * 7,
                    bottom: -5 + bob * 3,
                    width: 155,
                    height: 168,
                    child: Image.asset(
                      'assets/visuals/${widget.scene.actorFrames[pose]}',
                      fit: BoxFit.contain,
                      alignment: Alignment.bottomCenter,
                      gaplessPlayback: true,
                      excludeFromSemantics: true,
                    ),
                  ),
                  Positioned(
                    right: 8,
                    bottom: 4 + bob * 4,
                    width: 86,
                    height: 75,
                    child: Image.asset(
                      'assets/visuals/${widget.scene.prop}',
                      fit: BoxFit.contain,
                      excludeFromSemantics: true,
                    ),
                  ),
                  Positioned(
                    left: 113,
                    right: 10,
                    top: 13,
                    child: Transform.scale(
                      scale: 0.97 + 0.03 * ((bob + 1) / 2),
                      alignment: Alignment.bottomLeft,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 9,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xF2F5F0E2),
                          borderRadius: BorderRadius.circular(17),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black38,
                              blurRadius: 12,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Text(
                          widget.scene.caption,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Color(0xFF172034),
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            height: 1.25,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
