# Ich schaffe das — iPhone A1 test app

This Flutter app opens on a dark Google sign-in page and resumes at the first unfinished learning card. A new account starts with A1 lesson 1. Completing A1 opens the separate A1+ Revision course. Each card keeps its existing grammar, vocabulary, quiz, answers, word meanings, flag action, and scoring rules. The feed contains learning cards only.

Each of the 1,406 A1 and 145 A1+ cards has a separate visual scene. The scene specifies a background, four poses of one cutout character, a prop, and a short line from that card. The character, prop, and speech bubble move while the card is visible. Scene assignments are read from Deutsch Supabase's `learning_visual_scenes` table when available, with a bundled copy for offline use. Images are bundled from ClipStudio's reviewed `backend/cutouts` pack. ClipStudio's generated cutout library is a SQLite cache on its RunPod volume, not a Supabase asset database. The visual scenes do not change `learning_activities.payload`.

The learner's Supabase Auth UUID keys completed cards, quiz attempts, points, and flags. `learner_activity_progress`, `learner_answers`, and `learner_score_events` hold user progress. The older `learner_game_progress` table is retained as historical data but no game is loaded or shown by this app. Tap the initial at the top right for monthly leaders, personal points, and sign-out.

Books, lessons, activities, and the lexicon are read from Deutsch Supabase with bundled course fallback. The A1+ book is still a database draft, so the app uses its bundled content and scenes until publication. Google OAuth is in test mode and only listed test accounts can sign in. The redirect is `de.ichschaffedas.a1://login-callback/`.

Run `node tool/build_visual_scenes.js` from this directory to regenerate scene assignments and the selected packaged images from ClipStudio's cutout pack. The generated `tool/visual_scenes_import.sql` imports the assignments into Deutsch after the table migration. This IPA is unsigned for Sideloadly to sign with the installer's Apple ID.
