import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';
import 'package:ich_schaffe_das/visual_scenes.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('unanswered quiz follows the finger, returns, and shows a hint', (
    tester,
  ) async {
    final raw = await tester.runAsync(
      () => rootBundle.loadString('assets/starter_content.json'),
    );
    final curriculum = Curriculum.fromJson(jsonDecode(raw!));
    final scenes = await tester.runAsync(
      () => VisualSceneStore.load(curriculum.slug),
    );
    expect(scenes, hasLength(curriculum.activities.length));
    final firstQuiz = curriculum.activities.indexWhere((a) => a.kind == 'quiz');
    SharedPreferences.setMockInitialValues({
      'done:swipe-test:${curriculum.slug}': curriculum.activities
          .take(firstQuiz)
          .map((activity) => activity.slug)
          .toList(),
    });
    await tester.pumpWidget(
      const MaterialApp(
        home: LearningScreen(
          courseAsset: 'assets/starter_content.json',
          bookSlug: 'original-a1-starter',
          profileKey: 'swipe-test',
          profileName: 'Test learner',
        ),
      ),
    );
    await tester.runAsync(() async {
      await Future<void>.delayed(const Duration(milliseconds: 800));
    });
    final label = find.text('QUICK CHECK');
    for (var frame = 0; frame < 30 && label.evaluate().isEmpty; frame++) {
      await tester.pump(const Duration(milliseconds: 100));
    }
    expect(label, findsOneWidget,
        reason: 'Visible text: ${tester.widgetList<Text>(find.byType(Text)).map((widget) => widget.data).take(25).toList()}');
    final initialY = tester.getTopLeft(label).dy;
    final gesture = await tester.startGesture(const Offset(260, 440));
    await gesture.moveBy(const Offset(0, -120));
    await tester.pump();
    expect(tester.getTopLeft(label).dy, lessThan(initialY - 30));

    await gesture.up();
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 220));
    expect(find.text('Choose an answer before continuing.'), findsOneWidget);
    expect(tester.getTopLeft(label).dy, closeTo(initialY, 2));
    await tester.pump(const Duration(milliseconds: 1300));
    await tester.pump(const Duration(milliseconds: 220));
    expect(find.text('Choose an answer before continuing.'), findsNothing);
    expect(label, findsOneWidget);
  });
}
