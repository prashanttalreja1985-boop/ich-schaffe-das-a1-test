import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('expanded curriculum has ordered lessons, phases, and valid quizzes',
      () async {
    final raw = await rootBundle.loadString('assets/starter_content.json');
    final curriculum = Curriculum.fromJson(jsonDecode(raw));
    expect(curriculum.activities.length, greaterThan(1400));
    final lessonNumbers = curriculum.activities.map((a) => a.lessonNumber).toList();
    expect(lessonNumbers, orderedEquals([...lessonNumbers]..sort()));
    expect(lessonNumbers.toSet().length, 10);
    expect(
      curriculum.activities
          .where((a) => a.cardNumber == 1)
          .map((a) => a.lessonTitle)
          .toList(),
      [
        'Start, Sounds and Introductions',
        'People, Nouns and Articles',
        'Verbs, Sentences and Daily Routines',
        'Time, Dates and Appointments',
        'Food, Shopping and Home',
        'City, Directions and Travel',
        'Work, Study, Free Time and Plans',
        'Clothes, Health, Weather and Description',
        'Past Events and Written Communication',
        'Requests, Instructions and A1 Review',
      ],
    );
    expect(curriculum.activities.map((a) => a.slug).toSet().length, 1406);
    for (final number in lessonNumbers.toSet()) {
      final lessonActivities = curriculum.activities
          .where((a) => a.lessonNumber == number)
          .toList();
      final phases = lessonActivities
          .map((a) => a.kind)
          .toList();
      expect(lessonActivities.map((a) => a.cardNumber),
          orderedEquals(List.generate(lessonActivities.length, (i) => i + 1)));
      expect(lessonActivities.every(
          (a) => a.lessonCardCount == lessonActivities.length), isTrue);
      expect(phases, containsAll(['grammar', 'vocabulary', 'quiz']));
      expect(phases, orderedEquals([...phases]..sort((a, b) =>
        ['grammar', 'vocabulary', 'quiz'].indexOf(a).compareTo(
          ['grammar', 'vocabulary', 'quiz'].indexOf(b)))));
    }
    for (final activity in curriculum.activities.where((a) => a.kind == 'quiz')) {
      final options = activity.payload['options'] as List<dynamic>;
      final answer = activity.payload['answer'] as int;
      expect(answer, inInclusiveRange(0, options.length - 1));
      expect(options.toSet().length, options.length);
    }
  });

  test('A1+ revision is a separate 14-lesson continuation after A1', () async {
    final a1 = Curriculum.fromJson(jsonDecode(
        await rootBundle.loadString('assets/starter_content.json')));
    final a1Plus = Curriculum.fromJson(jsonDecode(
        await rootBundle.loadString('assets/a1_plus_content.json')));
    expect(a1Plus.slug, isNot(a1.slug));
    expect(a1Plus.activities.length, greaterThan(100));
    expect(a1Plus.activities.map((a) => a.lessonNumber).toSet().length, 14);
    expect(a1Plus.activities.map((a) => a.slug).toSet().intersection(
        a1.activities.map((a) => a.slug).toSet()), isEmpty);
  });

  test('lesson numbering starts at 1 even if the source rows arrive unordered',
      () async {
    final raw = jsonDecode(
        await rootBundle.loadString('assets/starter_content.json'))
        as Map<String, dynamic>;
    final unordered = Map<String, dynamic>.from(raw)
      ..['lessons'] = (raw['lessons'] as List<dynamic>).reversed.toList();
    final curriculum = Curriculum.fromJson(unordered);
    expect(curriculum.activities.first.lessonNumber, 1);
    expect(curriculum.activities.first.slug, 'greetings-grammar-1');
    expect(curriculum.activities.last.lessonNumber, 10);
  });
}
