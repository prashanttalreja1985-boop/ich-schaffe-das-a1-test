import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';
import 'package:ich_schaffe_das/visual_scenes.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('every existing A1 and A1+ card has a cutout scene', () async {
    final packaged = (await AssetManifest.loadFromAssetBundle(rootBundle))
        .listAssets().toSet();
    for (final asset in ['assets/starter_content.json',
      'assets/a1_plus_content.json']) {
      final book = Curriculum.fromJson(jsonDecode(await rootBundle.loadString(asset)));
      final scenes = await VisualSceneStore.load(book.slug);
      expect(scenes.keys.toSet(),
          book.activities.map((activity) => activity.slug).toSet());
      for (final activity in book.activities) {
        final scene = scenes[activity.slug]!;
        expect(scene.actorFrames, hasLength(4));
        expect(scene.caption, isNotEmpty);
        for (final file in scene.files) {
          expect(packaged, contains('assets/visuals/$file'));
        }
        if (activity.kind == 'quiz') {
          expect((activity.payload['question'] as String)
              .replaceAll(RegExp(r'\s+'), ' ').trim(), startsWith(scene.caption));
        }
      }
    }
  });
}
