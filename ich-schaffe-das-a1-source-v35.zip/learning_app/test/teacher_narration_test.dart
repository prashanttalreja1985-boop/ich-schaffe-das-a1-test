import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';
import 'package:ich_schaffe_das/teacher_narration.dart';
import 'package:ich_schaffe_das/teacher_portrait.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'the first twenty A1 cards have matching teacher scripts and audio',
    () async {
      final course = Curriculum.fromJson(
        jsonDecode(await rootBundle.loadString('assets/starter_content.json')),
      );
      final narrations = await TeacherNarrationStore.load(course.slug);
      final expected = course.activities
          .take(20)
          .map((card) => card.slug)
          .toSet();
      expect(narrations.keys.toSet(), expected);
      final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
      for (final narration in narrations.values) {
        expect(narration.script.length, greaterThan(170));
        expect(
          manifest.listAssets().contains('assets/${narration.audioAsset}'),
          isTrue,
          reason: narration.audioAsset,
        );
      }
      expect(
        await TeacherNarrationStore.load('ich-schaffe-das-a1-plus'),
        isEmpty,
      );
    },
  );

  test('six supplied teacher portraits cycle across cards', () async {
    final portraits = await TeacherPortraitStore.load();
    final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
    for (var index = 0; index < 12; index++) {
      final portrait = portraits.forCard('card-$index', index);
      expect(portrait, isNotNull);
      expect(manifest.listAssets().contains(portrait!.asset), isTrue);
      expect(portrait.mouthX, inInclusiveRange(0.0, 1.0));
      expect(portrait.mouthY, inInclusiveRange(0.0, 1.0));
    }
    expect(
      portraits.forCard('first', 0)?.id,
      portraits.forCard('seventh', 6)?.id,
    );
  });
}
