"""One-time Kokoro batch for the first twenty A1 teacher narrations.

Run on the existing ClipStudio pod that has kokoro-onnx, soundfile, and ffmpeg.
The generated MP3s are bundled with the app; no TTS service runs in the app.
"""

import argparse
import json
from pathlib import Path
import subprocess

import onnxruntime as ort
import soundfile as sf
from kokoro_onnx import Kokoro


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scripts", type=Path, required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--count", type=int, default=20)
    args = parser.parse_args()

    cards = json.loads(args.scripts.read_text(encoding="utf-8"))["cards"]
    assert len(cards) == 20
    args.output.mkdir(parents=True, exist_ok=True)
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    session = ort.InferenceSession(
        str(args.model_dir / "kokoro-v1.0.onnx"),
        sess_options=options,
        providers=["CPUExecutionProvider"],
    )
    voice = Kokoro.from_session(session, str(args.model_dir / "voices-v1.0.bin"))
    for card in cards[: args.count]:
        number = card["number"]
        output = args.output / f"a1_{number:02d}.mp3"
        if output.exists() and output.stat().st_size > 1000:
            print(f"{number:02d}: kept {output}", flush=True)
            continue
        samples, rate = voice.create(
            card["script"], voice="af_heart", speed=1.04, lang="en-us"
        )
        temporary = output.with_suffix(".wav")
        sf.write(temporary, samples, rate)
        subprocess.run(
            [
                "ffmpeg", "-v", "error", "-y", "-i", str(temporary),
                "-ac", "1", "-ar", "24000", "-b:a", "64k", str(output),
            ],
            check=True,
        )
        temporary.unlink()
        print(f"{number:02d}: {output.stat().st_size} bytes", flush=True)


if __name__ == "__main__":
    main()
