import 'dart:async';
import 'dart:convert';
import 'dart:math' show Random, max, min;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'lexicon.dart';
import 'teacher_narration.dart';
import 'teacher_portrait.dart';
part 'auth_gate.dart';

const _supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const _supabaseKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
const _googleRedirect = 'de.ichschaffedas.a1://login-callback/';
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (_supabaseUrl.isNotEmpty && _supabaseKey.isNotEmpty) {
    await Supabase.initialize(url: _supabaseUrl, publishableKey: _supabaseKey);
  }
  runApp(const LearningApp());
}

class Activity {
  const Activity({
    required this.slug,
    required this.kind,
    required this.title,
    required this.lessonTitle,
    required this.lessonNumber,
    required this.cardNumber,
    required this.lessonCardCount,
    required this.payload,
  });

  final String slug;
  final String kind;
  final String title;
  final String lessonTitle;
  final int lessonNumber;
  final int cardNumber;
  final int lessonCardCount;
  final Map<String, dynamic> payload;

  factory Activity.fromJson(
    Map<String, dynamic> json,
    String lessonTitle,
    int lessonNumber,
    int cardNumber,
    int lessonCardCount,
  ) {
    return Activity(
      slug: json['slug'] as String,
      kind: json['kind'] as String,
      title: json['title'] as String,
      lessonTitle: lessonTitle,
      lessonNumber: lessonNumber,
      cardNumber: cardNumber,
      lessonCardCount: lessonCardCount,
      payload: json,
    );
  }
}

class Curriculum {
  const Curriculum(this.title, this.edition, this.slug, this.activities);

  final String title;
  final String edition;
  final String slug;
  final List<Activity> activities;

  factory Curriculum.fromJson(Map<String, dynamic> data) {
    final book = data['book'] as Map<String, dynamic>;
    final activities = <Activity>[];
    final lessons =
        (data['lessons'] as List<dynamic>).cast<Map<String, dynamic>>()
          ..sort((a, b) => (a['number'] as int).compareTo(b['number'] as int));
    for (final lesson in lessons) {
      final row = lesson;
      final lessonActivities = row['activities'] as List<dynamic>;
      for (var index = 0; index < lessonActivities.length; index++) {
        activities.add(
          Activity.fromJson(
            lessonActivities[index] as Map<String, dynamic>,
            row['title'] as String,
            row['number'] as int,
            index + 1,
            lessonActivities.length,
          ),
        );
      }
    }
    return Curriculum(
      book['title'] as String,
      book['edition'] as String,
      book['slug'] as String,
      activities,
    );
  }
}

class LearningStore {
  LearningStore(this.courseAsset, this.bookSlug, this.profileKey);

  final String courseAsset;
  final String bookSlug;
  final String profileKey;

  SupabaseClient? get _client => _supabaseUrl.isEmpty || _supabaseKey.isEmpty
      ? null
      : Supabase.instance.client;

  Future<Curriculum> load() async {
    final sample = await rootBundle.loadString(courseAsset);
    final fallback = Curriculum.fromJson(
      jsonDecode(sample) as Map<String, dynamic>,
    );
    final client = _client;
    if (client == null) return fallback;
    try {
      final book = await client
          .from('learning_books')
          .select('id,slug,title,edition,level')
          .eq('slug', bookSlug)
          .single();
      final lessons = await client
          .from('learning_lessons')
          .select('id,slug,number,title,goal')
          .eq('book_id', book['id'])
          .order('number');
      final lessonIds = lessons.map((lesson) => lesson['id']).toList();
      final rows = <Map<String, dynamic>>[];
      for (var offset = 0; ; offset += 1000) {
        final page = await client
            .from('learning_activities')
            .select('lesson_id,slug,kind,title,payload,sequence_number')
            .inFilter('lesson_id', lessonIds)
            .order('lesson_id')
            .order('sequence_number')
            .range(offset, offset + 999);
        rows.addAll(page);
        if (page.length < 1000) break;
      }
      final lessonData = lessons.map((lesson) {
        final activities = rows
            .where((row) => row['lesson_id'] == lesson['id'])
            .map(
              (row) => {
                ...(row['payload'] as Map<String, dynamic>),
                'slug': row['slug'],
                'kind': row['kind'],
                'title': row['title'],
              },
            )
            .toList();
        return {...lesson, 'activities': activities};
      }).toList();
      return Curriculum.fromJson({'book': book, 'lessons': lessonData});
    } catch (_) {
      return fallback;
    }
  }

  Future<Lexicon> loadLexicon() async {
    final bundled = jsonDecode(
      await rootBundle.loadString('assets/lexicon.json'),
    ) as Map<String, dynamic>;
    final fallback = Lexicon.fromJson(bundled, bookSlug);
    final client = _client;
    if (client == null) return fallback;
    try {
      final rows = await client
          .from('learning_lexicon')
          .select('book_slug,lemma,word_type,meaning_en,article,forms')
          .eq('book_slug', bookSlug);
      if (rows.isEmpty) return fallback;
      return Lexicon(rows.map((row) => Lexeme.fromJson(row)));
    } catch (_) {
      // A bundled lexicon keeps the course usable before the optional table is
      // installed or published in Supabase.
      return fallback;
    }
  }

  Future<Set<String>> completed(Curriculum curriculum) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'done:$profileKey:${curriculum.slug}';
    final done = prefs.getStringList(key)?.toSet() ?? <String>{};
    final resetReady = await syncPendingProgressReset();
    final client = _client;
    if (resetReady && client != null && client.auth.currentUser != null) {
      try {
        final userId = client.auth.currentUser!.id;
        await _syncAnswers(curriculum, prefs, client, userId);
        final rows = <Map<String, dynamic>>[];
        for (var offset = 0; ; offset += 1000) {
          final page = await client
              .from('learner_activity_progress')
              .select('activity_slug')
              .eq('user_id', userId)
              .eq('profile_key', profileKey)
              .eq('book_slug', curriculum.slug)
              .order('activity_slug')
              .range(offset, offset + 999);
          rows.addAll(page);
          if (page.length < 1000) break;
        }
        final remoteDone = rows
            .map((row) => row['activity_slug'] as String)
            .toSet();
        done.addAll(remoteDone);
        await prefs.setStringList(key, done.toList());
        final validSlugs = curriculum.activities.map((a) => a.slug).toSet();
        final pending = done.intersection(validSlugs).difference(remoteDone);
        if (pending.isNotEmpty) {
          await client.from('learner_activity_progress').upsert([
            for (final slug in pending)
              {
                'user_id': userId,
                'profile_key': profileKey,
                'book_slug': curriculum.slug,
                'activity_slug': slug,
              },
          ], onConflict: 'user_id,profile_key,book_slug,activity_slug');
        }
      } catch (_) {
        // Keep local progress available while the database is offline.
      }
    }
    return done;
  }

  Future<bool> resetProfileProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('reset-pending:$profileKey', true);
    final client = _client;
    final user = client?.auth.currentUser;
    var synced = false;
    if (client != null && user != null) {
      try {
        await _deleteRemoteProgress(client, user.id);
        await prefs.remove('reset-pending:$profileKey');
        synced = true;
      } catch (_) {
        // The reset tombstone retries cloud deletion when this profile returns.
      }
    }
    for (final key in prefs.getKeys().where(
      (key) =>
          key.startsWith('done:$profileKey:') ||
          key.startsWith('answers:$profileKey:') ||
          key.startsWith('game-level:$profileKey:'),
    )) {
      await prefs.remove(key);
    }
    if (prefs.getString('legacy_progress_owner')?.toLowerCase() == profileKey) {
      await prefs.remove('done:original-a1-starter');
      await prefs.setString('legacy_progress_owner', profileKey);
    }
    return synced;
  }

  Future<bool> syncPendingProgressReset() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool('reset-pending:$profileKey') != true) return true;
    final client = _client;
    final user = client?.auth.currentUser;
    if (client == null || user == null) return false;
    try {
      await _deleteRemoteProgress(client, user.id);
      await prefs.remove('reset-pending:$profileKey');
      return true;
    } catch (_) {
      // Retry the tombstone at the next profile session.
      return false;
    }
  }

  Future<void> _deleteRemoteProgress(
    SupabaseClient client,
    String userId,
  ) async {
    for (final table in [
      'learner_activity_progress',
      'learner_answers',
      'learner_game_progress',
    ]) {
      await client
          .from(table)
          .delete()
          .eq('user_id', userId)
          .eq('profile_key', profileKey);
    }
  }

  Future<Set<String>> flagged(Curriculum curriculum) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs
            .getStringList('flagged:$profileKey:${curriculum.slug}')
            ?.toSet() ??
        <String>{};
  }

  Future<bool> flag(Curriculum curriculum, Activity activity) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'flagged:$profileKey:${curriculum.slug}';
    final local = prefs.getStringList(key) ?? <String>[];
    if (!local.contains(activity.slug)) {
      local.add(activity.slug);
      await prefs.setStringList(key, local);
    }
    final client = _client;
    if (client == null) return false;
    try {
      await client
          .from('learning_content_flags')
          .upsert(
            {'book_slug': curriculum.slug, 'activity_slug': activity.slug},
            onConflict: 'book_slug,activity_slug',
            ignoreDuplicates: true,
          );
      return true;
    } catch (_) {
      // Keep the local flag if network access or the review table is unavailable.
      return false;
    }
  }

  Future<bool> complete(
    Curriculum curriculum,
    Activity activity,
    Set<String> done,
    int? selectedAnswer, {
    bool answerSynced = true,
  }) async {
    final client = _client;
    final prefs = await SharedPreferences.getInstance();
    if (selectedAnswer != null &&
        selectedAnswer != activity.payload['answer']) {
      return false;
    }
    done.add(activity.slug);
    await prefs.setStringList(
      'done:$profileKey:${curriculum.slug}',
      done.toList(),
    );
    if (answerSynced && client != null && client.auth.currentUser != null) {
      try {
        final userId = client.auth.currentUser!.id;
        await client.from('learner_activity_progress').upsert({
          'user_id': userId,
          'profile_key': profileKey,
          'book_slug': curriculum.slug,
          'activity_slug': activity.slug,
          'completed_at': DateTime.now().toUtc().toIso8601String(),
        }, onConflict: 'user_id,profile_key,book_slug,activity_slug');
      } catch (_) {
        // A later session retries syncing local completion records.
      }
    }
    return true;
  }

  Future<bool> recordAnswer(
    Curriculum curriculum,
    Activity activity,
    int answer,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'answers:$profileKey:${curriculum.slug}';
    final attempts = prefs.getStringList(key) ?? <String>[];
    attempts.add(
      jsonEncode({
        'attempt_key':
            '${DateTime.now().microsecondsSinceEpoch}-'
            '${Random.secure().nextInt(1 << 32)}',
        'activity_slug': activity.slug,
        'selected_answer': answer,
        'is_correct': answer == activity.payload['answer'],
        'answered_at': DateTime.now().toUtc().toIso8601String(),
      }),
    );
    await prefs.setStringList(key, attempts);
    final client = _client;
    final user = client?.auth.currentUser;
    if (client == null || user == null) return false;
    try {
      await _syncAnswers(curriculum, prefs, client, user.id);
      return true;
    } catch (_) {
      // Attempts stay queued on device until the next connected session.
      return false;
    }
  }

  Future<void> _syncAnswers(
    Curriculum curriculum,
    SharedPreferences prefs,
    SupabaseClient client,
    String userId,
  ) async {
    final key = 'answers:$profileKey:${curriculum.slug}';
    final attempts = prefs.getStringList(key) ?? <String>[];
    final pending = <Map<String, dynamic>>[];
    var changed = false;
    for (var i = 0; i < attempts.length; i++) {
      final attempt = jsonDecode(attempts[i]) as Map<String, dynamic>;
      if (attempt['attempt_key'] == null) {
        attempt['attempt_key'] =
            '$userId:legacy:$profileKey:'
            '${curriculum.slug}:$i';
        attempts[i] = jsonEncode(attempt);
        changed = true;
      }
      pending.add({
        'user_id': userId,
        'profile_key': profileKey,
        'book_slug': curriculum.slug,
        'activity_slug': attempt['activity_slug'],
        'selected_answer': attempt['selected_answer'],
        'is_correct': attempt['is_correct'],
        'answered_at': attempt['answered_at'],
        'attempt_key': attempt['attempt_key'],
      });
    }
    if (changed) await prefs.setStringList(key, attempts);
    for (var offset = 0; offset < pending.length; offset += 100) {
      await client
          .from('learner_answers')
          .upsert(
            pending.skip(offset).take(100).toList(),
            onConflict: 'attempt_key',
            ignoreDuplicates: true,
          );
    }
  }

  Future<List<Map<String, dynamic>>> profilePoints() async {
    final client = _client;
    if (client == null) return [];
    final user = client.auth.currentUser;
    if (user == null) return [];
    try {
      final rows = await client
          .from('learner_profile_points')
          .select(
            'profile_key,language_level,lifetime_points,current_month_points',
          )
          .eq('user_id', user.id);
      return rows;
    } catch (_) {
      return [];
    }
  }
}

class LearningApp extends StatelessWidget {
  const LearningApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ich schaffe das',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF10182A),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFF5C85B),
          brightness: Brightness.dark,
        ),
        textTheme: ThemeData.dark().textTheme.apply(fontFamily: 'Arial'),
      ),
      home: const AuthGate(),
    );
  }
}

class LearningScreen extends StatefulWidget {
  const LearningScreen({
    super.key,
    required this.courseAsset,
    required this.bookSlug,
    required this.profileKey,
    required this.profileName,
    this.enableTeacherAudio = true,
    this.enableTeacherPortrait = true,
    this.onCourseCompleted,
    this.onSettingsChanged,
  });

  final String courseAsset;
  final String bookSlug;
  final String profileKey;
  final String profileName;
  final bool enableTeacherAudio;
  final bool enableTeacherPortrait;
  final VoidCallback? onCourseCompleted;
  final VoidCallback? onSettingsChanged;

  @override
  State<LearningScreen> createState() => _LearningScreenState();
}

class _LearningScreenState extends State<LearningScreen> {
  late final LearningStore _store;
  final _controller = PageController();
  Curriculum? _curriculum;
  Lexicon? _lexicon;
  Map<String, TeacherNarration> _narrations = {};
  TeacherPortraitStore? _portraits;
  AudioPlayer? _teacherPlayer;
  bool _teacherPlaying = false;
  int _voiceRequest = 0;
  Set<String> _done = {};
  Set<String> _flagged = {};
  int _index = 0;
  int? _selected;
  DateTime? _correctSelectedAt;
  Future<bool>? _answerWrite;
  bool _busy = false;
  Offset? _swipeStart;
  int? _activityDragIndex;
  double _activityDragOffset = 0;
  bool _activityDragging = false;
  String? _bottomHint;
  Timer? _bottomHintTimer;
  String? _error;

  @override
  void initState() {
    super.initState();
    _store = LearningStore(
      widget.courseAsset,
      widget.bookSlug,
      widget.profileKey,
    );
    _load();
  }

  AudioPlayer _audioPlayer() {
    final existing = _teacherPlayer;
    if (existing != null) return existing;
    final player = AudioPlayer();
    player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _teacherPlaying = false);
    });
    _teacherPlayer = player;
    return player;
  }

  Future<void> _playNarration(int index, {bool toggle = false}) async {
    if (!widget.enableTeacherAudio) return;
    final request = ++_voiceRequest;
    final curriculum = _curriculum;
    if (curriculum == null || index >= curriculum.activities.length) return;
    final narration = _narrations[curriculum.activities[index].slug];
    final player = narration == null ? _teacherPlayer : _audioPlayer();
    if (player == null) return;
    if (toggle && _teacherPlaying) {
      await player.pause();
      if (mounted && request == _voiceRequest) {
        setState(() => _teacherPlaying = false);
      }
      return;
    }
    if (toggle && player.state == PlayerState.paused && narration != null) {
      await player.resume();
      if (mounted && request == _voiceRequest) {
        setState(() => _teacherPlaying = true);
      }
      return;
    }
    await player.stop();
    if (mounted && request == _voiceRequest) {
      setState(() => _teacherPlaying = false);
    }
    if (narration == null || !mounted || request != _voiceRequest) return;
    try {
      await player.play(AssetSource(narration.audioAsset));
      if (mounted && request == _voiceRequest) {
        setState(() => _teacherPlaying = true);
      }
    } catch (_) {
      if (mounted && request == _voiceRequest) {
        _showBottomHint('Teacher audio could not play.');
      }
    }
  }

  void _showBottomHint(String message) {
    _bottomHintTimer?.cancel();
    setState(() => _bottomHint = message);
    _bottomHintTimer = Timer(const Duration(milliseconds: 1150), () {
      if (mounted) setState(() => _bottomHint = null);
    });
  }

  void _releaseActivityDrag() {
    if (!_activityDragging && _activityDragOffset == 0) return;
    setState(() {
      _activityDragging = false;
      _activityDragOffset = 0;
    });
  }

  Future<void> _load() async {
    try {
      final curriculum = await _store.load();
      final lexicon = await _store.loadLexicon();
      final narrations = await TeacherNarrationStore.load(widget.bookSlug);
      final portraits = widget.enableTeacherPortrait
          ? await TeacherPortraitStore.load()
          : null;
      if (curriculum.activities.isEmpty) {
        throw StateError('This book has no published activities yet.');
      }
      final done = await _store.completed(curriculum);
      final flagged = await _store.flagged(curriculum);
      var index = curriculum.activities.indexWhere(
        (a) => !done.contains(a.slug),
      );
      if (index < 0) index = curriculum.activities.length - 1;
      if (!mounted) return;
      setState(() {
        _curriculum = curriculum;
        _lexicon = lexicon;
        _narrations = narrations;
        _portraits = portraits;
        _done = done;
        _flagged = flagged;
        _index = index;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_controller.hasClients) {
          _controller.jumpToPage(index);
        }
        unawaited(_playNarration(index));
      });
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    }
  }

  Future<void> _complete(Activity activity, {bool autoCorrect = false}) async {
    final curriculum = _curriculum!;
    final selected = _selected;
    if (activity.kind == 'quiz' &&
        selected == null &&
        !_done.contains(activity.slug)) {
      _showBottomHint('Choose an answer before continuing.');
      return;
    }
    if (_busy) return;
    final startingIndex = _index;
    setState(() => _busy = true);
    try {
      final answerSynced = activity.kind == 'quiz'
          ? await (_answerWrite ?? Future<bool>.value(false))
          : true;
      final passed = await _store.complete(
        curriculum,
        activity,
        _done,
        selected,
        answerSynced: answerSynced,
      );
      if (!mounted) return;
      if (!passed) {
        _showBottomHint('Try another answer to unlock the next card.');
        return;
      }
      if (autoCorrect) {
        final selectedAt = _correctSelectedAt ?? DateTime.now();
        final remaining =
            const Duration(milliseconds: 500) -
            DateTime.now().difference(selectedAt);
        if (remaining > Duration.zero) await Future.delayed(remaining);
        if (!mounted || _index != startingIndex) return;
        setState(() {
          _activityDragIndex = startingIndex;
          _activityDragging = false;
          _activityDragOffset = 30;
        });
        await Future.delayed(const Duration(milliseconds: 160));
        if (!mounted) return;
      }
      if (widget.bookSlug == 'original-a1-starter' &&
          _done.length >= curriculum.activities.length) {
        widget.onCourseCompleted?.call();
        return;
      }
      setState(() {});
      if (_index < curriculum.activities.length - 1) {
        await _controller.nextPage(
          duration: Duration(milliseconds: autoCorrect ? 420 : 330),
          curve: autoCorrect ? Curves.easeInCubic : Curves.easeOutCubic,
        );
      }
      if (mounted) {
        setState(() {
          _selected = null;
          _correctSelectedAt = null;
          _answerWrite = null;
          _activityDragOffset = 0;
          _activityDragIndex = null;
        });
      }
    } catch (error) {
      if (mounted) {
        _showBottomHint('Could not save progress: $error');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _flag(Activity activity) async {
    if (_flagged.contains(activity.slug)) return;
    setState(() {
      _flagged.add(activity.slug);
    });
    final synced = await _store.flag(_curriculum!, activity);
    if (mounted) {
      _showBottomHint(
        synced
            ? 'Flagged for review.'
            : 'Saved on this device; could not sync the review flag.',
      );
    }
  }

  void _setCurrentIndex(int index) {
    if (!mounted || index < 0 || index >= _curriculum!.activities.length) {
      return;
    }
    setState(() {
      _index = index;
      _selected = null;
      _correctSelectedAt = null;
      _answerWrite = null;
    });
    unawaited(_playNarration(index));
  }

  Future<void> _openSettings() async {
    _voiceRequest++;
    await _teacherPlayer?.stop();
    if (!mounted) return;
    setState(() => _teacherPlaying = false);
    final result = await Navigator.of(context).push<_LearningSettingsResult>(
      MaterialPageRoute(
        builder: (_) => _LearningSettingsScreen(
          accountId: widget.profileKey,
          accountName: widget.profileName,
        ),
      ),
    );
    if (!mounted) return;
    if (result == null) return;
    widget.onSettingsChanged?.call();
  }

  @override
  void dispose() {
    _bottomHintTimer?.cancel();
    _voiceRequest++;
    final player = _teacherPlayer;
    if (player != null) unawaited(player.dispose());
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.cloud_off, size: 48),
                  const SizedBox(height: 18),
                  const Text(
                    'Could not load the course',
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  Text(_error!, textAlign: TextAlign.center),
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: () {
                      setState(() => _error = null);
                      _load();
                    },
                    child: const Text('Try again'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }
    final curriculum = _curriculum;
    if (curriculum == null || _lexicon == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final activities = curriculum.activities;
    final current = activities[_index];
    final unlockIndex = activities.indexWhere((a) => !_done.contains(a.slug));
    final maxIndex = unlockIndex < 0 ? activities.length - 1 : unlockIndex;
    final atLearningFrontier =
        _index == maxIndex && !_done.contains(activities[maxIndex].slug);
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: Listener(
                onPointerDown: (event) {
                  _swipeStart = event.position;
                  if (atLearningFrontier) {
                    _activityDragIndex = _index;
                  }
                },
                onPointerMove: (event) {
                  final start = _swipeStart;
                  if (start == null || !atLearningFrontier || _busy) return;
                  final upwardDistance = start.dy - event.position.dy;
                  if (upwardDistance <= 0 && !_activityDragging) return;
                  final offset = -min(96.0, max(0.0, upwardDistance * 0.55));
                  if (offset == _activityDragOffset) return;
                  setState(() {
                    _activityDragging = true;
                    _activityDragOffset = offset;
                  });
                },
                onPointerCancel: (_) {
                  _swipeStart = null;
                  _releaseActivityDrag();
                },
                onPointerUp: (event) {
                  final start = _swipeStart;
                  _swipeStart = null;
                  _releaseActivityDrag();
                  if (start != null &&
                      atLearningFrontier &&
                      !_busy &&
                      start.dy - event.position.dy > 56) {
                    _complete(activities[_index]);
                  }
                },
                child: PageView.builder(
                  controller: _controller,
                  scrollDirection: Axis.vertical,
                  physics: const ClampingScrollPhysics(),
                  itemCount: maxIndex + 1,
                  onPageChanged: (index) {
                    if (index > maxIndex) {
                      _controller.animateToPage(
                        maxIndex,
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOut,
                      );
                      return;
                    }
                    _setCurrentIndex(index);
                  },
                  itemBuilder: (context, index) {
                    final activity = activities[index];
                    final card = _ActivityCard(
                      activity: activity,
                      lexicon: _lexicon!,
                      narration: _narrations[activity.slug],
                      portrait: _portraits?.forCard(activity.slug, index),
                      teacherPlaying: index == _index && _teacherPlaying,
                      onToggleNarration: () =>
                          _playNarration(index, toggle: true),
                      onReplayNarration: () => _playNarration(index),
                      flagged: _flagged.contains(activity.slug),
                      onFlag: () => _flag(activity),
                      selected: index == _index ? _selected : null,
                      completed: _done.contains(activity.slug),
                      busy: _busy,
                      onSelect: (value) {
                        if (_busy ||
                            _done.contains(activity.slug) ||
                            _selected == value ||
                            _selected == activity.payload['answer']) {
                          return;
                        }
                        setState(() => _selected = value);
                        final previous = _answerWrite;
                        _answerWrite = () async {
                          if (previous != null) await previous;
                          return _store.recordAnswer(
                            curriculum,
                            activity,
                            value,
                          );
                        }();
                        if (value == activity.payload['answer']) {
                          _correctSelectedAt = DateTime.now();
                          _complete(activity, autoCorrect: true);
                        }
                      },
                    );
                    if (index != _activityDragIndex) return card;
                    return AnimatedContainer(
                      duration: _activityDragging
                          ? Duration.zero
                          : const Duration(milliseconds: 170),
                      curve: Curves.easeOutBack,
                      transform: Matrix4.translationValues(
                        0,
                        _activityDragOffset,
                        0,
                      ),
                      child: card,
                    );
                  },
                ),
              ),
            ),
            Positioned(
              top: 8,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 13,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF10182A).withValues(alpha: 0.92),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white12),
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.sizeOf(context).width - 82,
                  ),
                  child: Text(
                    'LESSON ${current.lessonNumber}  ·  '
                    'CARD ${current.cardNumber}/${current.lessonCardCount}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFFF5C85B),
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 8,
              right: 14,
              child: _FloatingControl(
                size: 42,
                onTap: _openSettings,
                child: Text(
                  widget.profileName.trim().isEmpty
                      ? '?'
                      : widget.profileName.trim().substring(0, 1).toUpperCase(),
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFFF5C85B),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 62,
              left: 20,
              right: 20,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: LinearProgressIndicator(
                  value: _done.length / activities.length,
                  minHeight: 4,
                  backgroundColor: Colors.white24,
                  color: const Color(0xFFF5C85B),
                ),
              ),
            ),
            Positioned(
              left: 24,
              right: 24,
              bottom: 22,
              child: IgnorePointer(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 190),
                  transitionBuilder: (child, animation) => SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.25),
                      end: Offset.zero,
                    ).animate(animation),
                    child: FadeTransition(opacity: animation, child: child),
                  ),
                  child: _bottomHint == null
                      ? const SizedBox.shrink(key: ValueKey('hint-empty'))
                      : Container(
                          key: ValueKey(_bottomHint),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 18,
                            vertical: 15,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF5C85B),
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black38,
                                blurRadius: 18,
                                offset: Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Text(
                            _bottomHint!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Color(0xFF172034),
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FloatingControl extends StatelessWidget {
  const _FloatingControl({required this.child, this.onTap, this.size = 40});

  final Widget child;
  final VoidCallback? onTap;
  final double size;

  @override
  Widget build(BuildContext context) => Material(
    color: const Color(0xFF10182A).withValues(alpha: 0.92),
    shape: const CircleBorder(side: BorderSide(color: Colors.white12)),
    child: InkWell(
      customBorder: const CircleBorder(),
      onTap: onTap,
      child: SizedBox(
        width: size,
        height: size,
        child: Center(child: child),
      ),
    ),
  );
}

class _LearningSettingsResult {
  const _LearningSettingsResult();
}

class _LearningSettingsScreen extends StatefulWidget {
  const _LearningSettingsScreen({
    required this.accountId,
    required this.accountName,
  });
  final String accountId;
  final String accountName;

  @override
  State<_LearningSettingsScreen> createState() =>
      _LearningSettingsScreenState();
}

class _LearningSettingsScreenState extends State<_LearningSettingsScreen> {
  List<Map<String, dynamic>> _scores = [];
  List<Map<String, dynamic>> _leaders = [];
  bool _resetting = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final scores = await LearningStore(
      '',
      '',
      widget.accountId,
    ).profilePoints();
    if (mounted) setState(() => _scores = scores);
    try {
      final leaders = await Supabase.instance.client.rpc('monthly_leaderboard');
      if (mounted) {
        setState(
          () => _leaders = (leaders as List).cast<Map<String, dynamic>>(),
        );
      }
    } catch (_) {
      // The account's own points remain available if ranking is offline.
    }
  }

  int _points(String column) => _scores.fold(
    0,
    (sum, row) => sum + ((row[column] as num?)?.toInt() ?? 0),
  );

  Future<void> _close() async {
    if (mounted) Navigator.of(context).pop(const _LearningSettingsResult());
  }

  Future<void> _signOut() async {
    await Supabase.instance.client.auth.signOut();
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _resetProgress() async {
    if (_resetting) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Start from card 1?'),
        content: const Text(
          'This clears your A1 and A1+ completion, answers, and points for this Google account. You can learn every card again.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Keep my progress'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Reset progress'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _resetting = true);
    await LearningStore('', '', widget.accountId).resetProfileProgress();
    if (mounted) Navigator.of(context).pop(const _LearningSettingsResult());
  }

  @override
  Widget build(BuildContext context) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    final now = DateTime.now();
    final email = Supabase.instance.client.auth.currentUser?.email;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _close();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Your settings'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded),
            tooltip: 'Back to course',
            onPressed: _close,
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(
              '${months[now.month - 1]} ${now.year} leaders',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 12),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF1D2940),
                borderRadius: BorderRadius.circular(20),
              ),
              child: _leaders.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.all(18),
                      child: Text('No points earned this month yet.'),
                    )
                  : Column(
                      children: [
                        for (final leader in _leaders)
                          ListTile(
                            leading: CircleAvatar(
                              child: Text('${leader['rank']}'),
                            ),
                            title: Text(leader['label'] as String),
                            trailing: Text(
                              '${leader['points']} pts',
                              style: const TextStyle(
                                color: Color(0xFFF5C85B),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                      ],
                    ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFF1D2940),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.accountName,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (email != null)
                    Text(email, style: const TextStyle(color: Colors.white60)),
                  const SizedBox(height: 10),
                  Text('This month: ${_points('current_month_points')} points'),
                  Text('Lifetime: ${_points('lifetime_points')} points'),
                  for (final row in _scores)
                    Text(
                      '${row['language_level']}: ${row['lifetime_points']} lifetime · '
                      '${row['current_month_points']} this month',
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              onPressed: _resetting ? null : _resetProgress,
              icon: const Icon(Icons.restart_alt_rounded),
              label: Text(
                _resetting
                    ? 'Resetting progress…'
                    : 'Reset progress and start over',
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _signOut,
              icon: const Icon(Icons.logout_rounded),
              label: const Text('Sign out'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActivityCard extends StatelessWidget {
  const _ActivityCard({
    required this.activity,
    required this.lexicon,
    required this.narration,
    required this.portrait,
    required this.teacherPlaying,
    required this.onToggleNarration,
    required this.onReplayNarration,
    required this.flagged,
    required this.onFlag,
    required this.selected,
    required this.completed,
    required this.busy,
    required this.onSelect,
  });

  final Activity activity;
  final Lexicon lexicon;
  final TeacherNarration? narration;
  final TeacherPortraitSpec? portrait;
  final bool teacherPlaying;
  final VoidCallback onToggleNarration;
  final VoidCallback onReplayNarration;
  final bool flagged;
  final VoidCallback onFlag;
  final int? selected;
  final bool completed;
  final bool busy;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final payload = activity.payload;
    final kind = activity.kind;
    final label = switch (kind) {
      'grammar' => 'GRAMMAR',
      'vocabulary' => 'VOCABULARY',
      'quiz' => 'QUICK CHECK',
      _ => kind.toUpperCase(),
    };
    final icon = switch (kind) {
      'grammar' => Icons.menu_book_rounded,
      'vocabulary' => Icons.translate_rounded,
      'quiz' => Icons.psychology_alt_rounded,
      _ => Icons.auto_stories,
    };
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1D2940),
        borderRadius: BorderRadius.circular(26),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(26, 98, 26, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5C85B).withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Icon(icon, color: const Color(0xFFF5C85B)),
                ),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: const TextStyle(
                    color: Color(0xFFF5C85B),
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                if (completed)
                  const Icon(Icons.check_circle, color: Color(0xFF70D6AB)),
                IconButton(
                  tooltip: flagged ? 'Flagged for review' : 'Flag this content',
                  onPressed: flagged ? null : onFlag,
                  icon: Icon(
                    flagged ? Icons.flag_rounded : Icons.outlined_flag,
                    color: flagged ? const Color(0xFFFFB684) : Colors.white70,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            LexicalText(
              activity.title,
              lexicon: lexicon,
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w800,
                height: 1.1,
              ),
            ),
            if (portrait != null) ...[
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: TeacherPortrait(
                  key: ValueKey('teacher-${portrait!.id}'),
                  spec: portrait!,
                  speaking: teacherPlaying,
                ),
              ),
            ],
            if (narration != null) ...[
              const SizedBox(height: 15),
              Row(
                children: [
                  FilledButton.tonalIcon(
                    onPressed: onToggleNarration,
                    icon: Icon(
                      teacherPlaying
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                    ),
                    label: Text(
                      teacherPlaying ? 'Pause teacher' : 'Hear your teacher',
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    tooltip: 'Replay teacher from the start',
                    onPressed: onReplayNarration,
                    icon: const Icon(Icons.replay_rounded),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 18),
            Expanded(
              child: SingleChildScrollView(
                physics: const ClampingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    switch (kind) {
                      'grammar' => _GrammarBody(
                        payload: payload,
                        lexicon: lexicon,
                      ),
                      'vocabulary' => _VocabularyBody(
                        payload: payload,
                        lexicon: lexicon,
                      ),
                      'quiz' => _QuizBody(
                        payload: payload,
                        selected: selected,
                        onSelect: onSelect,
                        lexicon: lexicon,
                      ),
                      _ => LexicalText(
                        payload['body']?.toString() ?? '',
                        lexicon: lexicon,
                      ),
                    },
                    if (narration != null) ...[
                      const SizedBox(height: 24),
                      Material(
                        color: Colors.transparent,
                        child: ExpansionTile(
                          tilePadding: EdgeInsets.zero,
                          title: const Text('Teacher transcript'),
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(bottom: 16),
                              child: Text(narration!.script),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GrammarBody extends StatelessWidget {
  const _GrammarBody({required this.payload, required this.lexicon});
  final Map<String, dynamic> payload;
  final Lexicon lexicon;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      LexicalText(
        payload['body']?.toString() ?? '',
        lexicon: lexicon,
        style: const TextStyle(fontSize: 18, height: 1.55),
      ),
      if (payload['example'] != null) ...[
        const SizedBox(height: 25),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.07),
            borderRadius: BorderRadius.circular(17),
          ),
          child: LexicalText(
            payload['example'].toString(),
            lexicon: lexicon,
            style: const TextStyle(fontSize: 17, color: Color(0xFFF5C85B)),
          ),
        ),
      ],
    ],
  );
}

class _VocabularyBody extends StatelessWidget {
  const _VocabularyBody({required this.payload, required this.lexicon});
  final Map<String, dynamic> payload;
  final Lexicon lexicon;

  @override
  Widget build(BuildContext context) {
    final items = payload['items'] as List<dynamic>? ?? [];
    return Column(
      children: items.map((entry) {
        final item = entry as Map<String, dynamic>;
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: LexicalText(
                      item['de'].toString(),
                      lexicon: lexicon,
                      style: const TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Text(
                    item['en'].toString(),
                    style: const TextStyle(color: Color(0xFFF5C85B)),
                  ),
                ],
              ),
              const SizedBox(height: 7),
              LexicalText(
                item['example'].toString(),
                lexicon: lexicon,
                style: const TextStyle(color: Colors.white60),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _QuizBody extends StatelessWidget {
  const _QuizBody({
    required this.payload,
    required this.selected,
    required this.onSelect,
    required this.lexicon,
  });
  final Map<String, dynamic> payload;
  final int? selected;
  final ValueChanged<int> onSelect;
  final Lexicon lexicon;

  @override
  Widget build(BuildContext context) {
    final options = payload['options'] as List<dynamic>? ?? [];
    final correct = payload['answer'] as int;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        LexicalText(
          payload['question'].toString(),
          lexicon: lexicon,
          style: const TextStyle(fontSize: 20, height: 1.4),
        ),
        const SizedBox(height: 20),
        for (var i = 0; i < options.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              onTap: () => onSelect(i),
              borderRadius: BorderRadius.circular(15),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(17),
                decoration: BoxDecoration(
                  color: selected == i
                      ? const Color(0xFFF5C85B).withValues(alpha: 0.18)
                      : Colors.white.withValues(alpha: 0.06),
                  border: Border.all(
                    color: selected == i
                        ? const Color(0xFFF5C85B)
                        : Colors.white12,
                  ),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: LexicalText(
                  options[i].toString(),
                  lexicon: lexicon,
                  style: const TextStyle(fontSize: 17),
                ),
              ),
            ),
          ),
        if (selected != null) ...[
          const SizedBox(height: 13),
          Text(
            selected == correct
                ? 'Correct! ✓'
                : 'Not quite. Correct: ${options[correct]}',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
              color: selected == correct
                  ? const Color(0xFF70D6AB)
                  : const Color(0xFFFFB684),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            payload['explanation']?.toString() ?? '',
            style: const TextStyle(color: Colors.white70),
          ),
        ],
      ],
    );
  }
}
