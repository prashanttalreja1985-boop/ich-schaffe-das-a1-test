import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TeacherPortraitSpec {
  const TeacherPortraitSpec({
    required this.id,
    required this.asset,
    required this.mouthX,
    required this.mouthY,
    required this.mouthWidth,
  });

  final String id;
  final String asset;
  final double mouthX;
  final double mouthY;
  final double mouthWidth;

  factory TeacherPortraitSpec.fromJson(Map<String, dynamic> json) {
    double fraction(String key, double fallback) =>
        ((json[key] as num?)?.toDouble() ?? fallback).clamp(0.0, 1.0);
    return TeacherPortraitSpec(
      id: json['id'] as String,
      asset: json['asset'] as String,
      mouthX: fraction('mouth_x', 0.5),
      mouthY: fraction('mouth_y', 0.7),
      mouthWidth: fraction('mouth_width', 0.16),
    );
  }
}

class TeacherPortraitStore {
  static Future<TeacherPortraitStore>? _cache;

  TeacherPortraitStore._(
    this._portraits,
    this._assignments,
    this._cycle,
    this._defaultId,
  );

  final Map<String, TeacherPortraitSpec> _portraits;
  final Map<String, String> _assignments;
  final List<String> _cycle;
  final String? _defaultId;

  static Future<TeacherPortraitStore> load() => _cache ??= _read();

  static Future<TeacherPortraitStore> _read() async {
    final json = jsonDecode(
      await rootBundle.loadString('assets/teacher_portraits.json'),
    ) as Map<String, dynamic>;
    final portraits = <String, TeacherPortraitSpec>{};
    for (final raw in json['portraits'] as List<dynamic>) {
      final spec = TeacherPortraitSpec.fromJson(raw as Map<String, dynamic>);
      if (spec.asset.startsWith('assets/teacher_portraits/')) {
        portraits[spec.id] = spec;
      }
    }
    return TeacherPortraitStore._(
      portraits,
      (json['assignments'] as Map<String, dynamic>).map(
        (key, value) => MapEntry(key, value as String),
      ),
      (json['cycle'] as List<dynamic>).cast<String>(),
      json['default_portrait'] as String?,
    );
  }

  TeacherPortraitSpec? forCard(String slug, int index) {
    final id = _assignments[slug] ??
        (_cycle.isEmpty ? _defaultId : _cycle[index % _cycle.length]);
    return _portraits[id];
  }
}

class TeacherPortrait extends StatefulWidget {
  const TeacherPortrait({
    super.key,
    required this.spec,
    required this.speaking,
  });

  final TeacherPortraitSpec spec;
  final bool speaking;

  @override
  State<TeacherPortrait> createState() => _TeacherPortraitState();
}

class _TeacherPortraitState extends State<TeacherPortrait>
    with SingleTickerProviderStateMixin {
  late final AnimationController _mouth = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 520),
  );

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(covariant TeacherPortrait oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.speaking != widget.speaking) _sync();
  }

  void _sync() {
    if (widget.speaking) {
      _mouth.repeat();
    } else {
      _mouth.stop();
      _mouth.value = 0;
    }
  }

  @override
  void dispose() {
    _mouth.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Semantics(
    label: widget.speaking ? 'Teacher speaking' : 'Teacher portrait',
    child: ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: SizedBox(
        width: 118,
        height: 118,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(widget.spec.asset, fit: BoxFit.cover),
            AnimatedBuilder(
              animation: _mouth,
              builder: (context, child) => CustomPaint(
                painter: _MouthPainter(
                  x: widget.spec.mouthX,
                  y: widget.spec.mouthY,
                  width: widget.spec.mouthWidth,
                  frame: widget.speaking
                      ? math.min(3, (_mouth.value * 4).floor())
                      : 0,
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class _MouthPainter extends CustomPainter {
  const _MouthPainter({
    required this.x,
    required this.y,
    required this.width,
    required this.frame,
  });

  final double x;
  final double y;
  final double width;
  final int frame;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * x, size.height * y);
    final mouthWidth = size.width * width;
    final heights = [0.12, 0.55, 0.9, 0.35];
    final height = math.max(2.0, mouthWidth * heights[frame]);
    final outline = Paint()
      ..color = const Color(0xFF5E2430)
      ..style = PaintingStyle.fill;
    canvas.drawOval(
      Rect.fromCenter(center: center, width: mouthWidth, height: height),
      outline,
    );
    if (frame == 2) {
      canvas.drawOval(
        Rect.fromCenter(
          center: center.translate(0, height * 0.22),
          width: mouthWidth * 0.52,
          height: height * 0.24,
        ),
        Paint()..color = const Color(0xFFF49AA3),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _MouthPainter oldDelegate) =>
      x != oldDelegate.x ||
      y != oldDelegate.y ||
      width != oldDelegate.width ||
      frame != oldDelegate.frame;
}
