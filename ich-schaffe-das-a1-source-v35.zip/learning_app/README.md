# Ich schaffe das — iPhone A1 test app

This Flutter app opens on a dark Google sign-in page and resumes at the first unfinished learning card. A new account starts with A1 lesson 1. Completing A1 opens the separate A1+ Revision course. Each card keeps its existing grammar, vocabulary, quiz, answers, word meanings, flag action, and scoring rules. The feed contains learning cards only.

Cards 1–20 of A1 have a conversational teacher script and pre-generated Kokoro narration. The current card plays automatically; the learner can pause, replay from the start, and expand the transcript. Audio is packaged in the IPA so learning does not call an AI service at runtime. Later cards keep their current content while the teacher series is expanded.

`assets/teacher_portraits.json` is the reusable speaking-photo map. Six supplied portraits are bundled and rotate through the cards. For another image, place it under `assets/teacher_portraits/`, give it an ID, and set `mouth_x`, `mouth_y`, and `mouth_width` as fractions of the displayed square crop. Add the ID to `cycle` or choose it for a particular activity slug in `assignments`. The app draws four deliberately simple mouth shapes while the card audio plays. No image generation or video rendering is required.

The learner's Supabase Auth UUID keys completed cards, quiz attempts, points, and flags. `learner_activity_progress`, `learner_answers`, and `learner_score_events` hold user progress. The older `learner_game_progress` table is retained as historical data but no game is loaded or shown by this app. Tap the initial at the top right for monthly leaders, personal points, reset progress, and sign-out. Reset removes both course progress and points for that account.

Books, lessons, activities, and the lexicon are read from Deutsch Supabase with bundled course fallback. The A1+ book is still a database draft, so the app uses its bundled content until publication. Google OAuth is in test mode and only listed test accounts can sign in. The redirect is `de.ichschaffedas.a1://login-callback/`.

The scripts live in `assets/teacher_scripts_a1_01_20.json` and the corresponding MP3 files in `assets/teacher_audio/`. The old visual-scene rows remain in Deutsch as unused historical data. This IPA is unsigned for Sideloadly to sign with the installer's Apple ID.
