create index if not exists learning_content_flags_activity_idx
  on public.learning_content_flags (activity_slug);
