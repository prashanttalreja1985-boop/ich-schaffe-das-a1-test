create table if not exists public.learning_content_flags (
  id uuid primary key default gen_random_uuid(),
  book_slug text not null references public.learning_books(slug) on delete cascade,
  activity_slug text not null references public.learning_activities(slug) on delete cascade,
  flagged_at timestamptz not null default now(),
  status text not null default 'open' check (status in ('open', 'fixed')),
  unique (book_slug, activity_slug)
);

create index if not exists learning_content_flags_status_idx
  on public.learning_content_flags (status, flagged_at desc);

create index if not exists learning_content_flags_activity_idx
  on public.learning_content_flags (activity_slug);

alter table public.learning_content_flags enable row level security;

create policy "learners can flag course content"
  on public.learning_content_flags
  for insert to anon, authenticated
  with check (
    length(trim(book_slug)) > 0 and length(trim(activity_slug)) > 0
  );

grant insert on public.learning_content_flags to anon, authenticated;
