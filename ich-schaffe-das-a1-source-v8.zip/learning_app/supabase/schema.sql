-- Run in a dedicated Supabase project. Content writes are administrator-only.
create table if not exists public.learning_books (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  edition text not null,
  level text not null check (level in ('A1', 'A2', 'B1', 'B2', 'C1', 'C2')),
  source_status text not null default 'draft' check (source_status in ('draft', 'reviewed', 'published')),
  created_at timestamptz not null default now()
);

create table if not exists public.learning_lessons (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null references public.learning_books(id) on delete cascade,
  slug text not null,
  number integer not null check (number > 0),
  title text not null,
  goal text not null default '',
  unique (book_id, slug),
  unique (book_id, number)
);

create table if not exists public.learning_activities (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.learning_lessons(id) on delete cascade,
  slug text not null unique,
  sequence_number integer not null check (sequence_number > 0),
  kind text not null check (kind in ('grammar', 'vocabulary', 'quiz')),
  title text not null,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  unique (lesson_id, sequence_number)
);

create table if not exists public.learner_activity_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  profile_key text not null,
  book_slug text not null references public.learning_books(slug) on delete cascade,
  activity_slug text not null references public.learning_activities(slug) on delete cascade,
  completed_at timestamptz not null default now(),
  primary key (user_id, profile_key, book_slug, activity_slug)
);

create table if not exists public.learner_answers (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  profile_key text not null,
  book_slug text not null references public.learning_books(slug) on delete cascade,
  activity_slug text not null references public.learning_activities(slug) on delete cascade,
  selected_answer integer not null,
  is_correct boolean not null,
  answered_at timestamptz not null default now()
);

create table if not exists public.learning_lexicon (
  book_slug text not null references public.learning_books(slug) on delete cascade,
  lemma text not null,
  word_type text not null check (word_type in ('noun', 'verb')),
  meaning_en text not null,
  article text check (article in ('der', 'die', 'das') or article is null),
  plural text,
  forms jsonb not null default '[]'::jsonb check (jsonb_typeof(forms) = 'array'),
  primary key (book_slug, lemma, word_type)
);

create table if not exists public.learning_content_flags (
  id uuid primary key default gen_random_uuid(),
  book_slug text not null references public.learning_books(slug) on delete cascade,
  activity_slug text not null references public.learning_activities(slug) on delete cascade,
  flagged_at timestamptz not null default now(),
  status text not null default 'open' check (status in ('open', 'fixed')),
  unique (book_slug, activity_slug)
);

create index if not exists learning_content_flags_activity_idx
  on public.learning_content_flags (activity_slug);

create index if not exists learner_answers_user_book_idx
  on public.learner_answers (user_id, profile_key, book_slug, answered_at desc);
create index if not exists learner_activity_progress_activity_idx
  on public.learner_activity_progress (activity_slug);
create index if not exists learner_activity_progress_book_idx
  on public.learner_activity_progress (book_slug);
create index if not exists learner_answers_activity_idx
  on public.learner_answers (activity_slug);
create index if not exists learner_answers_book_idx
  on public.learner_answers (book_slug);

alter table public.learning_books enable row level security;
alter table public.learning_lessons enable row level security;
alter table public.learning_activities enable row level security;
alter table public.learner_activity_progress enable row level security;
alter table public.learner_answers enable row level security;
alter table public.learning_lexicon enable row level security;
alter table public.learning_content_flags enable row level security;

-- Book content is read-only to clients; only published books are visible.
create policy "read published books" on public.learning_books for select
  to anon, authenticated using (source_status = 'published');
create policy "read published lessons" on public.learning_lessons for select
  to anon, authenticated using (
    exists (select 1 from public.learning_books b
      where b.id = book_id and b.source_status = 'published')
  );
create policy "read published activities" on public.learning_activities for select
  to anon, authenticated using (
    exists (select 1 from public.learning_lessons l
      join public.learning_books b on b.id = l.book_id
      where l.id = lesson_id and b.source_status = 'published')
  );
create policy "read published lexicon" on public.learning_lexicon for select
  to anon, authenticated using (
    exists (select 1 from public.learning_books b
      where b.slug = book_slug and b.source_status = 'published')
  );
create policy "learners can flag course content" on public.learning_content_flags
  for insert to anon, authenticated
  with check (length(trim(book_slug)) > 0 and length(trim(activity_slug)) > 0);

create policy "read own progress" on public.learner_activity_progress
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "insert own progress" on public.learner_activity_progress
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "update own progress" on public.learner_activity_progress
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
create policy "read own answers" on public.learner_answers
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "insert own answers" on public.learner_answers
  for insert to authenticated with check ((select auth.uid()) = user_id);

grant select on public.learning_books, public.learning_lessons,
  public.learning_activities, public.learning_lexicon to anon, authenticated;
grant insert on public.learning_content_flags to anon, authenticated;
grant select, insert, update on public.learner_activity_progress to authenticated;
grant select, insert on public.learner_answers to authenticated;
grant usage, select on sequence public.learner_answers_id_seq to authenticated;
