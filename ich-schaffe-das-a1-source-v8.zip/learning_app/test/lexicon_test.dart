import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/lexicon.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('A1 and A1+ have separate noun and verb lexicons with pressable forms',
      () async {
    final data = jsonDecode(await rootBundle.loadString('assets/lexicon.json'))
        as Map<String, dynamic>;
    final a1 = Lexicon.fromJson(data, 'original-a1-starter');
    final a1Plus = Lexicon.fromJson(data, 'ich-schaffe-das-a1-plus');

    expect(a1.entries.where((entry) => entry.type == 'noun').length,
        greaterThan(200));
    expect(a1.entries.where((entry) => entry.type == 'verb').length,
        greaterThan(100));
    expect(a1Plus.entries.where((entry) => entry.type == 'noun').length,
        greaterThan(100));
    expect(a1Plus.entries.where((entry) => entry.type == 'verb').length,
        greaterThan(100));

    expect(a1.find('der Name')?.meaning, isNotEmpty);
    expect(a1.find('bin')?.lemma, 'sein');
    expect(a1.find('wohne')?.lemma, 'wohnen');
    expect(a1Plus.find('der Arm')?.meaning, 'arm');
    expect(a1Plus.find('die Hand')?.meaning, 'hand');
    expect(a1.find('die Hand')?.article, 'die');
  });

  test('longest complete noun form is matched before shorter forms', () async {
    final data = jsonDecode(await rootBundle.loadString('assets/lexicon.json'))
        as Map<String, dynamic>;
    final lexicon = Lexicon.fromJson(data, 'original-a1-starter');

    final parts = lexicon.split('Ich kaufe den Apfel heute.');
    final linked = parts.where((part) => part.lexeme != null).toList();
    expect(linked.map((part) => part.text), contains('den Apfel'));
    expect(
        linked.firstWhere((part) => part.text == 'den Apfel').lexeme?.lemma,
        'Apfel');
  });

  testWidgets('meaning requires a long press and stays on screen',
      (tester) async {
    final data = jsonDecode(await rootBundle.loadString('assets/lexicon.json'))
        as Map<String, dynamic>;
    final lexicon = Lexicon.fromJson(data, 'original-a1-starter');
    var optionSelected = false;
    tester.view.physicalSize = const Size(320, 600);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Align(
          alignment: Alignment.bottomRight,
          child: Padding(
            padding: const EdgeInsets.only(right: 8, bottom: 20),
            child: InkWell(
              onTap: () => optionSelected = true,
              child: LexicalText('Apfel', lexicon: lexicon),
            ),
          ),
        ),
      ),
    ));

    final word = find.byType(RichText);
    await tester.tap(word);
    await tester.pumpAndSettle();
    expect(optionSelected, isTrue);
    expect(find.byKey(const ValueKey('meaning-popover')), findsNothing);

    await tester.longPress(word);
    await tester.pumpAndSettle();
    expect(find.text('apple'), findsOneWidget);
    final popup = tester.getRect(find.byKey(const ValueKey('meaning-popover')));
    expect(popup.left, greaterThanOrEqualTo(0));
    expect(popup.top, greaterThanOrEqualTo(0));
    expect(popup.right, lessThanOrEqualTo(320));
    expect(popup.bottom, lessThanOrEqualTo(600));
  });
}
