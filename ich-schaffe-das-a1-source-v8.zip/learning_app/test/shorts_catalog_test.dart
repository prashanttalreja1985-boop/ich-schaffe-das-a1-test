import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/shorts_catalog.dart';

void main() {
  test('interest words prioritize matching Shorts without removing others', () {
    final catalog = [
      YoutubeShort('one', 'German words', 'A', ['german', 'language']),
      YoutubeShort('two', 'Football skill', 'B', ['football', 'sports']),
      YoutubeShort('three', 'Nature', 'C', ['travel', 'nature']),
    ];
    final ranked = rankShorts(catalog, parseInterestKeywords(' football, travel '));
    expect(ranked.map((item) => item.id), ['two', 'three', 'one']);
  });
}
