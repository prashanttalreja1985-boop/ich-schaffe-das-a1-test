import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/feed_plan.dart';

void main() {
  test('starts with three Shorts, then one after four learning cards', () {
    final feed = planSessionFeed(
        firstUnfinishedActivity: 7, activityCount: 16, availableShorts: 10);
    expect(feed.take(3).map((slot) => slot.shortIndex), [0, 1, 2]);
    expect(feed.where((slot) => !slot.isShort).map((slot) => slot.activityIndex),
        [7, 8, 9, 10, 11, 12, 13, 14, 15]);
    expect(feed.where((slot) => slot.isShort).map((slot) => slot.shortIndex),
        [0, 1, 2, 3, 4]);
    expect(feed[7].shortIndex, 3);
    expect(feed[12].shortIndex, 4);
  });

  test('keeps lessons usable without video access', () {
    final feed = planSessionFeed(
        firstUnfinishedActivity: 2, activityCount: 6, availableShorts: 0);
    expect(feed.map((slot) => slot.activityIndex), [2, 3, 4, 5]);
  });
}
