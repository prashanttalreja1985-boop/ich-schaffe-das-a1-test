import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';

class Lexeme {
  const Lexeme({
    required this.bookSlug,
    required this.lemma,
    required this.type,
    required this.meaning,
    required this.forms,
    this.article,
  });

  final String bookSlug;
  final String lemma;
  final String type;
  final String meaning;
  final String? article;
  final List<String> forms;

  String get key => '$bookSlug:$type:$lemma';

  factory Lexeme.fromJson(Map<String, dynamic> json) => Lexeme(
        bookSlug: json['book_slug'] as String,
        lemma: json['lemma'] as String,
        type: json['word_type'] as String,
        meaning: json['meaning_en'] as String,
        article: json['article'] as String?,
        forms: (json['forms'] as List<dynamic>).cast<String>(),
      );
}

class Lexicon {
  Lexicon(Iterable<Lexeme> entries)
      : entries = List.unmodifiable(entries) {
    final byForm = <String, Lexeme>{};
    for (final entry in this.entries) {
      for (final form in entry.forms) {
        final key = _normalize(form);
        final previous = byForm[key];
        if (previous == null ||
            (entry.type == 'noun' && entry.article != null &&
                previous.article == null)) {
          byForm[key] = entry;
        }
      }
    }
    _byForm = byForm;
    final forms = byForm.keys.toList()
      ..sort((a, b) => b.length.compareTo(a.length));
    _pattern = forms.isEmpty
        ? null
        : RegExp(
            r'(?<![A-Za-zÄÖÜäöüß])(?:' +
                forms.map(RegExp.escape).join('|') +
                r')(?![A-Za-zÄÖÜäöüß])',
            caseSensitive: false,
          );
  }

  final List<Lexeme> entries;
  late final Map<String, Lexeme> _byForm;
  late final RegExp? _pattern;

  factory Lexicon.fromJson(Map<String, dynamic> json, String bookSlug) =>
      Lexicon((json['entries'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .where((entry) => entry['book_slug'] == bookSlug)
          .map(Lexeme.fromJson));

  Lexeme? find(String text) => _byForm[_normalize(text)];

  List<LexicalPart> split(String text) {
    final pattern = _pattern;
    if (pattern == null) return [LexicalPart(text, null)];
    final parts = <LexicalPart>[];
    var cursor = 0;
    for (final match in pattern.allMatches(text)) {
      if (match.start > cursor) {
        parts.add(LexicalPart(text.substring(cursor, match.start), null));
      }
      final visible = text.substring(match.start, match.end);
      final lexeme = _byForm[_normalize(visible)];
      parts.add(LexicalPart(visible, lexeme));
      cursor = match.end;
    }
    if (cursor < text.length) parts.add(LexicalPart(text.substring(cursor), null));
    return parts.isEmpty ? [LexicalPart(text, null)] : parts;
  }

  static String _normalize(String value) =>
      value.toLowerCase().trim();
}

class LexicalPart {
  const LexicalPart(this.text, this.lexeme);
  final String text;
  final Lexeme? lexeme;
}

class LexicalText extends StatefulWidget {
  const LexicalText(
    this.text, {
    super.key,
    required this.lexicon,
    this.style,
    this.textAlign,
    this.maxLines,
    this.overflow,
  });

  final String text;
  final Lexicon lexicon;
  final TextStyle? style;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;

  @override
  State<LexicalText> createState() => _LexicalTextState();
}

class _LexicalTextState extends State<LexicalText> {
  final Map<String, LongPressGestureRecognizer> _recognizers = {};
  OverlayEntry? _meaningEntry;

  @override
  void didUpdateWidget(covariant LexicalText oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.lexicon != widget.lexicon) _disposeRecognizers();
  }

  void _disposeRecognizers() {
    for (final recognizer in _recognizers.values) {
      recognizer.dispose();
    }
    _recognizers.clear();
  }

  LongPressGestureRecognizer _recognizer(Lexeme lexeme) =>
      _recognizers.putIfAbsent(lexeme.key, () {
        return LongPressGestureRecognizer()
          ..onLongPressStart = (details) => _showMeaning(
              lexeme, details.globalPosition);
      });

  void _showMeaning(Lexeme lexeme, Offset anchor) {
    _meaningEntry?.remove();
    final entry = OverlayEntry(builder: (overlayContext) {
      final media = MediaQuery.of(overlayContext);
      return Positioned.fill(
        child: LayoutBuilder(builder: (context, constraints) {
          final width = math
              .min(280.0, constraints.maxWidth - 24)
              .toDouble();
          final topInset = media.padding.top + 8;
          final bottomInset = media.padding.bottom + 8;
          final title = lexeme.type == 'noun' && lexeme.article != null
              ? '${lexeme.article} ${lexeme.lemma}'
              : lexeme.lemma;
          return Stack(children: [
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _dismissMeaning,
                child: const ColoredBox(color: Colors.transparent),
              ),
            ),
            CustomSingleChildLayout(
              delegate: _MeaningPopoverLayout(
                anchor: anchor,
                topInset: topInset,
                bottomInset: bottomInset,
                width: width,
              ),
              child: TweenAnimationBuilder<double>(
                duration: const Duration(milliseconds: 190),
                curve: Curves.easeOutBack,
                tween: Tween(begin: 0.82, end: 1),
                builder: (context, scale, child) => Transform.scale(
                  alignment: Alignment.bottomLeft,
                  scale: scale,
                  child: child,
                ),
                child: Container(
                  key: const ValueKey('meaning-popover'),
                  width: width,
                  constraints: BoxConstraints(
                    maxHeight: math.max(
                            80.0,
                            constraints.maxHeight - topInset - bottomInset)
                        .toDouble(),
                  ),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFF17634B), Color(0xFF0C3D30)],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withValues(alpha: 0.15)),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF061B16).withValues(alpha: 0.42),
                        blurRadius: 24,
                        offset: const Offset(0, 12),
                      ),
                    ],
                  ),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(title, style: const TextStyle(
                            color: Colors.white, fontSize: 16,
                            fontWeight: FontWeight.w800)),
                        const SizedBox(height: 5),
                        Text(lexeme.meaning, style: const TextStyle(
                            color: Colors.white, fontSize: 15, height: 1.35)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ]);
        }),
      );
    });
    _meaningEntry = entry;
    Overlay.of(context, rootOverlay: true).insert(entry);
  }

  void _dismissMeaning() {
    _meaningEntry?.remove();
    _meaningEntry = null;
  }

  @override
  void dispose() {
    _dismissMeaning();
    _disposeRecognizers();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = widget.style ?? DefaultTextStyle.of(context).style;
    final spans = widget.lexicon.split(widget.text).map((part) {
      final lexeme = part.lexeme;
      if (lexeme == null) return TextSpan(text: part.text);
      final isNoun = lexeme.type == 'noun';
      return TextSpan(
        text: part.text,
        recognizer: _recognizer(lexeme),
        style: TextStyle(
          color: isNoun ? const Color(0xFFF5C85B) : const Color(0xFF70D6AB),
          fontWeight: isNoun ? FontWeight.w700 : FontWeight.bold,
          decoration: TextDecoration.underline,
          decorationColor: (isNoun
                  ? const Color(0xFFF5C85B)
                  : const Color(0xFF70D6AB))
              .withValues(alpha: 0.35),
        ),
      );
    }).toList();
    return RichText(
      text: TextSpan(style: base, children: spans),
      textAlign: widget.textAlign ?? TextAlign.start,
      maxLines: widget.maxLines,
      overflow: widget.overflow ?? TextOverflow.clip,
    );
  }
}

class _MeaningPopoverLayout extends SingleChildLayoutDelegate {
  const _MeaningPopoverLayout({
    required this.anchor,
    required this.topInset,
    required this.bottomInset,
    required this.width,
  });

  final Offset anchor;
  final double topInset;
  final double bottomInset;
  final double width;

  @override
  BoxConstraints getConstraintsForChild(BoxConstraints constraints) =>
      BoxConstraints(
        maxWidth: width,
        maxHeight: math.max(
                80.0, constraints.maxHeight - topInset - bottomInset)
            .toDouble(),
      );

  @override
  Offset getPositionForChild(Size size, Size childSize) {
    final left = (anchor.dx + 12)
        .clamp(12.0, math.max(12.0, size.width - childSize.width - 12))
        .toDouble();
    var top = anchor.dy - childSize.height - 12;
    if (top < topInset) top = anchor.dy + 12;
    top = top.clamp(topInset,
        math.max(topInset, size.height - bottomInset - childSize.height))
        .toDouble();
    return Offset(left, top);
  }

  @override
  bool shouldRelayout(covariant _MeaningPopoverLayout oldDelegate) =>
      anchor != oldDelegate.anchor ||
      topInset != oldDelegate.topInset ||
      bottomInset != oldDelegate.bottomInset ||
      width != oldDelegate.width;
}
