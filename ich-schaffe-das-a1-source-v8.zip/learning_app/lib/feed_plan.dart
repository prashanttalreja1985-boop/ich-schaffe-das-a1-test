/// A session opens with three Shorts. One more follows each group of four
/// learning activities. Learning activity indices still refer to the course,
/// so video cards never count as completed lessons or alter saved progress.
class FeedSlot {
  const FeedSlot.activity(this.activityIndex) : shortIndex = null;
  const FeedSlot.short(this.shortIndex) : activityIndex = null;

  final int? activityIndex;
  final int? shortIndex;
  bool get isShort => shortIndex != null;
}

List<FeedSlot> planSessionFeed({
  required int firstUnfinishedActivity,
  required int activityCount,
  required int availableShorts,
}) {
  if (firstUnfinishedActivity < 0 || activityCount < firstUnfinishedActivity ||
      availableShorts < 0) {
    throw ArgumentError('Invalid session feed bounds');
  }
  final slots = <FeedSlot>[];
  var nextShort = 0;
  for (var i = 0; i < 3 && nextShort < availableShorts; i++) {
    slots.add(FeedSlot.short(nextShort++));
  }
  var cardsSinceShort = 0;
  for (var activity = firstUnfinishedActivity;
      activity < activityCount;
      activity++) {
    slots.add(FeedSlot.activity(activity));
    cardsSinceShort++;
    if (cardsSinceShort == 4 && nextShort < availableShorts) {
      slots.add(FeedSlot.short(nextShort++));
      cardsSinceShort = 0;
    }
  }
  return slots;
}
