import 'dart:convert';

import 'package:flutter/services.dart';

class YoutubeShort {
  const YoutubeShort(this.id, this.title, this.channel, this.tags);

  final String id;
  final String title;
  final String channel;
  final List<String> tags;

  factory YoutubeShort.fromJson(Map<String, dynamic> json) => YoutubeShort(
        json['id'] as String,
        json['title'] as String,
        json['channel'] as String,
        (json['tags'] as List<dynamic>).cast<String>(),
      );
}

List<String> parseInterestKeywords(String value) => value
    .split(',')
    .map((keyword) => keyword.trim().toLowerCase())
    .where((keyword) => keyword.isNotEmpty)
    .toSet()
    .toList();

List<YoutubeShort> rankShorts(
    List<YoutubeShort> catalog, List<String> keywords) {
  final scored = catalog.asMap().entries.map((entry) {
    final video = entry.value;
    final score = keywords.where((keyword) =>
        video.tags.any((tag) => tag.contains(keyword) || keyword.contains(tag)) ||
        video.title.toLowerCase().contains(keyword)).length;
    return (video: video, score: score, originalIndex: entry.key);
  }).toList();
  scored.sort((a, b) {
    final byScore = b.score.compareTo(a.score);
    return byScore != 0 ? byScore : a.originalIndex.compareTo(b.originalIndex);
  });
  return scored.map((entry) => entry.video).toList();
}

Future<List<YoutubeShort>> loadShortsCatalog(List<String> keywords) async {
  final raw = await rootBundle.loadString('assets/shorts_catalog.json');
  final catalog = (jsonDecode(raw) as List<dynamic>)
      .map((item) => YoutubeShort.fromJson(item as Map<String, dynamic>))
      .toList();
  return rankShorts(catalog, keywords);
}
