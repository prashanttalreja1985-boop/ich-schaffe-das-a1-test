"""Regenerate the simple iOS app icon from code."""

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
ICON_DIR = ROOT / "ios/Runner/Assets.xcassets/AppIcon.appiconset"
manifest = json.loads((ICON_DIR / "Contents.json").read_text(encoding="utf-8"))

image = Image.new("RGB", (1024, 1024), "#152039")
draw = ImageDraw.Draw(image)
draw.rounded_rectangle((100, 100, 924, 924), radius=210, fill="#F5C85B")
draw.rounded_rectangle((145, 145, 879, 879), radius=170, fill="#1D2940")
font_path = Path("C:/Windows/Fonts/arialbd.ttf")
if not font_path.exists():
    font_path = Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf")
font = ImageFont.truetype(str(font_path), 420)
draw.text((510, 465), "ich", font=font, anchor="mm", fill="#FFFFFF")
draw.arc((260, 495, 775, 810), 20, 160, fill="#F5C85B", width=44)

for spec in manifest["images"]:
    size = float(spec["size"].split("x")[0])
    scale = int(spec["scale"][0])
    pixels = round(size * scale)
    image.resize((pixels, pixels), Image.Resampling.LANCZOS).save(
        ICON_DIR / spec["filename"]
    )
print("Wrote iOS icon sizes")
