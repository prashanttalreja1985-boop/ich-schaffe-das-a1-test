// Builds a timestamp-only coverage audit from a transcript supplied locally.
// The transcript itself is deliberately not copied into the course bundle.
const fs = require('node:fs');
const path = require('node:path');

const input = process.argv[2];
if (!input) throw new Error('Usage: node tool/build_a1_plus_coverage.js <transcript.txt>');
const chapterStarts = [
  '00:00:00', '00:51:52', '01:39:16', '02:34:12', '03:37:27',
  '04:17:21', '04:37:45', '05:24:13', '05:59:59', '06:44:04',
  '07:25:49', '07:52:09', '08:45:06', '09:05:47',
];
const chapterNames = [
  'Basics, alphabet, pronunciation, greetings and introductions',
  'Articles, noun gender, dictionary use, clarification phrases and weekdays',
  'Personal pronouns, plural formation, numbers, phone numbers, months and dates',
  'Sentence structure, present tense, negation, time and ordering/payment',
  'Yes/no and W-questions, time prepositions, introductions, weather and seasons',
  'Adjectives, adjective endings and colors',
  'Modal verbs, separable verbs and daily routine',
  'Präteritum of haben/sein and regular/irregular verbs; transport and plans',
  'Perfekt auxiliaries and participles; apartment and weekend',
  'Accusative articles, pronouns, adjectives, kein and professions',
  'Possessive articles/pronouns in nominative/accusative; clothing',
  'Dative introduction, two-way/location/direction prepositions and directions',
  'Comparisons, demonstratives, groceries, prices and frequency',
  'Imperative forms, body parts, illness and doctor appointments',
];
const seconds = (time) => {
  const [hours, minutes, secs] = time.split(':').map(Number);
  return hours * 3600 + minutes * 60 + secs;
};
const source = fs.readFileSync(input, 'utf8').replace(/^\uFEFF/, '');
const timestamps = [...source.matchAll(/(?:^|\r?\n)(\d{2}:\d{2}:\d{2})\s*(?=\r?\n)/g)]
  .map((match) => match[1]);
if (timestamps.length < 100) throw new Error(`Only found ${timestamps.length} timestamps; check transcript format.`);
const chapters = chapterStarts.map((start, index) => ({
  number: index + 1,
  title: chapterNames[index],
  starts_at: start,
  ends_before: chapterStarts[index + 1] ?? '09:33:49',
  lesson_slug: `a1plus-transcript-chapter-${String(index + 1).padStart(2, '0')}`,
  timestamp_count: 0,
}));
const segments = timestamps.map((time) => {
  let chapter = 0;
  for (let i = 1; i < chapterStarts.length; i++) {
    if (seconds(time) < seconds(chapterStarts[i])) break;
    chapter = i;
  }
  chapters[chapter].timestamp_count++;
  return { time, chapter: chapter + 1,
    lesson_slug: chapters[chapter].lesson_slug };
});
const output = {
  source: 'https://www.youtube.com/watch?v=-KdGfbgL6sg',
  title: 'Learn German Step by Step | Full German A1 Course For Beginners | 9.5 Hours',
  transcript: 'User-supplied timestamped transcript; transcript text is not bundled.',
  status: 'chapter_mapped',
  duration_seconds: seconds(timestamps.at(-1)),
  timestamp_count: segments.length,
  chapter_count: chapters.length,
  chapters,
  timestamp_segments: segments,
};
const target = path.join(__dirname, 'a1_plus_video_coverage.json');
fs.writeFileSync(target, `${JSON.stringify(output, null, 2)}\n`);
console.log(`Mapped ${segments.length} transcript timestamps into ${chapters.length} chapter lessons: ${target}`);
