const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const books = [
  ['assets/starter_content.json', 'original-a1-starter'],
  ['assets/a1_plus_content.json', 'ich-schaffe-das-a1-plus'],
];

const verbMeanings = {
  sein: 'to be', haben: 'to have', werden: 'to become', heißen: 'to be called',
  sprechen: 'to speak', kommen: 'to come', wohnen: 'to live', lernen: 'to learn',
  machen: 'to do; to make', spielen: 'to play', arbeiten: 'to work', fragen: 'to ask',
  antworten: 'to answer', hören: 'to hear; to listen', sagen: 'to say', schreiben: 'to write',
  lesen: 'to read', üben: 'to practise', verstehen: 'to understand', buchstabieren: 'to spell',
  aufstehen: 'to get up', frühstücken: 'to have breakfast', anfangen: 'to begin',
  einkaufen: 'to shop', fernsehen: 'to watch television', schlafen: 'to sleep',
  duschen: 'to shower', abfahren: 'to depart', ankommen: 'to arrive', tanzen: 'to dance',
  schwimmen: 'to swim', treffen: 'to meet', fahren: 'to travel; to drive', gehen: 'to go',
  geben: 'to give', nehmen: 'to take', essen: 'to eat', trinken: 'to drink',
  sehen: 'to see; to watch', finden: 'to find', kaufen: 'to buy', brauchen: 'to need',
  bestellen: 'to order', bezahlen: 'to pay', zahlen: 'to pay', suchen: 'to look for',
  bringen: 'to bring', bleiben: 'to stay', besuchen: 'to visit', telefonieren: 'to telephone',
  anrufen: 'to call', aufräumen: 'to tidy up', aufmachen: 'to open', zumachen: 'to close',
  öffnen: 'to open', schließen: 'to close', beginnen: 'to start', enden: 'to end',
  warten: 'to wait', helfen: 'to help', laufen: 'to run; to walk', fliegen: 'to fly',
  reisen: 'to travel', regnen: 'to rain', schneien: 'to snow', kosten: 'to cost',
  tragen: 'to wear; to carry', gefallen: 'to please; to be liked', verdienen: 'to earn',
  möchten: 'would like', mögen: 'to like', können: 'can; to be able to', müssen: 'must; to have to',
  dürfen: 'may; to be allowed to', sollen: 'should; to be supposed to', wollen: 'to want',
  ausschlafen: 'to sleep in', aufwachen: 'to wake up', aussteigen: 'to get off',
  einsteigen: 'to get on', umsteigen: 'to change trains', anziehen: 'to put on; to get dressed',
  ausziehen: 'to take off; to move out', sich_freuen: 'to look forward to; to be happy',
  freuen: 'to make happy; to look forward to', sich_duschen: 'to shower',
  sich_vorstellen: 'to introduce oneself; to imagine', vorstellen: 'to introduce; to imagine',
  mitbringen: 'to bring along', mitkommen: 'to come along', einladen: 'to invite',
  aufräumen: 'to tidy up', aufpassen: 'to pay attention; to look after',
  vergessen: 'to forget', verlieren: 'to lose', gewinnen: 'to win', legen: 'to put; to lay',
  stehen: 'to stand', sitzen: 'to sit', liegen: 'to lie; to be located', hängen: 'to hang',
  nehmen: 'to take', helfen: 'to help', zeigen: 'to show', erklären: 'to explain',
  wiederholen: 'to repeat', bedeuten: 'to mean', buchstabieren: 'to spell',
};

const irregularForms = {
  sein: ['bin', 'bist', 'ist', 'sind', 'seid', 'gewesen'],
  haben: ['habe', 'hast', 'hat', 'haben', 'habt', 'gehabt'],
  werden: ['werde', 'wirst', 'wird', 'werden', 'werdet', 'geworden'],
  fahren: ['fahre', 'fährst', 'fährt', 'fahren', 'fahrt', 'gefahren'],
  sprechen: ['spreche', 'sprichst', 'spricht', 'sprechen', 'sprecht', 'gesprochen'],
  lesen: ['lese', 'liest', 'liest', 'lesen', 'lest', 'gelesen'],
  sehen: ['sehe', 'siehst', 'sieht', 'sehen', 'seht', 'gesehen'],
  geben: ['gebe', 'gibst', 'gibt', 'geben', 'gebt', 'gegeben'],
  nehmen: ['nehme', 'nimmst', 'nimmt', 'nehmen', 'nehmt', 'genommen'],
  essen: ['esse', 'isst', 'isst', 'essen', 'esst', 'gegessen'],
  treffen: ['treffe', 'triffst', 'trifft', 'treffen', 'trefft', 'getroffen'],
  schlafen: ['schlafe', 'schläfst', 'schläft', 'schlafen', 'schlaft', 'geschlafen'],
  helfen: ['helfe', 'hilfst', 'hilft', 'helfen', 'helft', 'geholfen'],
  laufen: ['laufe', 'läufst', 'läuft', 'laufen', 'lauft', 'gelaufen'],
  können: ['kann', 'kannst', 'kann', 'können', 'könnt', 'gekonnt'],
  müssen: ['muss', 'musst', 'muss', 'müssen', 'müsst', 'gemusst'],
  dürfen: ['darf', 'darfst', 'darf', 'dürfen', 'dürft', 'gedurft'],
  sollen: ['soll', 'sollst', 'soll', 'sollen', 'sollt', 'gesollt'],
  wollen: ['will', 'willst', 'will', 'wollen', 'wollt', 'gewollt'],
  mögen: ['mag', 'magst', 'mag', 'mögen', 'mögt', 'gemocht'],
  möchten: ['möchte', 'möchtest', 'möchte', 'möchten', 'möchtet'],
};

const normalize = (value) => value.normalize('NFC').toLocaleLowerCase('de-DE').trim();
const unique = (values) => [...new Set(values.filter(Boolean))];

function regularVerbForms(lemma) {
  const prefixAt = lemma.indexOf('_');
  const reflexive = prefixAt >= 0 ? 'sich ' : '';
  const verb = prefixAt >= 0 ? lemma.replace('_', ' ') : lemma;
  const prefix = /^(an|auf|aus|ein|mit|vor|zu|zurück|fern|ab|um|weg|los)(.+)$/.exec(verb);
  const infinitive = prefix ? prefix[2] : verb;
  const stem = infinitive.replace(/(?:en|n)$/, '');
  const soft = /[td]$/.test(stem);
  const forms = [
    `${reflexive}${verb}`,
    `${reflexive}${stem}e`,
    `${reflexive}${stem}${soft ? 'est' : 'st'}`,
    `${reflexive}${stem}${soft ? 'et' : 't'}`,
    `${reflexive}${verb}`,
    `${reflexive}${stem}${soft ? 'et' : 't'}`,
  ];
  if (prefix) {
    const separable = prefix[1];
    const baseStem = stem;
    forms.push(
      `${reflexive}${baseStem}${soft ? 'e' : 'e'} ${separable}`,
      `${reflexive}${baseStem}${soft ? 'est' : 'st'} ${separable}`,
      `${reflexive}${baseStem}${soft ? 'et' : 't'} ${separable}`,
      `${reflexive}${infinitive} ${separable}`,
    );
  }
  return unique(forms);
}

function nounForms(article, lemma, aliases = []) {
  const baseForms = unique([lemma, ...aliases]);
  const loweredArticle = normalize(article);
  const alternatives = loweredArticle === 'der'
    ? ['der', 'den', 'dem', 'des']
    : loweredArticle === 'die'
      ? ['die', 'der']
      : ['das', 'dem', 'des'];
  const forms = [...baseForms];
  for (const noun of baseForms) {
    for (const determiner of alternatives) forms.push(`${determiner} ${noun}`);
    if (/e$/.test(noun) && loweredArticle === 'der') {
      forms.push(`${noun}n`, `den ${noun}n`, `dem ${noun}n`, `des ${noun}n`);
    }
  }
  return unique(forms);
}

const allEntries = [];
for (const [assetPath, expectedSlug] of books) {
  const data = JSON.parse(fs.readFileSync(path.join(root, assetPath), 'utf8'));
  if (data.book.slug !== expectedSlug) throw new Error(`Unexpected book slug in ${assetPath}`);

  const vocab = data.lessons.flatMap((lesson) => lesson.activities)
    .filter((activity) => activity.kind === 'vocabulary')
    .flatMap((activity) => activity.items ?? []);
  const translations = new Map(vocab.map((item) => [normalize(item.de), item.en]));
  const nouns = new Map();
  const verbs = new Set(Object.keys(verbMeanings));

  for (const item of vocab) {
    const germanParts = item.de.split('/').map((part) => part.trim()).filter(Boolean);
    const englishParts = item.en.split('/').map((part) => part.trim()).filter(Boolean);
    const nounParts = germanParts.map((part, index) => {
      const match = /^(der|die|das)\s+(.+)$/i.exec(part);
      return match ? { article: match[1].toLocaleLowerCase('de-DE'),
        lemma: match[2].trim(), meaning: englishParts[index] ?? item.en } : null;
    }).filter(Boolean);
    if (nounParts.length) {
      for (const { article, lemma, meaning } of nounParts) {
        const key = normalize(lemma);
        const current = nouns.get(key);
        const record = {
          book_slug: expectedSlug,
          lemma,
          word_type: 'noun',
          meaning_en: meaning,
          article,
          plural: null,
          forms: nounForms(article, lemma),
        };
        if (!current || meaning.length > current.meaning_en.length) nouns.set(key, record);
      }
      continue;
    }

    const normalized = normalize(item.de);
    const translationSuggestsVerb = /^(to\s|can\b|must\b|may\b|should\b|would like\b)/i.test(item.en.trim());
    if (translationSuggestsVerb || /^(?:sich\s+)?[\p{L}]+(?:en|n)$/u.test(normalized)) {
      const first = normalized.split(/\s+/).at(-1);
      if (first && /(?:en|n)$/.test(first)) verbs.add(first);
    }
  }

  const entries = [...nouns.values()];
  const seenVerb = new Set();
  for (const rawVerb of verbs) {
    const lemma = rawVerb.replaceAll(' ', '_');
    const key = normalize(rawVerb.replaceAll('_', ' '));
    if (seenVerb.has(key)) continue;
    seenVerb.add(key);
    const fromVocab = translations.get(key) ?? translations.get(normalize(rawVerb));
    const meaning = fromVocab ?? verbMeanings[rawVerb] ?? verbMeanings[lemma];
    if (!meaning) continue;
    const forms = irregularForms[rawVerb] ?? regularVerbForms(rawVerb);
    const phraseItem = vocab.find((item) => normalize(item.de).split(/\s+/).at(-1) === key);
    entries.push({
      book_slug: expectedSlug,
      lemma: rawVerb.replaceAll('_', ' '),
      word_type: 'verb',
      meaning_en: meaning,
      article: null,
      plural: null,
      forms: unique([rawVerb, rawVerb.replaceAll('_', ' '), ...(phraseItem ? [phraseItem.de] : []), ...forms]),
    });
  }

  allEntries.push(...entries);
}

allEntries.sort((a, b) => a.book_slug.localeCompare(b.book_slug) ||
  a.word_type.localeCompare(b.word_type) || a.lemma.localeCompare(b.lemma, 'de'));
fs.writeFileSync(path.join(root, 'assets/lexicon.json'),
  JSON.stringify({ version: 1, entries: allEntries }, null, 2) + '\n');

const sqlString = (value) => value == null ? 'null' : `'${String(value).replaceAll("'", "''")}'`;
const sqlJson = (value) => `${sqlString(JSON.stringify(value))}::jsonb`;
const rows = allEntries.map((entry) => `  (${sqlString(entry.book_slug)}, ${sqlString(entry.lemma)}, ${sqlString(entry.word_type)}, ${sqlString(entry.meaning_en)}, ${sqlString(entry.article)}, ${sqlString(entry.plural)}, ${sqlJson(entry.forms)})`);
const sql = `-- Generated by tool/build_lexicon.js. Safe to re-run; updates lexicon records only.\n` +
`insert into public.learning_lexicon (book_slug, lemma, word_type, meaning_en, article, plural, forms)\nvalues\n${rows.join(',\n')}\non conflict (book_slug, lemma, word_type) do update set\n  meaning_en = excluded.meaning_en,\n  article = excluded.article,\n  plural = excluded.plural,\n  forms = excluded.forms;\n`;
fs.writeFileSync(path.join(root, 'tool/lexicon_import.sql'), sql);

for (const [assetPath] of books) {
  const slug = JSON.parse(fs.readFileSync(path.join(root, assetPath), 'utf8')).book.slug;
  const byType = allEntries.filter((entry) => entry.book_slug === slug)
    .reduce((counts, entry) => ({ ...counts, [entry.word_type]: (counts[entry.word_type] ?? 0) + 1 }), {});
  console.log(`${slug}: ${byType.noun ?? 0} nouns, ${byType.verb ?? 0} verbs`);
}
