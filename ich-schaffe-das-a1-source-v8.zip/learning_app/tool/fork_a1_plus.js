// Build a separate A1+ revision and extension course for use after A1.
// The supplied transcript text itself is not bundled.
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const target = path.join(root, 'assets', 'a1_plus_content.json');
const chapterFile = path.join(__dirname, 'a1_plus_transcript_chapters.json');
const chapters = JSON.parse(fs.readFileSync(chapterFile, 'utf8'));
const copy = { book: {
  slug: 'ich-schaffe-das-a1-plus',
  title: 'Ich schaffe das — A1+ Revision',
  edition: 'Original A1+ revision and extension following the separate A1 course',
  level: 'A1',
}, lessons: [] };
for (const [chapterIndex, chapter] of chapters.entries()) {
  const chapterNumber = String(chapterIndex + 1).padStart(2, '0');
  const lessonSlug = `a1plus-transcript-chapter-${chapterNumber}`;
  const activities = [];
  const append = (kind, entries) => {
    for (const [index, entry] of entries.entries()) {
      activities.push({
        slug: `a1plus-video-ch${chapterNumber}-${kind}-${String(index + 1).padStart(2, '0')}`,
        kind,
        ...entry,
      });
    }
  };
  append('grammar', chapter.grammar);
  append('vocabulary', chapter.vocabulary);
  append('quiz', chapter.quiz);
  copy.lessons.push({
    slug: lessonSlug,
    number: copy.lessons.length + 1,
    title: chapter.title,
    goal: chapter.goal,
    activities,
  });
}
fs.writeFileSync(target, `${JSON.stringify(copy, null, 2)}\n`);
console.log(`Built ${copy.lessons.length} A1+ revision lessons, including ${chapters.length} transcript-aligned chapters, at ${target}.`);
