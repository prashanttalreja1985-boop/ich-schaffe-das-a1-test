import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('expanded curriculum has ordered lessons, phases, and valid quizzes',
      () async {
    final raw = await rootBundle.loadString('assets/starter_content.json');
    final curriculum = Curriculum.fromJson(jsonDecode(raw));
    expect(curriculum.activities.length, greaterThan(1400));
    final lessonNumbers = curriculum.activities.map((a) => a.lessonNumber).toList();
    expect(lessonNumbers, orderedEquals([...lessonNumbers]..sort()));
    expect(lessonNumbers.toSet().length, 35);
    for (final number in lessonNumbers.toSet()) {
      final phases = curriculum.activities
          .where((a) => a.lessonNumber == number)
          .map((a) => a.kind)
          .toList();
      expect(phases, containsAll(['grammar', 'vocabulary', 'quiz']));
      expect(phases, orderedEquals([...phases]..sort((a, b) =>
        ['grammar', 'vocabulary', 'quiz'].indexOf(a).compareTo(
          ['grammar', 'vocabulary', 'quiz'].indexOf(b)))));
    }
    for (final activity in curriculum.activities.where((a) => a.kind == 'quiz')) {
      final options = activity.payload['options'] as List<dynamic>;
      final answer = activity.payload['answer'] as int;
      expect(answer, inInclusiveRange(0, options.length - 1));
      expect(options.toSet().length, options.length);
    }
  });
}
