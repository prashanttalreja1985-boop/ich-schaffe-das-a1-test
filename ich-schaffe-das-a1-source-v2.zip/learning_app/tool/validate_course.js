const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const course = JSON.parse(fs.readFileSync(path.join(root, 'assets', 'starter_content.json'), 'utf8'));
const audit = JSON.parse(fs.readFileSync(path.join(__dirname, 'video_coverage_0emzztSmKjA.json'), 'utf8'));
function check(condition, message) { if (!condition) throw new Error(message); }
const slugs = new Set();
const lessonSlugs = new Set();
let count = 0;
for (const [i, lesson] of course.lessons.entries()) {
  check(lesson.number === i + 1, `Lesson order at ${lesson.slug}`);
  check(!lessonSlugs.has(lesson.slug), `Duplicate lesson ${lesson.slug}`);
  lessonSlugs.add(lesson.slug);
  const phases = lesson.activities.map(a => a.kind);
  check(['grammar', 'vocabulary', 'quiz'].every(k => phases.includes(k)), `Missing phase: ${lesson.slug}`);
  check(phases.join(',') === [...phases].sort((a, b) =>
    ['grammar', 'vocabulary', 'quiz'].indexOf(a) - ['grammar', 'vocabulary', 'quiz'].indexOf(b)).join(','),
    `Phase order: ${lesson.slug}`);
  for (const a of lesson.activities) {
    check(!slugs.has(a.slug), `Duplicate activity ${a.slug}`);
    slugs.add(a.slug);
    if (a.kind === 'quiz') {
      check(a.options.length >= 3 && new Set(a.options).size === a.options.length, `Quiz options ${a.slug}`);
      check(Number.isInteger(a.answer) && a.answer >= 0 && a.answer < a.options.length, `Quiz answer ${a.slug}`);
      check(a.question && a.explanation, `Quiz prompt ${a.slug}`);
    }
    if (a.kind === 'vocabulary') check(a.items.every(x => x.de && x.en && x.example), `Vocabulary ${a.slug}`);
    if (a.kind === 'grammar') check(a.body && a.example, `Grammar ${a.slug}`);
    count++;
  }
}
check(audit.minutes.length === 55, 'Video minute count');
audit.minutes.forEach((m, i) => {
  check(m.minute === i && m.concept, `Video minute ${i}`);
  check(m.lessons.length > 0 && m.lessons.every(slug => lessonSlugs.has(slug)), `Video mapping ${i}`);
});
console.log(`Validated ${course.lessons.length} lessons, ${count} activities, and all 55 video minute mappings.`);
