-- Progress belongs to a Supabase account. The profile_key column remains for
-- compatibility with the existing score trigger, but must equal that account.
drop table if exists public.learner_profiles;

alter table public.learner_activity_progress
  add constraint learner_activity_account_key
  check (profile_key = user_id::text);

alter table public.learner_answers
  add constraint learner_answers_account_key
  check (profile_key = user_id::text);

alter table public.learner_game_progress
  add constraint learner_games_account_key
  check (profile_key = user_id::text);

alter table public.learner_score_events
  add constraint learner_scores_account_key
  check (profile_key = user_id::text);


