create or replace function public.monthly_leaderboard()
returns table(rank bigint, label text, points integer, is_me boolean)
language sql security definer set search_path = ''
as $$
  select row_number() over (order by total.points desc, total.user_id),
    case when total.user_id = (select auth.uid()) then 'You'
      else 'Learner ' || upper(substr(md5(total.user_id::text), 1, 6)) end,
    total.points,
    total.user_id = (select auth.uid())
  from (
    select user_id, sum(points)::integer as points
    from public.learner_score_events
    where earned_at >= date_trunc('month', now())
    group by user_id
  ) total
  order by total.points desc, total.user_id
  limit 20;
$$;
revoke all on function public.monthly_leaderboard() from public, anon;
grant execute on function public.monthly_leaderboard() to authenticated;

