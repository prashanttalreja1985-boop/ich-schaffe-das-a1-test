-- Saved profile names are account-scoped so Google sign-in can restore the
-- profile chooser on another installation.
create table if not exists public.learner_profiles (
  user_id uuid not null references auth.users(id) on delete cascade,
  profile_key text not null check (length(trim(profile_key)) > 0),
  display_name text not null check (length(trim(display_name)) > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, profile_key)
);

alter table public.learner_profiles enable row level security;
create policy "read own profiles" on public.learner_profiles
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "insert own profiles" on public.learner_profiles
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "update own profiles" on public.learner_profiles
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
grant select, insert, update on public.learner_profiles to authenticated;
