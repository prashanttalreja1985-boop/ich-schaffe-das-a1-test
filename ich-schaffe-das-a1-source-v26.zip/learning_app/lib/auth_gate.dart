part of 'main.dart';

// A saved Supabase Google session is the only entrance to the course. The
// learner's auth UUID is also the progress key on this device and in Postgres.
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> with WidgetsBindingObserver {
  StreamSubscription<AuthState>? _subscription;
  User? _user;
  String? _bookSlug;
  String? _courseAsset;
  String _keywords = _starterReelKeywords;
  bool _reelsEnabled = true;
  bool _gamesEnabled = true;
  bool _loading = true;
  String? _error;
  int _request = 0;
  int _revision = 0;

  SupabaseClient? get _client => _supabaseUrl.isEmpty || _supabaseKey.isEmpty
      ? null : Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _subscription = _client?.auth.onAuthStateChange.listen((state) {
      if (state.event == AuthChangeEvent.signedIn ||
          state.event == AuthChangeEvent.signedOut ||
          state.event == AuthChangeEvent.userUpdated) {
        _refresh();
      }
    });
    _refresh();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  bool _isGoogleUser(User? user) => user != null &&
      !user.isAnonymous && user.appMetadata['provider'] == 'google';

  Future<void> _clearLegacyPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool('google_only_reset_v1') == true) return;
    for (final key in prefs.getKeys().toList()) {
      if (key == 'profiles' || key == 'last_profile' ||
          key == 'legacy_progress_owner' ||
          key == 'done:original-a1-starter' ||
          key.startsWith('done:') || key.startsWith('answers:') ||
          key.startsWith('game-level:') || key.startsWith('keywords:') ||
          key.startsWith('reels:') || key.startsWith('games:') ||
          key.startsWith('flagged:') || key.startsWith('reset-pending:')) {
        await prefs.remove(key);
      }
    }
    await prefs.setBool('google_only_reset_v1', true);
  }

  Future<void> _refresh({bool force = false}) async {
    final request = ++_request;
    if (!mounted) return;
    final client = _client;
    if (client == null) {
      setState(() {
        _loading = false;
        _error = 'This build is missing its Supabase connection.';
      });
      return;
    }
    try {
      await _clearLegacyPreferences();
      var user = client.auth.currentUser;
      if (user?.isAnonymous == true) {
        await client.auth.signOut();
        user = null;
      }
      if (!_isGoogleUser(user)) {
        if (!mounted || request != _request) return;
        setState(() {
          _user = null;
          _bookSlug = null;
          _courseAsset = null;
          _loading = false;
          _error = null;
        });
        return;
      }
      if (!force && _user?.id == user!.id && _bookSlug != null) return;
      if (mounted) setState(() => _loading = true);
      final prefs = await SharedPreferences.getInstance();
      final key = user!.id;
      final a1 = LearningStore('assets/starter_content.json',
          'original-a1-starter', key);
      final curriculum = await a1.load();
      final completed = await a1.completed(curriculum);
      final a1Complete = curriculum.activities.isNotEmpty &&
          completed.length >= curriculum.activities.length;
      if (!mounted || request != _request) return;
      setState(() {
        _user = user;
        _bookSlug = a1Complete
            ? 'ich-schaffe-das-a1-plus' : 'original-a1-starter';
        _courseAsset = a1Complete
            ? 'assets/a1_plus_content.json' : 'assets/starter_content.json';
        _keywords = prefs.getString('keywords:$key') ?? _starterReelKeywords;
        _reelsEnabled = prefs.getBool('reels:$key') ?? true;
        _gamesEnabled = prefs.getBool('games:$key') ?? true;
        _loading = false;
        _error = null;
        if (force) _revision++;
      });
    } catch (error) {
      if (!mounted || request != _request) return;
      setState(() {
        _loading = false;
        _error = 'Could not restore your course: $error';
      });
    }
  }

  String _displayName(User user) {
    final metadata = user.userMetadata;
    final name = (metadata?['full_name'] ?? metadata?['name'])?.toString();
    if (name != null && name.trim().isNotEmpty) return name.trim();
    return user.email?.split('@').first ?? 'Learner';
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _subscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_user == null || _bookSlug == null || _courseAsset == null) {
      return _GoogleSignInScreen(error: _error);
    }
    return LearningScreen(
      key: ValueKey('${_user!.id}:$_bookSlug:$_revision'),
      courseAsset: _courseAsset!,
      bookSlug: _bookSlug!,
      profileKey: _user!.id,
      profileName: _displayName(_user!),
      keywords: parseInterestKeywords(_keywords),
      includeReels: _reelsEnabled,
      includeGames: _gamesEnabled,
      startAtActivity: false,
      onCourseCompleted: () => _refresh(force: true),
      onSettingsChanged: () => _refresh(force: true),
    );
  }
}

class _GoogleSignInScreen extends StatefulWidget {
  const _GoogleSignInScreen({this.error});
  final String? error;

  @override
  State<_GoogleSignInScreen> createState() => _GoogleSignInScreenState();
}

class _GoogleSignInScreenState extends State<_GoogleSignInScreen> {
  bool _busy = false;
  String? _error;

  Future<void> _signIn() async {
    if (_busy || _supabaseUrl.isEmpty || _supabaseKey.isEmpty) return;
    setState(() { _busy = true; _error = null; });
    try {
      final opened = await Supabase.instance.client.auth.signInWithOAuth(
        OAuthProvider.google,
        redirectTo: _googleRedirect,
        authScreenLaunchMode: LaunchMode.externalApplication,
      );
      if (!opened && mounted) {
        setState(() => _error = 'Could not open Google sign-in.');
      }
    } catch (error) {
      if (mounted) setState(() => _error = 'Google sign-in failed: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Padding(
      padding: const EdgeInsets.all(30),
      child: Column(mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Icon(Icons.auto_stories_rounded,
              size: 72, color: Color(0xFFF5C85B)),
          const SizedBox(height: 28),
          const Text('Ich schaffe das', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          const Text('Your German A1 course, one card at a time.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 17)),
          const SizedBox(height: 42),
          FilledButton.icon(onPressed: _busy ? null : _signIn,
              icon: const Icon(Icons.login_rounded),
              label: Text(_busy ? 'Opening Google…' :
                  'Sign in or sign up with Google')),
          const SizedBox(height: 12),
          const Text('Your progress is saved to your Google account.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white54)),
          if (_error != null || widget.error != null) ...[
            const SizedBox(height: 20),
            Text(_error ?? widget.error!, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.orangeAccent)),
          ],
        ]),
    )),
  );
}
