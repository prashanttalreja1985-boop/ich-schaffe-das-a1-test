create table if not exists public.learner_game_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  profile_key text not null check (length(trim(profile_key)) > 0),
  game_slug text not null check (game_slug in ('planks', 'territory')),
  highest_level integer not null default 1 check (highest_level between 1 and 20),
  updated_at timestamptz not null default now(),
  primary key (user_id, profile_key, game_slug)
);

alter table public.learner_game_progress enable row level security;

create policy "read own game progress" on public.learner_game_progress
  for select to authenticated
  using ((select auth.uid()) = user_id);
create policy "insert own game progress" on public.learner_game_progress
  for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy "update own game progress" on public.learner_game_progress
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

grant select, insert, update on public.learner_game_progress to authenticated;
