create policy "delete own progress" on public.learner_activity_progress
  for delete to authenticated using ((select auth.uid()) = user_id);
create policy "delete own answers" on public.learner_answers
  for delete to authenticated using ((select auth.uid()) = user_id);
create policy "delete own game progress" on public.learner_game_progress
  for delete to authenticated using ((select auth.uid()) = user_id);

grant delete on public.learner_activity_progress to authenticated;
grant delete on public.learner_answers to authenticated;
grant delete on public.learner_game_progress to authenticated;
