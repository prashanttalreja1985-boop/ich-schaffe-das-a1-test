-- One-time A1 curriculum regrouping. Activity slugs stay unchanged so saved
-- answers, flags, and learner progress continue to reference the same cards.
do $$
declare
  target_book uuid;
  source_lesson_count integer;
  source_activity_count integer;
  final_lesson_count integer;
  final_activity_count integer;
begin
  select id into strict target_book
  from public.learning_books
  where slug = 'original-a1-starter' and source_status = 'published';

  select count(*) into source_lesson_count
  from public.learning_lessons
  where book_id = target_book and slug in (
    'greetings', 'origin', 'sounds-greetings', 'alphabet-numbers',
    'questions-conversation', 'people-family', 'articles-gender',
    'present-tense', 'case-tables', 'possessives-negation',
    'sentence-links', 'daily-routine', 'time-calendar', 'dates-months-numbers',
    'food-drink', 'shopping-prices', 'home-rooms', 'city-directions',
    'prepositions', 'transport-travel', 'work-study', 'hobbies-free-time',
    'clothes-colours', 'body-health', 'weather-seasons', 'pronouns-cases',
    'perfect-past', 'past-participles', 'appointments-contact',
    'restaurant-service', 'instructions-imperative', 'comparisons-descriptions',
    'plans-permission', 'reading-writing', 'a1-review'
  );
  if source_lesson_count <> 35 then
    raise exception 'Expected 35 source A1 lessons, found %; nothing was changed.', source_lesson_count;
  end if;

  select count(*) into source_activity_count
  from public.learning_activities a
  join public.learning_lessons l on l.id = a.lesson_id
  where l.book_id = target_book;
  if source_activity_count <> 1406 then
    raise exception 'Expected 1406 A1 activities, found %; nothing was changed.', source_activity_count;
  end if;

  update public.learning_books
  set edition = 'Original expanded A1 course, 10-topic version'
  where id = target_book;

  -- Open lesson numbers 1-10 before creating the new topic-based rows.
  update public.learning_lessons
  set number = number + 1000
  where book_id = target_book;

  insert into public.learning_lessons (book_id, slug, number, title, goal)
  values
    (target_book, 'a1-start-and-introductions', 1, 'Start, Sounds and Introductions', 'Learn greetings, sounds, letters, numbers, personal details, and how to introduce people.'),
    (target_book, 'a1-people-nouns-and-articles', 2, 'People, Nouns and Articles', 'Learn noun gender and articles, then use core cases, pronouns, possessives, and negation.'),
    (target_book, 'a1-verbs-sentences-and-routines', 3, 'Verbs, Sentences and Daily Routines', 'Conjugate common present-tense verbs, build statements and questions, and describe a daily routine.'),
    (target_book, 'a1-time-dates-and-appointments', 4, 'Time, Dates and Appointments', 'Tell the time, use days and dates, and arrange or change appointments.'),
    (target_book, 'a1-food-shopping-and-home', 5, 'Food, Shopping and Home', 'Talk about meals, shop and ask prices, describe a home, and order in a restaurant.'),
    (target_book, 'a1-city-directions-and-travel', 6, 'City, Directions and Travel', 'Ask for places and directions, use common prepositions, and manage everyday travel.'),
    (target_book, 'a1-work-study-and-free-time', 7, 'Work, Study, Free Time and Plans', 'Talk about jobs, learning, hobbies, invitations, plans, permission, and obligations.'),
    (target_book, 'a1-clothes-health-weather-and-description', 8, 'Clothes, Health, Weather and Description', 'Describe clothing, health, weather, seasons, and compare people and things.'),
    (target_book, 'a1-past-and-written-communication', 9, 'Past Events and Written Communication', 'Talk about completed events with the Perfekt and understand everyday forms and short messages.'),
    (target_book, 'a1-requests-instructions-and-review', 10, 'Requests, Instructions and A1 Review', 'Make polite requests, understand simple instructions, and review the full A1 course.')
  on conflict (book_id, slug) do update
    set number = excluded.number, title = excluded.title, goal = excluded.goal;

  -- Avoid sequence_number collisions while cards move between source lessons.
  update public.learning_activities a
  set sequence_number = a.sequence_number + 10000
  from public.learning_lessons l
  where a.lesson_id = l.id and l.book_id = target_book;

  with source_map (source_slug, target_slug, member_order) as (
    values
      ('greetings', 'a1-start-and-introductions', 1),
      ('origin', 'a1-start-and-introductions', 2),
      ('sounds-greetings', 'a1-start-and-introductions', 3),
      ('alphabet-numbers', 'a1-start-and-introductions', 4),
      ('questions-conversation', 'a1-start-and-introductions', 5),
      ('people-family', 'a1-start-and-introductions', 6),
      ('articles-gender', 'a1-people-nouns-and-articles', 1),
      ('case-tables', 'a1-people-nouns-and-articles', 2),
      ('possessives-negation', 'a1-people-nouns-and-articles', 3),
      ('pronouns-cases', 'a1-people-nouns-and-articles', 4),
      ('present-tense', 'a1-verbs-sentences-and-routines', 1),
      ('sentence-links', 'a1-verbs-sentences-and-routines', 2),
      ('daily-routine', 'a1-verbs-sentences-and-routines', 3),
      ('time-calendar', 'a1-time-dates-and-appointments', 1),
      ('dates-months-numbers', 'a1-time-dates-and-appointments', 2),
      ('appointments-contact', 'a1-time-dates-and-appointments', 3),
      ('food-drink', 'a1-food-shopping-and-home', 1),
      ('shopping-prices', 'a1-food-shopping-and-home', 2),
      ('home-rooms', 'a1-food-shopping-and-home', 3),
      ('restaurant-service', 'a1-food-shopping-and-home', 4),
      ('city-directions', 'a1-city-directions-and-travel', 1),
      ('prepositions', 'a1-city-directions-and-travel', 2),
      ('transport-travel', 'a1-city-directions-and-travel', 3),
      ('work-study', 'a1-work-study-and-free-time', 1),
      ('hobbies-free-time', 'a1-work-study-and-free-time', 2),
      ('plans-permission', 'a1-work-study-and-free-time', 3),
      ('clothes-colours', 'a1-clothes-health-weather-and-description', 1),
      ('body-health', 'a1-clothes-health-weather-and-description', 2),
      ('weather-seasons', 'a1-clothes-health-weather-and-description', 3),
      ('comparisons-descriptions', 'a1-clothes-health-weather-and-description', 4),
      ('perfect-past', 'a1-past-and-written-communication', 1),
      ('past-participles', 'a1-past-and-written-communication', 2),
      ('reading-writing', 'a1-past-and-written-communication', 3),
      ('instructions-imperative', 'a1-requests-instructions-and-review', 1),
      ('a1-review', 'a1-requests-instructions-and-review', 2)
  ), ranked_cards as (
    select a.id as activity_id, target.id as target_lesson_id,
      row_number() over (
        partition by map.target_slug
        order by case a.kind when 'grammar' then 1 when 'vocabulary' then 2 else 3 end,
          map.member_order, a.sequence_number
      )::integer as target_sequence
    from source_map map
    join public.learning_lessons source
      on source.book_id = target_book and source.slug = map.source_slug
    join public.learning_activities a on a.lesson_id = source.id
    join public.learning_lessons target
      on target.book_id = target_book and target.slug = map.target_slug
  )
  update public.learning_activities a
  set lesson_id = ranked.target_lesson_id,
      sequence_number = ranked.target_sequence
  from ranked_cards ranked
  where a.id = ranked.activity_id;

  delete from public.learning_lessons
  where book_id = target_book and slug in (
    'greetings', 'origin', 'sounds-greetings', 'alphabet-numbers',
    'questions-conversation', 'people-family', 'articles-gender',
    'present-tense', 'case-tables', 'possessives-negation',
    'sentence-links', 'daily-routine', 'time-calendar', 'dates-months-numbers',
    'food-drink', 'shopping-prices', 'home-rooms', 'city-directions',
    'prepositions', 'transport-travel', 'work-study', 'hobbies-free-time',
    'clothes-colours', 'body-health', 'weather-seasons', 'pronouns-cases',
    'perfect-past', 'past-participles', 'appointments-contact',
    'restaurant-service', 'instructions-imperative', 'comparisons-descriptions',
    'plans-permission', 'reading-writing', 'a1-review'
  );

  select count(*) into final_lesson_count
  from public.learning_lessons where book_id = target_book;
  select count(*) into final_activity_count
  from public.learning_activities a
  join public.learning_lessons l on l.id = a.lesson_id
  where l.book_id = target_book;
  if final_lesson_count <> 10 or final_activity_count <> 1406 then
    raise exception 'Unexpected result after regrouping: % lessons, % activities.',
      final_lesson_count, final_activity_count;
  end if;
end $$;
