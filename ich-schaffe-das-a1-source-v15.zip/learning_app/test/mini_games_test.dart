import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/mini_games.dart';

void main() {
  test('both games expose twenty levels with growing boards and blockers', () {
    final planks = plankLevels();
    final territories = TerritoryLevel.all();
    expect(planks, hasLength(20));
    expect(territories, hasLength(20));
    expect(planks.first.pieces.where((piece) => !piece.target), hasLength(1));
    expect(planks[3].pieces.where((piece) => !piece.target), hasLength(4));
    expect(planks[19].pieces.length, greaterThan(planks[3].pieces.length));
    expect(territories.first.size, lessThan(territories.last.size));
    for (final level in territories) {
      expect(level.blocked.intersection(level.playerSeeds), isEmpty);
      expect(level.blocked.intersection(level.opponentSeeds), isEmpty);
    }
  });

  test('territory expands from a tapped adjacent cell and can win', () {
    final level = TerritoryLevel(number: 1, size: 5, blocked: const {},
        playerSeeds: const {0, 5}, opponentSeeds: const {24, 19});
    final game = TerritoryGameState(level);
    expect(game.isAvailableToPlayer(1), isTrue);
    expect(game.isAvailableToPlayer(24), isFalse);
    expect(game.tap(1), isTrue);
    expect(game.cells[1], 1);
    expect(game.playerCount, greaterThan(2));
    expect(game.opponentCount, greaterThan(2));
  });
}
