import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/feed_plan.dart';

void main() {
  test('opens with four Shorts and adds a break after each four cards', () {
    final feed = planSessionFeed(
      firstUnfinishedActivity: 0,
      activityCount: 24,
      availableShorts: 2,
      reelsEnabled: true,
    );
    expect(feed.take(4).map((slot) => slot.shortIndex), [0, 1, 0, 1]);
    expect(feed.where((slot) => slot.isActivity), hasLength(24));
    expect(feed.where((slot) => slot.isShort), hasLength(10));
    for (var i = 0; i < 6; i++) {
      expect(feed[4 + i * 5 + 4].isShort, isTrue);
    }
  });

  test('limits each lesson to four games across its full card range', () {
    final lessons = [
      ...List<int>.filled(40, 1),
      ...List<int>.filled(24, 2),
    ];
    final feed = planSessionFeed(
      firstUnfinishedActivity: 0,
      activityCount: lessons.length,
      availableShorts: 3,
      lessonNumbers: lessons,
      reelsEnabled: true,
      gamesEnabled: true,
    );
    expect(feed.take(4).every((slot) => slot.isShort), isTrue);
    expect(feed.where((slot) => slot.isGame), hasLength(8));
    expect(feed.where((slot) => slot.isShort), hasLength(12));
    expect(feed.where((slot) => slot.isActivity), hasLength(64));
  });

  test('resuming a lesson does not schedule more than four games', () {
    final lessons = List<int>.filled(40, 1);
    final feed = planSessionFeed(
      firstUnfinishedActivity: 20,
      activityCount: lessons.length,
      availableShorts: 1,
      lessonNumbers: lessons,
      reelsEnabled: true,
      gamesEnabled: true,
    );
    expect(feed.where((slot) => slot.isGame).length, lessThanOrEqualTo(4));
    expect(feed.where((slot) => slot.isActivity), hasLength(20));
  });

  test('keeps lessons usable with both modes off', () {
    final feed = planSessionFeed(
      firstUnfinishedActivity: 2,
      activityCount: 6,
      availableShorts: 0,
      reelsEnabled: false,
      gamesEnabled: false,
    );
    expect(feed.map((slot) => slot.activityIndex), [2, 3, 4, 5]);
  });
}
