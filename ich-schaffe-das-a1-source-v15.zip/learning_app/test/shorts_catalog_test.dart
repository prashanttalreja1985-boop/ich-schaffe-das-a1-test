import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/shorts_catalog.dart';

void main() {
  test('only Shorts matching entered interests are returned', () {
    final catalog = [
      YoutubeShort('one', 'German words', 'A', ['german', 'language']),
      YoutubeShort('two', 'Football skill', 'B', ['football', 'sports']),
      YoutubeShort('three', 'Nature', 'C', ['travel', 'nature']),
    ];
    final ranked = rankShorts(catalog, parseInterestKeywords(' football, travel '));
    expect(ranked.map((item) => item.id), ['two', 'three']);
  });

  test('no interests do not fall back to the whole catalog', () {
    final catalog = [
      YoutubeShort('one', 'German words', 'A', ['german', 'language']),
    ];
    expect(rankShorts(catalog, const []), isEmpty);
  });

  test('partial words do not accidentally match unrelated interests', () {
    final catalog = [
      YoutubeShort('one', 'Education tips', 'A', ['education']),
      YoutubeShort('two', 'Cat care', 'B', ['cats']),
    ];
    expect(rankShorts(catalog, ['cat']).map((item) => item.id), ['two']);
  });
}
