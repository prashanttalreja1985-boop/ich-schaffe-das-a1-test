import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/youtube_search.dart';

void main() {
  test('searches embeddable short videos for an interest hashtag', () {
    final uri = youtubeSearchUri('#football');
    expect(uri.queryParameters['q'], '#football #shorts');
    expect(uri.queryParameters['type'], 'video');
    expect(uri.queryParameters['videoDuration'], 'short');
    expect(uri.queryParameters['videoEmbeddable'], 'true');
  });

  test('reads playable IDs and captions from search results', () {
    final videos = parseYoutubeSearch('''{
      "items": [
        {"id": {"videoId": "AbCdEfGh123"},
         "snippet": {"title": "Football tricks", "channelTitle": "Club"}},
        {"id": {"videoId": "bad"}, "snippet": {"title": "Ignore"}}
      ]
    }''', 'football');
    expect(videos, hasLength(1));
    expect(videos.single.id, 'AbCdEfGh123');
    expect(videos.single.title, 'Football tricks');
    expect(videos.single.channel, 'Club');
  });
}
