// Original A1 curriculum authored for this app. No book text is copied here.
// Run with: node tool/build_a1_course.js
const fs = require('node:fs');
const path = require('node:path');

const out = path.join(__dirname, '..', 'assets', 'starter_content.json');
const base = JSON.parse(fs.readFileSync(out, 'utf8'));
const seedPath = path.join(__dirname, 'a1_seed_lessons.json');
const seed = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
const lessons = seed.lessons.map(lesson => ({...lesson}));

// Each row: German | English | short German example. Keep the article with nouns.
const plans = [
  {
    slug: 'alphabet-numbers', title: 'Buchstaben und Zahlen', goal: 'Spell names, exchange phone numbers, and count.',
    grammar: [
      ['Spell it', 'German letters have names. Ask Wie schreibt man das? or Können Sie das bitte buchstabieren? Ä, Ö and Ü are separate vowel sounds; ß is called Eszett. Say a name one letter at a time.', 'Wie schreibt man „Müller“? — M-Ü-L-L-E-R.'],
      ['Numbers and questions', 'Use Wie viel? for an amount and Wie viele? before a plural noun. The numbers 13–19 end in -zehn; in 21–99 say the unit before und and the ten: einundzwanzig.', 'Wie viele Bücher hast du? — Drei.'],
    ],
    vocab: `null|zero|Die Nummer ist null.;eins|one|Ich habe ein Buch.;zwei|two|Wir sind zwei Personen.;drei|three|Drei Äpfel, bitte.;vier|four|Es ist vier Uhr.;fünf|five|Fünf Euro, bitte.;zehn|ten|Zehn Minuten.;zwanzig|twenty|Ich bin zwanzig.;hundert|hundred|Das kostet hundert Euro.;die Zahl|number|Schreib die Zahl auf.;die Telefonnummer|phone number|Meine Telefonnummer ist neu.;buchstabieren|to spell|Bitte buchstabieren Sie Ihren Namen.`,
    quizzes: [
      ['What is 21 in German?', 'einundzwanzig', 'zwanzigeins', 'einszwanzig', 'The unit comes before und and the ten.'],
      ['Ask someone politely to spell a name.', 'Können Sie das bitte buchstabieren?', 'Wo wohnen Sie?', 'Wie alt sind Sie?', 'Use buchstabieren for spelling.'],
    ],
    verbs: ['haben'],
  },
  {
    slug: 'people-family', title: 'Menschen und Familie', goal: 'Describe family and relationships.',
    grammar: [
      ['Possessive words', 'Mein means my and dein means your (informal). Before feminine or plural nouns add -e in the nominative: meine Mutter, deine Eltern. Use Ihr for polite your.', 'Das ist mein Bruder. Das ist meine Schwester.'],
      ['Plural nouns', 'German plurals have several patterns: der Bruder → die Brüder, die Tochter → die Töchter, das Kind → die Kinder. Learn each plural with the noun. All plural nouns use die in the nominative.', 'Das Kind spielt. Die Kinder spielen.'],
    ],
    vocab: `die Mutter|mother|Meine Mutter heißt Eva.;der Vater|father|Mein Vater arbeitet heute.;die Schwester|sister|Meine Schwester wohnt hier.;der Bruder|brother|Mein Bruder ist zwölf.;die Eltern|parents|Meine Eltern kommen morgen.;das Kind|child|Das Kind spielt.;die Tochter|daughter|Ihre Tochter lernt Deutsch.;der Sohn|son|Sein Sohn ist klein.;die Großmutter|grandmother|Meine Großmutter ist nett.;der Großvater|grandfather|Mein Großvater wohnt in Bonn.;die Familie|family|Meine Familie ist groß.;verheiratet|married|Meine Eltern sind verheiratet.`,
    quizzes: [
      ['Complete: Das ist ___ Mutter.', 'meine', 'mein', 'meinen', 'Mutter is feminine, so use meine.'],
      ['Complete: Die Kinder ___ hier.', 'spielen', 'spielt', 'spielst', 'Plural subjects take the -en verb form.'],
    ],
    verbs: ['sein', 'heißen'],
  },
  {
    slug: 'articles-gender', title: 'Der, die, das', goal: 'Learn noun gender and indefinite articles.',
    grammar: [
      ['Three noun genders', 'Every German noun has a grammatical gender. In the nominative, use der for masculine, die for feminine, and das for neuter. Always memorize a noun together with its article and plural. Capitalize nouns.', 'der Tisch, die Lampe, das Fenster'],
      ['A and an', 'The indefinite articles are ein (masculine), eine (feminine), and ein (neuter) in the nominative. There is no indefinite article in the plural. The gender belongs to the noun, not the object.', 'Das ist ein Tisch. Das ist eine Lampe.'],
      ['This is / these are', 'Use Das ist for one object and Das sind for several. After Das ist, a noun phrase is usually nominative.', 'Das ist ein Stuhl. Das sind Stühle.'],
    ],
    vocab: `der Tisch|table|Der Tisch ist neu.;die Lampe|lamp|Die Lampe ist hell.;das Fenster|window|Das Fenster ist offen.;der Stuhl|chair|Der Stuhl ist bequem.;die Tür|door|Die Tür ist zu.;das Buch|book|Das Buch ist interessant.;der Schlüssel|key|Der Schlüssel liegt hier.;die Tasche|bag|Die Tasche ist blau.;das Handy|mobile phone|Das Handy ist neu.;der Computer|computer|Der Computer ist schnell.;die Uhr|clock or watch|Die Uhr ist klein.;das Bild|picture|Das Bild ist schön.`,
    quizzes: [
      ['Complete: Das ist ___ Lampe.', 'eine', 'ein', 'einen', 'Lampe is feminine.'],
      ['Which word must be capitalized in German?', 'Tisch', 'schön', 'und', 'Nouns are capitalized.'],
    ],
    verbs: ['liegen'],
  },
  {
    slug: 'present-tense', title: 'Verben im Präsens', goal: 'Form regular present-tense verbs and simple statements.',
    grammar: [
      ['Regular endings', 'Remove -en from a regular infinitive and add -e, -st, -t, -en, -t, -en for ich, du, er/sie/es, wir, ihr, sie/Sie. Examples with machen: mache, machst, macht, machen, macht, machen.', 'Ich lerne. Du lernst. Wir lernen.'],
      ['The verb in position two', 'In a normal statement, the conjugated verb is the second idea. A time expression can come first, but the verb still comes second and the subject moves after it.', 'Heute lerne ich Deutsch. Ich lerne heute Deutsch.'],
      ['Questions without a question word', 'For yes/no questions, put the conjugated verb first. For W-questions, put the question word first and verb second.', 'Lernst du Deutsch? Wo lernst du Deutsch?'],
    ],
    vocab: `lernen|to learn|Ich lerne Deutsch.;machen|to do or make|Was machst du?;spielen|to play|Wir spielen Fußball.;arbeiten|to work|Sie arbeitet heute.;fragen|to ask|Ich frage den Lehrer.;antworten|to answer|Er antwortet schnell.;hören|to hear or listen|Hörst du Musik?;sagen|to say|Sag das bitte noch einmal.;schreiben|to write|Ich schreibe eine Nachricht.;lesen|to read|Du liest ein Buch.;üben|to practice|Wir üben jeden Tag.;verstehen|to understand|Verstehen Sie mich?`,
    quizzes: [
      ['Put the verb in position two: Heute ___ ich Deutsch.', 'lerne', 'ich lerne', 'lernen', 'After Heute, the verb comes before ich.'],
      ['Choose the yes/no question.', 'Lernst du Deutsch?', 'Du lernst Deutsch?', 'Wo du lernst?', 'The conjugated verb starts a yes/no question.'],
    ],
    verbs: ['lernen', 'machen', 'spielen', 'arbeiten', 'hören', 'schreiben', 'lesen'],
  },
  {
    slug: 'daily-routine', title: 'Mein Tag', goal: 'Describe routine and separable verbs.',
    grammar: [
      ['Separable verbs', 'Some verbs have a prefix that moves to the end of a main clause. Aufstehen becomes ich stehe ... auf. The infinitive and modal construction keep the prefix attached.', 'Ich stehe um sieben Uhr auf. Ich muss früh aufstehen.'],
      ['Time expressions', 'Say um sieben Uhr for a clock time, am Montag for a day, and morgens/abends for a recurring time of day. First state when, then what happens.', 'Am Montag fange ich um acht Uhr an.'],
    ],
    vocab: `aufstehen|to get up|Ich stehe früh auf.;frühstücken|to have breakfast|Wir frühstücken um acht Uhr.;anfangen|to begin|Der Kurs fängt um neun Uhr an.;einkaufen|to shop|Ich kaufe am Samstag ein.;fernsehen|to watch television|Sie sieht abends fern.;schlafen|to sleep|Das Kind schläft.;duschen|to shower|Ich dusche morgens.;die Pause|break|Die Pause ist um zwölf Uhr.;der Morgen|morning|Am Morgen trinke ich Tee.;der Abend|evening|Am Abend lese ich.;der Alltag|daily life|Mein Alltag ist ruhig.;spät|late|Heute komme ich spät.`,
    quizzes: [
      ['Complete: Ich stehe um sieben Uhr ___.', 'auf', 'an', 'ein', 'Aufstehen separates into stehe ... auf.'],
      ['Complete: Der Kurs ___ um neun Uhr an.', 'fängt', 'fangt', 'fange', 'Anfangen has vowel change a → ä with er/sie/es.'],
    ],
    verbs: ['aufstehen', 'anfangen', 'einkaufen', 'fernsehen', 'schlafen'],
  },
  {
    slug: 'time-calendar', title: 'Uhrzeit und Kalender', goal: 'Tell time, days, dates, and appointments.',
    grammar: [
      ['Clock time', 'Use Es ist ... Uhr for exact time. In conversation, halb acht means 7:30, because German names the coming hour. Viertel nach acht is 8:15; Viertel vor acht is 7:45.', 'Es ist halb acht. Der Bus kommt um Viertel vor acht.'],
      ['Days and dates', 'Use am with days and dates: am Dienstag, am dritten Mai. Use im with months and seasons: im Mai, im Sommer. Ordinals in dates change endings.', 'Mein Termin ist am dritten Mai.'],
    ],
    vocab: `der Montag|Monday|Am Montag arbeite ich.;der Dienstag|Tuesday|Am Dienstag habe ich Zeit.;der Mittwoch|Wednesday|Am Mittwoch lernen wir.;der Donnerstag|Thursday|Am Donnerstag koche ich.;der Freitag|Friday|Am Freitag gehe ich aus.;der Samstag|Saturday|Am Samstag kaufe ich ein.;der Sonntag|Sunday|Am Sonntag schlafe ich länger.;der Termin|appointment|Ich habe einen Termin.;die Minute|minute|Warte eine Minute.;die Stunde|hour|Der Kurs dauert eine Stunde.;heute|today|Heute ist Montag.;morgen|tomorrow|Morgen komme ich.`,
    quizzes: [
      ['What time is halb acht?', '7:30', '8:30', '7:15', 'Halb names the coming hour.'],
      ['Complete: ___ Montag habe ich Zeit.', 'Am', 'Im', 'Um', 'Use am with a day.'],
      ['Complete: Der Kurs beginnt ___ neun Uhr.', 'um', 'am', 'im', 'Use um with a clock time.'],
    ],
    verbs: ['beginnen', 'kommen'],
  },
  {
    slug: 'food-drink', title: 'Essen und Trinken', goal: 'Order food and describe meals.',
    grammar: [
      ['Accusative objects', 'A direct object answers what or whom. Only the masculine article changes in the accusative: der → den and ein → einen. Feminine die/eine and neuter das/ein stay the same.', 'Ich esse einen Apfel. Ich trinke eine Limonade.'],
      ['Likes and preferences', 'Use gern after a verb for “like doing”: Ich koche gern. Use lieber for “prefer”: Ich trinke lieber Tee. Mögen also expresses liking: Ich mag Kaffee.', 'Ich esse gern Brot. Ich mag Käse.'],
    ],
    vocab: `das Brot|bread|Ich esse Brot.;der Käse|cheese|Der Käse ist lecker.;die Milch|milk|Ich trinke Milch.;das Wasser|water|Ein Wasser, bitte.;der Kaffee|coffee|Der Kaffee ist heiß.;der Tee|tea|Ich trinke Tee.;der Apfel|apple|Ich esse einen Apfel.;die Banane|banana|Die Banane ist gelb.;das Ei|egg|Das Ei ist gekocht.;die Suppe|soup|Die Suppe ist warm.;das Gemüse|vegetables|Ich kaufe Gemüse.;das Frühstück|breakfast|Das Frühstück ist fertig.`,
    quizzes: [
      ['Complete: Ich esse ___ Apfel.', 'einen', 'ein', 'eine', 'Apfel is masculine and the direct object is accusative.'],
      ['Complete: Ich ___ gern Tee.', 'trinke', 'trinkst', 'trinkt', 'Ich takes trinke.'],
    ],
    verbs: ['essen', 'trinken', 'mögen', 'kochen'],
  },
  {
    slug: 'shopping-prices', title: 'Einkaufen', goal: 'Ask prices, quantities, and make purchases.',
    grammar: [
      ['Polite requests', 'Ich hätte gern ... is a polite way to order or request something. Bitte and danke make exchanges natural. Use Was kostet ...? for one item and Was kosten ...? for several.', 'Ich hätte gern zwei Brötchen, bitte. Was kosten sie?'],
      ['Quantity and negation', 'Use kein to negate a noun: kein Brot, keine Milch, keinen Apfel (masculine accusative). Nicht negates a verb, adjective, or whole statement.', 'Ich habe keinen Kaffee. Der Tee ist nicht heiß.'],
    ],
    vocab: `der Preis|price|Der Preis ist gut.;das Geld|money|Ich habe kein Geld dabei.;der Euro|euro|Das kostet drei Euro.;die Kasse|checkout|Die Kasse ist dort.;der Markt|market|Der Markt ist heute offen.;das Geschäft|shop|Das Geschäft schließt um sechs.;die Bäckerei|bakery|Die Bäckerei ist nebenan.;das Brötchen|bread roll|Zwei Brötchen, bitte.;die Flasche|bottle|Eine Flasche Wasser, bitte.;das Kilo|kilogram|Ein Kilo Äpfel, bitte.;billig|cheap|Das ist billig.;teuer|expensive|Die Jacke ist teuer.`,
    quizzes: [
      ['Complete: Ich habe ___ Apfel.', 'keinen', 'kein', 'keine', 'Masculine accusative takes keinen.'],
      ['Ask the price of one book.', 'Was kostet das Buch?', 'Was kosten das Buch?', 'Wie viel Bücher?', 'One item takes kostet.'],
    ],
    verbs: ['kaufen', 'bezahlen'],
  },
  {
    slug: 'home-rooms', title: 'Zu Hause', goal: 'Name rooms and describe where things are.',
    grammar: [
      ['There is / there are', 'Use es gibt + accusative to say something exists. For a location, use ist/sind or stehen/liegen: Das Bett steht im Zimmer.', 'In der Wohnung gibt es eine Küche.'],
      ['Location with dative', 'When in, an, auf, unter, über, vor, hinter, neben or zwischen answers Where?, use dative. Common forms: in dem → im, an dem → am. Masculine/neuter der/das → dem; feminine die → der.', 'Das Buch liegt auf dem Tisch. Die Lampe steht in der Küche.'],
    ],
    vocab: `die Wohnung|apartment|Die Wohnung ist hell.;das Zimmer|room|Das Zimmer ist groß.;die Küche|kitchen|Die Küche ist klein.;das Bad|bathroom|Das Bad ist sauber.;das Schlafzimmer|bedroom|Das Schlafzimmer ist oben.;das Wohnzimmer|living room|Wir sitzen im Wohnzimmer.;das Bett|bed|Das Bett steht am Fenster.;das Sofa|sofa|Das Sofa ist bequem.;der Schrank|wardrobe or cupboard|Der Schrank ist weiß.;der Balkon|balcony|Der Balkon ist klein.;die Miete|rent|Die Miete ist hoch.;die Adresse|address|Wie ist Ihre Adresse?`,
    quizzes: [
      ['Complete: Das Buch liegt auf ___ Tisch.', 'dem', 'den', 'der', 'Where? takes dative; Tisch is masculine.'],
      ['Complete: In der Wohnung gibt es ___ Küche.', 'eine', 'ein', 'einen', 'Es gibt takes accusative; feminine remains eine.'],
    ],
    verbs: ['wohnen', 'sitzen', 'stehen'],
  },
  {
    slug: 'city-directions', title: 'In der Stadt', goal: 'Ask for places and give simple directions.',
    grammar: [
      ['Where or where to?', 'Wo? asks for a position; Wohin? asks for a destination. For motion to a place, use in + accusative: in den Park, in die Stadt. For position use in + dative: im Park, in der Stadt.', 'Ich gehe in den Park. Ich bin im Park.'],
      ['Simple directions', 'Use geradeaus, links and rechts. To ask politely: Entschuldigung, wo ist ...? For a destination, say Gehen Sie ... with polite Sie.', 'Gehen Sie geradeaus und dann links.'],
    ],
    vocab: `die Straße|street|Die Straße ist lang.;der Platz|square|Der Platz ist groß.;der Bahnhof|train station|Der Bahnhof ist nah.;die Haltestelle|stop|Die Haltestelle ist dort.;die Post|post office|Die Post ist links.;die Bank|bank|Die Bank ist neben der Post.;die Apotheke|pharmacy|Die Apotheke ist offen.;der Supermarkt|supermarket|Der Supermarkt ist rechts.;der Park|park|Wir gehen in den Park.;die Ampel|traffic light|An der Ampel links.;links|left|Gehen Sie links.;rechts|right|Die Bank ist rechts.`,
    quizzes: [
      ['Complete: Ich gehe in ___ Park.', 'den', 'dem', 'der', 'Wohin? uses accusative; Park is masculine.'],
      ['Complete: Ich bin ___ Park.', 'im', 'in den', 'in die', 'Wo? uses dative: in dem → im.'],
    ],
    verbs: ['gehen', 'finden', 'suchen'],
  },
  {
    slug: 'transport-travel', title: 'Unterwegs', goal: 'Travel, buy tickets, and describe routes.',
    grammar: [
      ['By transport', 'Use mit + dative for transport: mit dem Bus, mit der Bahn. Zu + dative means to a person or destination: zum Bahnhof, zur Schule.', 'Ich fahre mit dem Zug zum Bahnhof.'],
      ['Vowel-changing verbs', 'Some strong verbs change their stem vowel in du and er/sie/es: fahren → du fährst/er fährt; laufen → du läufst/er läuft. The wir and Sie forms keep the infinitive stem.', 'Du fährst heute nach Berlin.'],
    ],
    vocab: `der Bus|bus|Der Bus kommt gleich.;der Zug|train|Der Zug fährt um neun Uhr.;die Bahn|railway or train|Ich fahre mit der Bahn.;das Fahrrad|bicycle|Mein Fahrrad ist neu.;das Auto|car|Das Auto steht hier.;das Ticket|ticket|Ich kaufe ein Ticket.;die Fahrkarte|ticket|Die Fahrkarte kostet zehn Euro.;der Fahrplan|timetable|Der Fahrplan hängt dort.;die Reise|trip|Die Reise ist lang.;der Flughafen|airport|Der Flughafen ist weit weg.;abfahren|to depart|Der Zug fährt um acht Uhr ab.;ankommen|to arrive|Wir kommen um neun Uhr an.`,
    quizzes: [
      ['Complete: Ich fahre mit ___ Bus.', 'dem', 'den', 'der', 'Mit always takes dative.'],
      ['Complete: Du ___ nach Berlin.', 'fährst', 'fahrst', 'fahrt', 'Fahren changes a → ä with du.'],
    ],
    verbs: ['fahren', 'laufen', 'abfahren', 'ankommen'],
  },
  {
    slug: 'work-study', title: 'Arbeit und Lernen', goal: 'Talk about occupations, study, and ability.',
    grammar: [
      ['Jobs without an article', 'After sein, a profession often has no article: Ich bin Lehrer. With an adjective, an article is usual: Er ist ein guter Lehrer. Feminine forms often end in -in: Lehrer/Lehrerin.', 'Sie ist Ärztin. Er ist Student.'],
      ['Modal verb können', 'A modal verb is conjugated in second position; the second verb stays as an infinitive at the end. Können means can or be able to.', 'Ich kann Deutsch sprechen. Kannst du heute kommen?'],
    ],
    vocab: `der Beruf|profession|Was ist dein Beruf?;die Arbeit|work|Die Arbeit beginnt um neun.;der Lehrer|male teacher|Der Lehrer erklärt die Aufgabe.;die Lehrerin|female teacher|Die Lehrerin ist freundlich.;der Arzt|male doctor|Der Arzt arbeitet im Krankenhaus.;die Ärztin|female doctor|Die Ärztin hat heute Zeit.;der Student|male student|Der Student lernt viel.;die Studentin|female student|Die Studentin liest.;das Büro|office|Das Büro ist im Zentrum.;die Schule|school|Die Schule beginnt früh.;der Kurs|course|Der Kurs macht Spaß.;die Aufgabe|task|Die Aufgabe ist leicht.`,
    quizzes: [
      ['Complete: Ich ___ heute arbeiten.', 'kann', 'kannst', 'können', 'Ich kann plus infinitive at the end.'],
      ['Which sentence is natural for a profession?', 'Ich bin Lehrer.', 'Ich bin ein Lehrer.', 'Ich Lehrer bin.', 'After sein, a job title often has no article.'],
    ],
    verbs: ['können', 'sprechen', 'erklären'],
  },
  {
    slug: 'hobbies-free-time', title: 'Freizeit', goal: 'Talk about interests and invitations.',
    grammar: [
      ['Gern, lieber, am liebsten', 'Place gern after a verb to say you like an activity. Lieber compares two options; am liebsten names your favorite.', 'Ich spiele gern Tennis. Ich schwimme lieber.'],
      ['Modal verb wollen', 'Wollen expresses a wish or intention. Like other modal verbs, it sends the action infinitive to the end. In polite requests, möchte is softer than will.', 'Wir wollen heute tanzen. Ich möchte mitkommen.'],
    ],
    vocab: `die Freizeit|free time|In meiner Freizeit lese ich.;das Hobby|hobby|Mein Hobby ist Musik.;die Musik|music|Ich höre Musik.;der Film|film|Der Film ist lustig.;das Kino|cinema|Wir gehen ins Kino.;der Sport|sport|Ich mache gern Sport.;das Schwimmbad|swimming pool|Das Schwimmbad ist offen.;das Konzert|concert|Das Konzert beginnt um acht.;die Einladung|invitation|Danke für die Einladung.;tanzen|to dance|Wir tanzen am Samstag.;schwimmen|to swim|Ich schwimme gern.;treffen|to meet|Ich treffe meine Freunde.`,
    quizzes: [
      ['Complete: Wir ___ heute tanzen.', 'wollen', 'will', 'wollt', 'Wir takes wollen.'],
      ['Choose the polite wish.', 'Ich möchte einen Kaffee.', 'Ich will sofort Kaffee.', 'Ich habe Kaffee nicht.', 'Möchte is a softer way to request.'],
    ],
    verbs: ['wollen', 'möchten', 'treffen', 'schwimmen'],
  },
  {
    slug: 'clothes-colours', title: 'Kleidung und Farben', goal: 'Describe clothing, colors, and fit.',
    grammar: [
      ['Describing a noun', 'After sein, an adjective has no ending: Die Jacke ist rot. Before a noun, an adjective gets an ending: eine rote Jacke, ein rotes Hemd. At A1, learn common phrases as patterns.', 'Das Hemd ist blau. Das ist ein blaues Hemd.'],
      ['This one and size', 'Welche Größe? asks for size. Use dieser/diese/dieses before a masculine/feminine/neuter noun in nominative. In accusative masculine, dieser becomes diesen.', 'Diese Jacke gefällt mir. Ich nehme diesen Pullover.'],
    ],
    vocab: `die Jacke|jacket|Die Jacke ist rot.;das Hemd|shirt|Das Hemd ist weiß.;die Hose|trousers|Die Hose ist schwarz.;der Pullover|sweater|Der Pullover ist warm.;das Kleid|dress|Das Kleid ist schön.;der Schuh|shoe|Der Schuh ist neu.;die Größe|size|Welche Größe brauchen Sie?;die Farbe|color|Welche Farbe magst du?;rot|red|Die Jacke ist rot.;blau|blue|Das Hemd ist blau.;grün|green|Der Pullover ist grün.;schwarz|black|Die Hose ist schwarz.`,
    quizzes: [
      ['Complete: Das ist ___ Jacke.', 'eine rote', 'ein rot', 'einen roten', 'Jacke is feminine; use eine rote.'],
      ['Complete: Ich nehme ___ Pullover.', 'diesen', 'dieser', 'dieses', 'Masculine accusative of dieser is diesen.'],
    ],
    verbs: ['nehmen', 'brauchen', 'tragen'],
  },
  {
    slug: 'body-health', title: 'Körper und Gesundheit', goal: 'Describe symptoms and ask for help.',
    grammar: [
      ['I have pain', 'Use Ich habe Kopfschmerzen for a headache or Mein Kopf tut weh. For a body part: Mein Arm tut weh; Meine Beine tun weh. Use mir with Es geht mir gut/schlecht.', 'Mein Bauch tut weh. Mir geht es nicht gut.'],
      ['Must and should', 'Müssen expresses necessity; sollen can express advice or an instruction from someone else. A second verb remains at the end as an infinitive.', 'Ich muss zum Arzt gehen. Du sollst viel trinken.'],
    ],
    vocab: `der Kopf|head|Mein Kopf tut weh.;der Bauch|stomach|Mein Bauch tut weh.;der Arm|arm|Mein Arm tut weh.;das Bein|leg|Mein Bein tut weh.;die Hand|hand|Meine Hand ist kalt.;das Auge|eye|Mein Auge ist rot.;der Schmerz|pain|Der Schmerz ist stark.;das Fieber|fever|Ich habe Fieber.;die Erkältung|cold illness|Ich habe eine Erkältung.;das Medikament|medicine|Ich brauche ein Medikament.;das Krankenhaus|hospital|Das Krankenhaus ist hier.;gesund|healthy|Ich bin wieder gesund.`,
    quizzes: [
      ['Complete: Ich ___ zum Arzt gehen.', 'muss', 'musst', 'müssen', 'Ich muss plus infinitive at the end.'],
      ['Complete: Mein Arm ___ weh.', 'tut', 'tun', 'tust', 'Singular Arm takes tut.'],
    ],
    verbs: ['müssen', 'sollen', 'helfen'],
  },
  {
    slug: 'weather-seasons', title: 'Wetter und Jahreszeiten', goal: 'Talk about weather and seasonal plans.',
    grammar: [
      ['Weather expressions', 'German weather phrases often use es: Es regnet, es schneit, es ist kalt. To describe a day, say Heute ist es warm. A forecast can use morgen.', 'Heute regnet es. Morgen ist es sonnig.'],
      ['Because with denn', 'Denn gives a simple reason and keeps normal word order after it: Ich bleibe zu Hause, denn es regnet. Avoid moving the verb to the end after denn.', 'Ich nehme eine Jacke, denn es ist kalt.'],
    ],
    vocab: `das Wetter|weather|Wie ist das Wetter?;der Regen|rain|Der Regen ist stark.;der Schnee|snow|Im Winter gibt es Schnee.;die Sonne|sun|Die Sonne scheint.;der Wind|wind|Der Wind ist kalt.;der Frühling|spring|Im Frühling ist es warm.;der Sommer|summer|Im Sommer schwimme ich.;der Herbst|autumn|Im Herbst regnet es oft.;der Winter|winter|Im Winter schneit es.;warm|warm|Heute ist es warm.;kalt|cold|Im Winter ist es kalt.;sonnig|sunny|Morgen ist es sonnig.`,
    quizzes: [
      ['Complete: Ich bleibe zu Hause, denn es ___.', 'regnet', 'regnen', 'regne', 'Denn keeps normal verb order.'],
      ['Complete: ___ Winter schneit es.', 'Im', 'Am', 'Um', 'Use im with seasons.'],
    ],
    verbs: ['bleiben'],
  },
  {
    slug: 'pronouns-cases', title: 'Pronomen und Fälle', goal: 'Use subject, object, and indirect-object pronouns.',
    grammar: [
      ['Personal pronouns', 'Nominative: ich, du, er, sie, es, wir, ihr, sie, Sie. Accusative: mich, dich, ihn, sie, es, uns, euch, sie, Sie. An object after sehen or treffen is accusative.', 'Ich sehe ihn. Er sieht mich.'],
      ['Dative pronouns', 'Dative forms include mir, dir, ihm, ihr, ihm, uns, euch, ihnen, Ihnen. Some verbs, such as helfen and gefallen, take a dative object.', 'Kannst du mir helfen? Das gefällt ihr.'],
      ['Two objects', 'With a person and a thing, the person is often dative and the thing accusative: Ich gebe dem Kind das Buch. Pronouns can move before a noun object.', 'Ich gebe dir das Buch.'],
    ],
    vocab: `mich|me (accusative)|Er sieht mich.;dich|you (accusative)|Ich höre dich.;ihn|him|Ich kenne ihn.;uns|us|Sie besucht uns.;euch|you all (accusative)|Ich sehe euch.;mir|to me|Das gefällt mir.;dir|to you|Ich helfe dir.;ihm|to him|Ich gebe ihm das Buch.;ihr|to her|Das gefällt ihr.;geben|to give|Ich gebe dir das Buch.;gefallen|to please|Das Kleid gefällt mir.;kennen|to know a person|Ich kenne ihn.`,
    quizzes: [
      ['Complete: Kannst du ___ helfen?', 'mir', 'mich', 'ich', 'Helfen takes dative.'],
      ['Complete: Ich sehe ___. (him)', 'ihn', 'ihm', 'er', 'Sehen takes an accusative object.'],
      ['Complete: Ich gebe ___ das Buch. (to you)', 'dir', 'dich', 'du', 'The recipient is dative.'],
    ],
    verbs: ['geben', 'kennen'],
  },
  {
    slug: 'perfect-past', title: 'Was hast du gemacht?', goal: 'Talk about finished past events.',
    grammar: [
      ['Present perfect with haben', 'To discuss a completed event, use a conjugated form of haben and a past participle at the end. Regular participles often have ge- and -t: machen → gemacht, kaufen → gekauft.', 'Ich habe gestern gekocht. Wir haben Brot gekauft.'],
      ['Present perfect with sein', 'Many verbs of movement or change use sein: gehen → gegangen, fahren → gefahren, kommen → gekommen, aufstehen → aufgestanden. The participle stays at the end.', 'Ich bin nach Berlin gefahren.'],
      ['Common irregular participles', 'Some frequent verbs have -en participles: essen → gegessen, trinken → getrunken, lesen → gelesen, sehen → gesehen, schreiben → geschrieben. Learn these as pairs.', 'Ich habe ein Buch gelesen.'],
    ],
    vocab: `gestern|yesterday|Gestern war ich zu Hause.;letzte Woche|last week|Letzte Woche war ich krank.;gemacht|done or made|Ich habe die Aufgabe gemacht.;gekauft|bought|Wir haben Brot gekauft.;gegangen|gone|Sie ist nach Hause gegangen.;gefahren|travelled|Wir sind nach Berlin gefahren.;gegessen|eaten|Ich habe Suppe gegessen.;getrunken|drunk|Er hat Wasser getrunken.;gesehen|seen|Ich habe einen Film gesehen.;gelesen|read|Sie hat ein Buch gelesen.;geschrieben|written|Ich habe eine E-Mail geschrieben.;gewesen|been|Ich bin dort gewesen.`,
    quizzes: [
      ['Complete: Ich ___ gestern gekocht.', 'habe', 'bin', 'hat', 'Kochen forms the perfect with haben.'],
      ['Complete: Wir ___ nach Berlin gefahren.', 'sind', 'haben', 'hat', 'Fahren to a destination commonly takes sein.'],
      ['Past participle of essen?', 'gegessen', 'geesst', 'gesessen', 'Essen → gegessen.'],
      ['Past participle of schreiben?', 'geschrieben', 'geschreibt', 'geschreiben', 'Schreiben → geschrieben.'],
    ],
    verbs: ['haben', 'sein'],
  },
  {
    slug: 'appointments-contact', title: 'Termine und Nachrichten', goal: 'Arrange meetings and write short messages.',
    grammar: [
      ['Can we meet?', 'Use können to ask availability: Können wir uns morgen treffen? Use um for a time and am for a day. A short invitation can use Möchtest du ...?', 'Können wir uns am Freitag um 15 Uhr treffen?'],
      ['Simple message order', 'A short message names the recipient, reason, time/place and closes politely. Use Ich kann leider nicht kommen for declining and Passt dir ...? to propose a time.', 'Hallo Lea, ich kann heute leider nicht kommen. Passt dir morgen? Liebe Grüße, Ali.'],
    ],
    vocab: `die Nachricht|message|Ich schreibe eine Nachricht.;die E-Mail|email|Die E-Mail ist kurz.;der Anruf|phone call|Der Anruf kommt später.;der Kalender|calendar|Der Termin steht im Kalender.;die Verabredung|arrangement|Unsere Verabredung ist um drei.;die Einladung|invitation|Danke für die Einladung.;pünktlich|on time|Bitte sei pünktlich.;leider|unfortunately|Leider habe ich keine Zeit.;vielleicht|perhaps|Vielleicht komme ich morgen.;absagen|to cancel|Ich sage den Termin ab.;verschieben|to postpone|Wir verschieben den Termin.;bestätigen|to confirm|Bitte bestätigen Sie den Termin.`,
    quizzes: [
      ['Complete: Können wir uns ___ Freitag treffen?', 'am', 'im', 'um', 'Use am with a weekday.'],
      ['Complete: Ich sage den Termin ___.', 'ab', 'an', 'auf', 'Absagen separates into sage ... ab.'],
    ],
    verbs: ['absagen', 'verschieben', 'bestätigen'],
  },
  {
    slug: 'restaurant-service', title: 'Im Restaurant', goal: 'Order a meal and pay.',
    grammar: [
      ['Ordering politely', 'Use Ich hätte gern ... or Ich nehme ... to order. A masculine food item after nehmen uses einen; feminine uses eine; neuter uses ein. Zum Trinken ... introduces a drink.', 'Ich nehme einen Salat und ein Wasser.'],
      ['At the end of a meal', 'Ask Die Rechnung, bitte or Ich möchte bezahlen. To ask if a seat is free: Ist hier noch frei? To ask for an item: Haben Sie ...?', 'Die Rechnung, bitte. Kann ich mit Karte bezahlen?'],
    ],
    vocab: `die Speisekarte|menu|Die Speisekarte liegt auf dem Tisch.;das Gericht|dish|Das Gericht ist lecker.;der Salat|salad|Ich nehme einen Salat.;die Pizza|pizza|Die Pizza ist heiß.;die Rechnung|bill|Die Rechnung, bitte.;das Trinkgeld|tip|Das Trinkgeld ist freiwillig.;der Kellner|waiter|Der Kellner kommt gleich.;die Kellnerin|waitress|Die Kellnerin bringt Wasser.;der Löffel|spoon|Ich brauche einen Löffel.;die Gabel|fork|Die Gabel liegt rechts.;das Messer|knife|Das Messer liegt links.;die Karte|card|Ich bezahle mit Karte.`,
    quizzes: [
      ['Complete: Ich nehme ___ Salat.', 'einen', 'ein', 'eine', 'Salat is masculine accusative.'],
      ['Ask for the bill.', 'Die Rechnung, bitte.', 'Die Speisekarte, bitte.', 'Wo ist die Küche?', 'Rechnung means bill.'],
    ],
    verbs: ['nehmen', 'bringen', 'bezahlen'],
  },
  {
    slug: 'instructions-imperative', title: 'Bitte machen Sie ...', goal: 'Understand requests and give simple instructions.',
    grammar: [
      ['Polite imperative', 'For formal requests, use the infinitive-like verb followed by Sie: Kommen Sie bitte! Gehen Sie nach links! A separable prefix appears at the end: Stehen Sie bitte auf!', 'Bitte warten Sie hier.'],
      ['Informal imperative', 'With one familiar person, use a short verb form without du: Komm! Lies! Nimm! With several familiar people use the ihr form without ihr: Kommt! Wartet!', 'Lies bitte den Text. Kommt bitte um acht!'],
    ],
    vocab: `bitte|please|Warten Sie bitte.;langsam|slowly|Sprechen Sie bitte langsam.;noch einmal|once more|Bitte noch einmal.;wiederholen|to repeat|Wiederholen Sie das bitte.;öffnen|to open|Öffnen Sie das Fenster.;schließen|to close|Schließen Sie die Tür.;warten|to wait|Warten Sie hier.;zeigen|to show|Zeigen Sie mir das Buch.;hören|to listen|Hören Sie gut zu.;lesen|to read|Lesen Sie den Text.;schreiben|to write|Schreiben Sie Ihren Namen.;aufstehen|to stand up|Stehen Sie bitte auf.`,
    quizzes: [
      ['Choose the polite command.', 'Warten Sie bitte hier.', 'Du wartest bitte hier.', 'Wartet Sie bitte hier.', 'Formal imperative uses verb + Sie.'],
      ['Informal command to one person: read!', 'Lies!', 'Lest!', 'Lesen Sie!', 'The du imperative of lesen is Lies!'],
    ],
    verbs: ['warten', 'öffnen', 'schließen'],
  },
  {
    slug: 'comparisons-descriptions', title: 'Beschreiben und Vergleichen', goal: 'Describe people and things using basic comparisons.',
    grammar: [
      ['Adjectives after sein', 'A descriptive adjective after sein has no ending: Der Mann ist groß; das Haus ist klein. Negate it with nicht: Der Bus ist nicht schnell.', 'Die Wohnung ist hell und ruhig.'],
      ['Simple comparison', 'Use -er + als for comparisons: größer als, kleiner als, schneller als. Common irregular forms include gut → besser and viel → mehr. Use so ... wie for equality.', 'Der Zug ist schneller als der Bus.'],
    ],
    vocab: `groß|big or tall|Das Haus ist groß.;klein|small|Die Tasche ist klein.;alt|old|Das Auto ist alt.;jung|young|Das Kind ist jung.;neu|new|Das Buch ist neu.;schön|beautiful|Der Park ist schön.;schnell|fast|Der Zug ist schnell.;langsam|slow|Der Bus ist langsam.;hell|bright|Die Küche ist hell.;dunkel|dark|Das Zimmer ist dunkel.;besser|better|Heute geht es mir besser.;mehr|more|Ich brauche mehr Zeit.`,
    quizzes: [
      ['Complete: Der Zug ist schneller ___ der Bus.', 'als', 'wie', 'denn', 'A comparative uses als.'],
      ['Comparative of gut?', 'besser', 'guter', 'mehr gut', 'Gut has an irregular comparative.'],
    ],
    verbs: ['brauchen', 'sein'],
  },
  {
    slug: 'plans-permission', title: 'Pläne und Regeln', goal: 'Discuss plans, permission, obligations, and preferences.',
    grammar: [
      ['Modal verb dürfen', 'Dürfen means to be allowed to. It can form questions about permission. Put the action infinitive at the end.', 'Darf ich hier sitzen? Hier darf man nicht rauchen.'],
      ['Modal verbs together', 'At A1, master one modal at a time: können (ability), müssen (necessity), wollen (intention), dürfen (permission), sollen (advice), mögen/möchte (liking or polite wish). The main action is an infinitive at the end.', 'Ich möchte gehen. Ich muss arbeiten. Ich kann helfen.'],
      ['Future with present', 'A future time word plus present tense often expresses a future plan; no special tense is needed for simple plans.', 'Morgen fahre ich nach Hamburg.'],
    ],
    vocab: `der Plan|plan|Mein Plan ist einfach.;die Regel|rule|Das ist eine wichtige Regel.;erlaubt|allowed|Ist das hier erlaubt?;verboten|forbidden|Rauchen ist hier verboten.;möglich|possible|Ist das morgen möglich?;frei|free or available|Am Sonntag bin ich frei.;die Zeit|time|Hast du Zeit?;das Wochenende|weekend|Am Wochenende reise ich.;nächste Woche|next week|Nächste Woche habe ich Urlaub.;später|later|Ich komme später.;zusammen|together|Wir lernen zusammen.;allein|alone|Ich wohne allein.`,
    quizzes: [
      ['Ask permission to sit here.', 'Darf ich hier sitzen?', 'Muss ich hier sitzen?', 'Will ich hier sitzen?', 'Dürfen asks about permission.'],
      ['Complete: Morgen ___ ich nach Hamburg.', 'fahre', 'fahren', 'fährst', 'A present-tense verb plus Morgen can express a plan.'],
    ],
    verbs: ['dürfen', 'müssen', 'können', 'wollen', 'sollen'],
  },
  {
    slug: 'reading-writing', title: 'Lesen und Schreiben', goal: 'Understand everyday signs, forms, and short notes.',
    grammar: [
      ['Simple forms', 'A form may ask for Vorname (first name), Nachname (surname), Geburtsdatum (date of birth), Adresse and Unterschrift (signature). Fill in facts, not full sentences, unless asked.', 'Vorname: Mia; Nachname: Weber; Wohnort: Bonn.'],
      ['Short written requests', 'Begin a formal short email with Guten Tag or Sehr geehrte Damen und Herren. Say your purpose in short main clauses. Close with Mit freundlichen Grüßen. An informal note can begin Hallo and end Liebe Grüße.', 'Guten Tag, ich brauche einen Termin. Haben Sie am Montag Zeit? Mit freundlichen Grüßen, Mia Weber.'],
    ],
    vocab: `der Vorname|first name|Mein Vorname ist Mia.;der Nachname|surname|Mein Nachname ist Weber.;das Geburtsdatum|date of birth|Mein Geburtsdatum steht hier.;der Wohnort|place of residence|Mein Wohnort ist Bonn.;die Unterschrift|signature|Hier fehlt die Unterschrift.;das Formular|form|Ich fülle das Formular aus.;der Brief|letter|Der Brief ist kurz.;die Notiz|note|Ich schreibe eine Notiz.;die Öffnungszeiten|opening hours|Die Öffnungszeiten stehen hier.;geschlossen|closed|Das Geschäft ist geschlossen.;geöffnet|open|Die Apotheke ist geöffnet.;ausfüllen|to fill out|Bitte füllen Sie das Formular aus.`,
    quizzes: [
      ['What does Vorname mean?', 'first name', 'surname', 'address', 'Vorname is the given name.'],
      ['Complete: Ich fülle das Formular ___.', 'aus', 'an', 'auf', 'Ausfüllen is separable.'],
    ],
    verbs: ['ausfüllen', 'schreiben', 'lesen'],
  },
  {
    slug: 'a1-review', title: 'A1 Abschlussrunde', goal: 'Review core structures across everyday situations.',
    grammar: [
      ['The A1 sentence toolkit', 'A clear statement places the conjugated verb second. A yes/no question puts it first. With a modal verb, the action infinitive goes last. In the perfect, the participle goes last.', 'Heute kaufe ich ein. Kannst du kommen? Ich habe gestern gelernt.'],
      ['The A1 case toolkit', 'Learn noun gender with every word. Nominative marks the subject; accusative often marks the direct object; dative follows mit and often expresses a recipient or location. Watch masculine changes: der → den → dem.', 'Der Mann kauft den Apfel. Ich gebe dem Mann den Apfel.'],
      ['Next step', 'Use this course as repeated practice. Revisit old cards by swiping down. A1 also needs listening and speaking practice with real voices; these text cards focus on words, structures and short communication.', 'Ich kann einfache Fragen stellen und beantworten.'],
    ],
    vocab: `die Frage|question|Ich habe eine Frage.;die Antwort|answer|Die Antwort ist richtig.;der Satz|sentence|Schreib einen Satz.;das Wort|word|Das Wort ist neu.;das Gespräch|conversation|Das Gespräch ist kurz.;der Fehler|mistake|Ein Fehler ist normal.;richtig|correct|Die Antwort ist richtig.;falsch|wrong|Die Antwort ist falsch.;einfach|simple|Der Satz ist einfach.;wichtig|important|Das Wort ist wichtig.;wieder|again|Bitte sag das wieder.;fertig|finished|Ich bin fertig.`,
    quizzes: [
      ['Complete: Gestern ___ ich viel gelernt.', 'habe', 'bin', 'hat', 'Lernen forms the perfect with haben.'],
      ['Complete: Ich fahre mit ___ Zug.', 'dem', 'den', 'der', 'Mit takes dative.'],
      ['Complete: Ich sehe ___ Mann.', 'den', 'dem', 'der', 'A masculine direct object takes den.'],
      ['Complete: Du ___ Deutsch sprechen.', 'kannst', 'kann', 'können', 'The du form of können is kannst.'],
      ['Complete: Das ist ___ Buch.', 'ein', 'eine', 'einen', 'Buch is neuter in nominative.'],
    ],
    verbs: ['sein', 'haben', 'werden'],
  },
];

// Extra lessons audited against the full 54:24 beginner-video transcript.
plans.splice(plans.length - 1, 0,
  {
    slug: 'sounds-greetings', title: 'Laute und Grüße', goal: 'Recognize key German sounds and greet naturally.',
    grammar: [
      ['The alphabet is familiar, the sounds differ', 'German uses the basic Latin alphabet plus Ä, Ö, Ü and ß. Letter names are not always English letter names. Spell a word aloud and check it with Wie schreibt man das? Nouns always start with a capital letter.', 'A wie Anna, B wie Berlin, Z wie Zug.'],
      ['Umlauts and Eszett', 'Ä sounds similar to the vowel in German Bären. For Ö, round your lips while saying an e-like vowel; for Ü, round them while saying an i-like vowel. ß represents a sharp s sound. Standard spelling uses ß after a long vowel or diphthong, as in Straße; use ss in words such as Kuss.', 'Mädchen · schön · über · Straße'],
      ['Greetings for the situation', 'Guten Morgen is for the morning, Guten Tag for the day and Guten Abend for the evening. Tschüss is informal goodbye; Auf Wiedersehen is more formal. Freut mich means pleased to meet you.', 'Guten Tag, Frau Müller. — Auf Wiedersehen!'],
    ],
    vocab: `das Alphabet|alphabet|Das Alphabet hat viele bekannte Buchstaben.;der Buchstabe|letter|Welcher Buchstabe ist das?;die Aussprache|pronunciation|Die Aussprache ist wichtig.;das Mädchen|girl|Das Mädchen heißt Lea.;die Straße|street|Die Straße ist lang.;der Kuss|kiss|Ein Kuss ist ein Gruß.;Guten Tag|good day|Guten Tag, Herr Weber.;Guten Abend|good evening|Guten Abend, Frau Meier.;Auf Wiedersehen|goodbye formally|Auf Wiedersehen, Herr Weber.;Tschüss|bye informally|Tschüss, bis morgen.;Freut mich|pleased to meet you|Freut mich, dich kennenzulernen.;bitte langsam|slowly please|Sprechen Sie bitte langsam.`,
    quizzes: [
      ['Which is a formal goodbye?', 'Auf Wiedersehen', 'Tschüss', 'Hallo', 'Use Auf Wiedersehen in a formal setting.'],
      ['Which noun has a capital first letter?', 'Mädchen', 'schön', 'über', 'German nouns begin with a capital letter.'],
      ['Which spelling uses ß?', 'Straße', 'Strasse in standard German spelling', 'Straaße', 'Straße has a long vowel before ß.'],
    ], verbs: ['buchstabieren'],
  },
  {
    slug: 'questions-conversation', title: 'Fragen und Vorstellen', goal: 'Ask and answer personal questions in formal and informal speech.',
    grammar: [
      ['W-question words', 'Was = what, wer = who, wo = where, wohin = where to, woher = where from, wann = when, warum = why, wie = how. The pattern is question word + conjugated verb + subject.', 'Wo wohnst du? Woher kommen Sie?'],
      ['Yes/no and negation', 'A yes/no question begins with the conjugated verb: Sprichst du Deutsch? Ja and nein can answer alone. Inside a sentence, use nicht to negate a verb or description; use kein before an indefinite noun.', 'Nein, ich spreche nicht Englisch. Ich habe kein Auto.'],
      ['Introduce yourself', 'Use Wie heißt du? with a familiar person and Wie heißen Sie? politely. Wie geht es dir? is informal; Wie geht es Ihnen? is formal. Answer simply and ask back with Und dir? or Und Ihnen?', 'Ich heiße Lea. Mir geht es gut, danke. Und Ihnen?'],
    ],
    vocab: `wer|who|Wer ist das?;was|what|Was machst du?;wo|where|Wo wohnst du?;wohin|where to|Wohin gehst du?;woher|where from|Woher kommen Sie?;wann|when|Wann beginnt der Kurs?;warum|why|Warum lernst du Deutsch?;wie|how|Wie heißen Sie?;ja|yes|Ja, ich komme.;nein|no|Nein, ich komme nicht.;nicht|not|Ich bin nicht müde.;die Geschwister|siblings|Hast du Geschwister?`,
    quizzes: [
      ['Ask where someone comes from.', 'Woher kommst du?', 'Wohin kommst du?', 'Wann kommst du?', 'Woher means where from.'],
      ['Ask where someone is going.', 'Wohin gehst du?', 'Woher gehst du?', 'Wo gehst duher?', 'Wohin asks for a destination.'],
      ['Choose a yes/no question.', 'Sprichst du Deutsch?', 'Wo sprichst du Deutsch?', 'Du sprichst Deutsch.', 'A yes/no question starts with the conjugated verb.'],
      ['Formal: How are you?', 'Wie geht es Ihnen?', 'Wie geht es dir?', 'Wie heißen Sie?', 'Use Ihnen with formal Sie.'],
    ], verbs: ['sprechen', 'wohnen', 'kommen'],
  },
  {
    slug: 'case-tables', title: 'Nominativ, Akkusativ, Dativ', goal: 'Use articles and pronouns for subject, object, and recipient.',
    grammar: [
      ['Definite articles by case', 'For masculine nouns: nominative der, accusative den, dative dem. Feminine: die, die, der. Neuter: das, das, dem. Plural: die, die, den; plural nouns often add -n in dative if possible.', 'Der Mann gibt dem Kind den Ball.'],
      ['Indefinite and negative articles', 'Ein/kein follow similar endings: masculine ein/einen/einem; feminine eine/eine/einer; neuter ein/ein/einem. In the plural there is no ein, but keine/keine/keinen. Learn the case from the sentence role or preposition.', 'Ich habe einen Ball. Ich habe keinen Ball.'],
      ['Pronoun case table', 'Subject: ich, du, er, sie, es, wir, ihr, sie, Sie. Accusative: mich, dich, ihn, sie, es, uns, euch, sie, Sie. Dative: mir, dir, ihm, ihr, ihm, uns, euch, ihnen, Ihnen.', 'Sie sieht mich. Ich helfe ihr.'],
    ],
    vocab: `der Mann|man|Der Mann kocht.;die Frau|woman|Die Frau liest.;das Kind|child|Das Kind spielt.;der Ball|ball|Ich sehe den Ball.;der Reis|rice|Der Reis ist fertig.;das Geschenk|gift|Ich gebe dir ein Geschenk.;der Freund|male friend|Mein Freund kommt heute.;die Freundin|female friend|Meine Freundin wohnt hier.;das Buch|book|Ich gebe dem Kind das Buch.;die Kinder|children|Die Kinder spielen.;der Tisch|table|Auf dem Tisch liegt ein Buch.;das Auto|car|Ich habe kein Auto.`,
    quizzes: [
      ['Complete: ___ Mann kocht.', 'Der', 'Den', 'Dem', 'The subject is nominative.'],
      ['Complete: Ich sehe ___ Mann.', 'den', 'der', 'dem', 'A masculine direct object is accusative.'],
      ['Complete: Ich gebe ___ Kind den Ball.', 'dem', 'das', 'den', 'The recipient is dative; Kind is neuter.'],
      ['Complete: Ich spreche mit ___ Kindern.', 'den', 'die', 'dem', 'Mit takes dative; plural article is den and Kind gains -ern.'],
      ['Complete: Ich habe ___ Auto.', 'kein', 'keine', 'keinen', 'Auto is neuter accusative.'],
    ], verbs: ['geben', 'sehen'],
  },
  {
    slug: 'prepositions', title: 'Präpositionen und Fälle', goal: 'Choose the case required by common prepositions.',
    grammar: [
      ['Always accusative', 'Für (for), durch (through), ohne (without), gegen (against/around) and um (around/at a time) take accusative. With masculine nouns, use den/einen; with pronouns, use forms such as dich and mich.', 'Das Geschenk ist für dich. Wir gehen durch den Park.'],
      ['Always dative', 'Mit (with), zu (to), nach (after/to a city or country), von (from/of), bei (at/with), aus (out of/from) take dative. Common contractions: zu dem → zum, zu der → zur, von dem → vom.', 'Ich fahre mit dem Bus zum Arzt. Sie kommt von der Arbeit.'],
      ['Two-way prepositions', 'In, auf, an, unter, über, vor, hinter, neben and zwischen take dative for a location (Wo?) and accusative for a destination (Wohin?). Movement alone is not the test: the question is location versus destination.', 'Ich bin im Restaurant. Ich gehe ins Restaurant.'],
    ],
    vocab: `für|for|Das Geschenk ist für dich.;durch|through|Wir gehen durch den Park.;ohne|without|Ich komme ohne Auto.;gegen|against or around|Wir kommen gegen acht Uhr.;um|at or around|Der Film beginnt um sieben.;mit|with|Ich fahre mit dem Bus.;zu|to|Ich gehe zum Arzt.;nach|after or to|Nach dem Essen gehe ich nach Hause.;von|from or of|Sie kommt von der Arbeit.;bei|at or with|Ich wohne bei meinen Eltern.;aus|from or out of|Das Buch kommt aus der Tasche.;in|in or into|Ich bin im Park.`,
    quizzes: [
      ['Complete: Das Geschenk ist für ___. (you, informal)', 'dich', 'dir', 'du', 'Für takes accusative.'],
      ['Complete: Wir gehen durch ___ Park.', 'den', 'dem', 'der', 'Durch takes accusative.'],
      ['Complete: Ich fahre mit ___ Bus.', 'dem', 'den', 'der', 'Mit takes dative.'],
      ['Complete: Sie kommt von ___ Arbeit.', 'der', 'die', 'den', 'Von takes dative; Arbeit is feminine.'],
      ['Complete: Wir gehen ___ Restaurant.', 'ins', 'im', 'am', 'A destination into a neuter place: in das → ins.'],
    ], verbs: ['gehen', 'fahren'],
  },
  {
    slug: 'past-participles', title: 'Perfekt: Partizipien', goal: 'Build common regular, irregular, and prefixed past participles.',
    grammar: [
      ['Regular participles', 'Many regular verbs form a participle with ge- + stem + -t: spielen → gespielt; machen → gemacht. Verbs with a stem ending in -t/-d often add -et: arbeiten → gearbeitet.', 'Wir haben gestern gearbeitet.'],
      ['Strong and mixed participles', 'Common strong verbs may change the vowel and end in -en: gehen → gegangen, trinken → getrunken, finden → gefunden. Learn these with the infinitive and the auxiliary haben or sein.', 'Er hat Wasser getrunken. Sie ist nach Hause gegangen.'],
      ['Prefixes and -ieren', 'A separable prefix places ge between prefix and stem: anrufen → angerufen, aufstehen → aufgestanden, einkaufen → eingekauft. Inseparable be-, ver-, er-, zer- and verbs ending in -ieren do not take ge-: besucht, verstanden, erzählt, studiert, telefoniert.', 'Ich habe dich angerufen. Wir haben telefoniert.'],
    ],
    vocab: `gespielt|played|Wir haben gespielt.;gearbeitet|worked|Ich habe gestern gearbeitet.;gegangen|gone|Sie ist nach Hause gegangen.;getrunken|drunk|Er hat Tee getrunken.;gefunden|found|Ich habe den Schlüssel gefunden.;angerufen|called|Ich habe meine Mutter angerufen.;aufgestanden|got up|Er ist früh aufgestanden.;eingekauft|shopped|Wir haben gestern eingekauft.;besucht|visited|Sie hat ihre Freundin besucht.;verstanden|understood|Ich habe die Frage verstanden.;studiert|studied|Er hat in Bonn studiert.;telefoniert|made a phone call|Wir haben telefoniert.`,
    quizzes: [
      ['Past participle of spielen?', 'gespielt', 'gespielen', 'spielt', 'A regular participle often ends in -t.'],
      ['Past participle of anrufen?', 'angerufen', 'geanrufen', 'anruft', 'Ge goes between the separable prefix and root.'],
      ['Past participle of besuchen?', 'besucht', 'gebesucht', 'besuchen', 'The inseparable prefix be- blocks ge-.'],
      ['Past participle of studieren?', 'studiert', 'gestudiert', 'studieren', 'Verbs ending in -ieren do not add ge-.'],
      ['Complete: Sie ___ früh aufgestanden.', 'ist', 'hat', 'haben', 'Aufstehen describes a change of state and uses sein.'],
    ], verbs: ['anrufen', 'besuchen', 'telefonieren'],
  },
  {
    slug: 'possessives-negation', title: 'Mein, dein und kein', goal: 'Use ownership and negation across common cases.',
    grammar: [
      ['Possessive families', 'Mein (my), dein (your informal), sein (his), ihr (her/their), unser (our), euer (your plural) and Ihr (your formal) behave like ein. Feminine/plural nominative add -e: meine Schwester, unsere Freunde.', 'Das ist mein Vater. Das sind unsere Freunde.'],
      ['Possessives in accusative and dative', 'Only masculine changes between nominative and accusative: mein Vater → meinen Vater. Dative endings: masculine/neuter -em, feminine -er, plural -en. Use these with mit, von, zu and recipients.', 'Ich sehe meinen Vater. Ich spreche mit meiner Schwester.'],
      ['Kein versus nicht', 'Kein negates a noun with an indefinite or zero article: kein Auto, keine Zeit, keinen Kaffee, keinen Kindern (dative plural). Nicht negates an action, adjective or definite phrase: Das ist nicht teuer. Nein answers a yes/no question.', 'Nein, ich habe keinen Kaffee. Der Tee ist nicht kalt.'],
    ],
    vocab: `mein|my|Mein Bruder kommt.;dein|your informal|Dein Buch liegt hier.;sein|his|Sein Vater ist Arzt.;ihr|her or their|Ihre Mutter ist nett.;unser|our|Unser Haus ist klein.;euer|your plural|Euer Auto ist neu.;Ihr|your formal|Ist das Ihr Buch?;kein|no or not a|Ich habe kein Auto.;nicht|not|Das ist nicht teuer.;nein|no|Nein, ich komme nicht.;die Zeit|time|Ich habe keine Zeit.;der Bruder|brother|Ich helfe meinem Bruder.`,
    quizzes: [
      ['Complete: Ich sehe ___ Vater.', 'meinen', 'mein', 'meinem', 'Masculine direct object takes -en.'],
      ['Complete: Ich spreche mit ___ Schwester.', 'meiner', 'meine', 'meinen', 'Mit takes dative; feminine possessive ends in -er.'],
      ['Complete: Ich habe ___ Zeit.', 'keine', 'nicht', 'keinen', 'Negate a feminine noun with keine.'],
      ['Complete: Der Tee ist ___ kalt.', 'nicht', 'kein', 'keine', 'Negate an adjective with nicht.'],
    ], verbs: ['haben', 'sprechen'],
  },
  {
    slug: 'sentence-links', title: 'Sätze verbinden', goal: 'Order information and connect simple statements.',
    grammar: [
      ['Time, manner, place', 'A useful default order for extra information is when, how, where: Ich fahre heute mit dem Bus nach Hause. The conjugated verb still stays second in a main clause. Natural order can shift for emphasis.', 'Morgen fahre ich mit dem Zug nach Berlin.'],
      ['Und, aber, oder, denn', 'Und joins similar ideas, aber contrasts, oder gives a choice, and denn provides a reason. Each joins main clauses without sending the verb to the end.', 'Ich lerne Deutsch, denn ich wohne in Berlin.'],
      ['Weil', 'Weil also means because, but introduces a subordinate clause with the conjugated verb at the end. This differs from denn. A simple A1 sentence can use denn first, then practice weil.', 'Ich bleibe zu Hause, weil ich krank bin.'],
    ],
    vocab: `und|and|Ich lerne und arbeite.;aber|but|Ich komme, aber ich bleibe nicht.;oder|or|Tee oder Kaffee?;denn|because|Ich bleibe, denn ich bin müde.;weil|because|Ich bleibe, weil ich müde bin.;heute|today|Heute fahre ich nach Bonn.;morgen|tomorrow|Morgen habe ich Zeit.;mit dem Bus|by bus|Ich fahre mit dem Bus.;nach Hause|homeward|Ich gehe nach Hause.;zu Hause|at home|Ich bin zu Hause.;zuerst|first|Zuerst frühstücke ich.;dann|then|Dann gehe ich zur Arbeit.`,
    quizzes: [
      ['Complete: Ich bleibe zu Hause, denn ich ___ krank.', 'bin', 'krank bin', 'bist', 'Denn keeps main-clause verb order.'],
      ['Complete: Ich bleibe zu Hause, weil ich krank ___.', 'bin', 'ist', 'bin ich', 'The conjugated verb ends the weil clause.'],
      ['Choose a natural time–manner–place order.', 'Ich fahre heute mit dem Bus nach Hause.', 'Ich fahre nach Hause mit dem Bus heute.', 'Heute nach Hause mit dem Bus ich fahre.', 'A useful default is time, manner, place.'],
    ], verbs: ['bleiben', 'fahren'],
  },
  {
    slug: 'dates-months-numbers', title: 'Zahlen, Monate, Daten', goal: 'Read numbers, clock time, weekdays, months, and dates.',
    grammar: [
      ['Numbers beyond twenty', '21–99 put the unit before und and the ten: einundzwanzig, zweiunddreißig. Learn tens such as zwanzig, dreißig, vierzig, fünfzig, sechzig, siebzig, achtzig and neunzig.', 'Die Fahrkarte kostet einundzwanzig Euro.'],
      ['Official and conversational time', 'Official time reads hour + Uhr + minute: vierzehn Uhr dreißig. Everyday time can use Viertel nach zwei (2:15), halb drei (2:30) and Viertel vor drei (2:45). An event is um a clock time.', 'Der Zug fährt um halb drei ab.'],
      ['Weekdays, months, dates', 'Use am with weekdays and calendar dates: am Montag, am dritten Juli. Use im with months and seasons: im Januar, im Sommer. Date ordinals generally use -ten for 1–19 and -sten from 20 onward, with special forms such as ersten and dritten.', 'Der Termin ist am einundzwanzigsten Oktober.'],
    ],
    vocab: `elf|eleven|Es sind elf Personen.;zwölf|twelve|Es ist zwölf Uhr.;dreizehn|thirteen|Sie ist dreizehn.;einundzwanzig|twenty-one|Ich bin einundzwanzig.;dreißig|thirty|Der Kurs dauert dreißig Minuten.;vierzig|forty|Das kostet vierzig Euro.;der Januar|January|Im Januar ist es kalt.;der Februar|February|Im Februar habe ich Geburtstag.;der März|March|Im März beginnt der Frühling.;der April|April|Im April regnet es.;der Mai|May|Im Mai ist es warm.;der Juni|June|Im Juni fahre ich weg.;der Juli|July|Im Juli habe ich Urlaub.;der August|August|Im August ist es heiß.;der September|September|Im September beginnt der Kurs.;der Oktober|October|Im Oktober ist es kühl.;der November|November|Im November regnet es oft.;der Dezember|December|Im Dezember ist Winter.`,
    quizzes: [
      ['What is 2:30 in everyday German?', 'halb drei', 'halb zwei', 'drei Uhr halb', 'Halb names the coming hour.'],
      ['What is 14:30 in official time?', 'vierzehn Uhr dreißig', 'halb vierzehn', 'vierzehn Uhr halb', 'Official time reads the hour and minute.'],
      ['Complete: Der Termin ist ___ dritten Juli.', 'am', 'im', 'um', 'Use am with dates.'],
      ['Complete: ___ Januar ist es kalt.', 'Im', 'Am', 'Um', 'Use im with months.'],
      ['How do you say 21?', 'einundzwanzig', 'zwanzigeins', 'einszwanzig', 'The unit precedes und and the ten.'],
    ], verbs: ['beginnen', 'abfahren'],
  },
);

// Place video-audit lessons beside the related foundations, not at the end.
function moveBefore(slug, target) {
  const index = plans.findIndex(x => x.slug === slug);
  const [plan] = plans.splice(index, 1);
  plans.splice(plans.findIndex(x => x.slug === target), 0, plan);
}
moveBefore('sounds-greetings', 'alphabet-numbers');
moveBefore('questions-conversation', 'people-family');
moveBefore('case-tables', 'daily-routine');
moveBefore('possessives-negation', 'daily-routine');
moveBefore('sentence-links', 'daily-routine');
moveBefore('dates-months-numbers', 'food-drink');
moveBefore('prepositions', 'transport-travel');
moveBefore('past-participles', 'appointments-contact');

const forms = {
  buchstabieren: ['buchstabiere', 'buchstabierst', 'buchstabiert', 'buchstabieren', 'buchstabiert', 'buchstabieren'],
  sehen: ['sehe', 'siehst', 'sieht', 'sehen', 'seht', 'sehen'],
  anrufen: ['rufe an', 'rufst an', 'ruft an', 'rufen an', 'ruft an', 'rufen an'],
  besuchen: ['besuche', 'besuchst', 'besucht', 'besuchen', 'besucht', 'besuchen'],
  telefonieren: ['telefoniere', 'telefonierst', 'telefoniert', 'telefonieren', 'telefoniert', 'telefonieren'],
  sein: ['bin', 'bist', 'ist', 'sind', 'seid', 'sind'],
  haben: ['habe', 'hast', 'hat', 'haben', 'habt', 'haben'],
  heißen: ['heiße', 'heißt', 'heißt', 'heißen', 'heißt', 'heißen'],
  liegen: ['liege', 'liegst', 'liegt', 'liegen', 'liegt', 'liegen'],
  lernen: ['lerne', 'lernst', 'lernt', 'lernen', 'lernt', 'lernen'],
  machen: ['mache', 'machst', 'macht', 'machen', 'macht', 'machen'],
  spielen: ['spiele', 'spielst', 'spielt', 'spielen', 'spielt', 'spielen'],
  arbeiten: ['arbeite', 'arbeitest', 'arbeitet', 'arbeiten', 'arbeitet', 'arbeiten'],
  hören: ['höre', 'hörst', 'hört', 'hören', 'hört', 'hören'],
  schreiben: ['schreibe', 'schreibst', 'schreibt', 'schreiben', 'schreibt', 'schreiben'],
  lesen: ['lese', 'liest', 'liest', 'lesen', 'lest', 'lesen'],
  aufstehen: ['stehe auf', 'stehst auf', 'steht auf', 'stehen auf', 'steht auf', 'stehen auf'],
  anfangen: ['fange an', 'fängst an', 'fängt an', 'fangen an', 'fangt an', 'fangen an'],
  einkaufen: ['kaufe ein', 'kaufst ein', 'kauft ein', 'kaufen ein', 'kauft ein', 'kaufen ein'],
  fernsehen: ['sehe fern', 'siehst fern', 'sieht fern', 'sehen fern', 'seht fern', 'sehen fern'],
  schlafen: ['schlafe', 'schläfst', 'schläft', 'schlafen', 'schlaft', 'schlafen'],
  beginnen: ['beginne', 'beginnst', 'beginnt', 'beginnen', 'beginnt', 'beginnen'],
  kommen: ['komme', 'kommst', 'kommt', 'kommen', 'kommt', 'kommen'],
  essen: ['esse', 'isst', 'isst', 'essen', 'esst', 'essen'],
  trinken: ['trinke', 'trinkst', 'trinkt', 'trinken', 'trinkt', 'trinken'],
  mögen: ['mag', 'magst', 'mag', 'mögen', 'mögt', 'mögen'],
  kochen: ['koche', 'kochst', 'kocht', 'kochen', 'kocht', 'kochen'],
  kaufen: ['kaufe', 'kaufst', 'kauft', 'kaufen', 'kauft', 'kaufen'],
  kosten: ['koste', 'kostest', 'kostet', 'kosten', 'kostet', 'kosten'],
  bezahlen: ['bezahle', 'bezahlst', 'bezahlt', 'bezahlen', 'bezahlt', 'bezahlen'],
  wohnen: ['wohne', 'wohnst', 'wohnt', 'wohnen', 'wohnt', 'wohnen'],
  sitzen: ['sitze', 'sitzt', 'sitzt', 'sitzen', 'sitzt', 'sitzen'],
  stehen: ['stehe', 'stehst', 'steht', 'stehen', 'steht', 'stehen'],
  gehen: ['gehe', 'gehst', 'geht', 'gehen', 'geht', 'gehen'],
  finden: ['finde', 'findest', 'findet', 'finden', 'findet', 'finden'],
  suchen: ['suche', 'suchst', 'sucht', 'suchen', 'sucht', 'suchen'],
  fahren: ['fahre', 'fährst', 'fährt', 'fahren', 'fahrt', 'fahren'],
  laufen: ['laufe', 'läufst', 'läuft', 'laufen', 'lauft', 'laufen'],
  abfahren: ['fahre ab', 'fährst ab', 'fährt ab', 'fahren ab', 'fahrt ab', 'fahren ab'],
  ankommen: ['komme an', 'kommst an', 'kommt an', 'kommen an', 'kommt an', 'kommen an'],
  können: ['kann', 'kannst', 'kann', 'können', 'könnt', 'können'],
  sprechen: ['spreche', 'sprichst', 'spricht', 'sprechen', 'sprecht', 'sprechen'],
  erklären: ['erkläre', 'erklärst', 'erklärt', 'erklären', 'erklärt', 'erklären'],
  wollen: ['will', 'willst', 'will', 'wollen', 'wollt', 'wollen'],
  möchten: ['möchte', 'möchtest', 'möchte', 'möchten', 'möchtet', 'möchten'],
  treffen: ['treffe', 'triffst', 'trifft', 'treffen', 'trefft', 'treffen'],
  schwimmen: ['schwimme', 'schwimmst', 'schwimmt', 'schwimmen', 'schwimmt', 'schwimmen'],
  nehmen: ['nehme', 'nimmst', 'nimmt', 'nehmen', 'nehmt', 'nehmen'],
  brauchen: ['brauche', 'brauchst', 'braucht', 'brauchen', 'braucht', 'brauchen'],
  tragen: ['trage', 'trägst', 'trägt', 'tragen', 'tragt', 'tragen'],
  müssen: ['muss', 'musst', 'muss', 'müssen', 'müsst', 'müssen'],
  sollen: ['soll', 'sollst', 'soll', 'sollen', 'sollt', 'sollen'],
  wehtun: ['tue weh', 'tust weh', 'tut weh', 'tun weh', 'tut weh', 'tun weh'],
  helfen: ['helfe', 'hilfst', 'hilft', 'helfen', 'helft', 'helfen'],
  regnen: ['regne', 'regnest', 'regnet', 'regnen', 'regnet', 'regnen'],
  schneien: ['schneie', 'schneist', 'schneit', 'schneien', 'schneit', 'schneien'],
  bleiben: ['bleibe', 'bleibst', 'bleibt', 'bleiben', 'bleibt', 'bleiben'],
  geben: ['gebe', 'gibst', 'gibt', 'geben', 'gebt', 'geben'],
  gefallen: ['gefalle', 'gefällst', 'gefällt', 'gefallen', 'gefallt', 'gefallen'],
  kennen: ['kenne', 'kennst', 'kennt', 'kennen', 'kennt', 'kennen'],
  absagen: ['sage ab', 'sagst ab', 'sagt ab', 'sagen ab', 'sagt ab', 'sagen ab'],
  verschieben: ['verschiebe', 'verschiebst', 'verschiebt', 'verschieben', 'verschiebt', 'verschieben'],
  bestätigen: ['bestätige', 'bestätigst', 'bestätigt', 'bestätigen', 'bestätigt', 'bestätigen'],
  bringen: ['bringe', 'bringst', 'bringt', 'bringen', 'bringt', 'bringen'],
  warten: ['warte', 'wartest', 'wartet', 'warten', 'wartet', 'warten'],
  öffnen: ['öffne', 'öffnest', 'öffnet', 'öffnen', 'öffnet', 'öffnen'],
  schließen: ['schließe', 'schließt', 'schließt', 'schließen', 'schließt', 'schließen'],
  dürfen: ['darf', 'darfst', 'darf', 'dürfen', 'dürft', 'dürfen'],
  ausfüllen: ['fülle aus', 'füllst aus', 'füllt aus', 'füllen aus', 'füllt aus', 'füllen aus'],
  werden: ['werde', 'wirst', 'wird', 'werden', 'werdet', 'werden'],
};

const pronouns = ['ich', 'du', 'er/sie/es', 'wir', 'ihr', 'sie/Sie'];
const vocabulary = [];
for (const [offset, plan] of plans.entries()) {
  const number = offset + 3;
  const prefix = plan.slug;
  const activities = [];
  plan.grammar.forEach(([title, body, example], i) => activities.push({
    slug: `${prefix}-grammar-${i + 1}`, kind: 'grammar', title, body, example,
  }));
  const items = plan.vocab.split(';').map(row => {
    const [de, en, example] = row.split('|');
    if (!de || !en || !example) throw new Error(`Bad vocabulary: ${prefix}: ${row}`);
    vocabulary.push({de, en, lesson: number});
    return {de, en, example};
  });
  for (let i = 0; i < items.length; i += 6) {
    activities.push({slug: `${prefix}-vocab-${i / 6 + 1}`, kind: 'vocabulary',
      title: `Words ${i + 1}–${Math.min(i + 6, items.length)}`, items: items.slice(i, i + 6)});
  }
  let quizNo = 0;
  function quiz(title, question, answer, wrong, explanation) {
    const options = [answer, ...wrong.filter(x => x !== answer)].slice(0, 4);
    if (new Set(options).size < 3) throw new Error(`Repeated options: ${prefix}: ${question}`);
    const shift = quizNo % options.length;
    const rotated = options.slice(shift).concat(options.slice(0, shift));
    activities.push({slug: `${prefix}-quiz-${++quizNo}`, kind: 'quiz', title,
      question, options: rotated, answer: rotated.indexOf(answer), explanation});
  }
  for (const [question, answer, wrong1, wrong2, explanation] of plan.quizzes) {
    quiz('Use it in a sentence', question, answer, [wrong1, wrong2], explanation);
  }
  const nouns = items.filter(item => /^(der|die|das) /.test(item.de));
  nouns.forEach((item, i) => {
    const article = item.de.split(' ')[0];
    const word = item.de.slice(4);
    quiz('Choose the article', `Which article belongs to ${word}?`, article,
      ['der', 'die', 'das'].filter(x => x !== article), `Learn the noun as ${item.de}.`);
  });
  items.forEach((item, i) => {
    const distractors = [...new Set(items.filter(other => other.en !== item.en && other.de !== item.de)
      .slice((i + 1) % 4).map(other => other.en))];
    if (distractors.length >= 2) quiz('Recall the meaning', `What does “${item.de}” mean?`, item.en,
      distractors.slice(0, 2), item.example);
  });
  for (const verb of plan.verbs) {
    const row = forms[verb];
    if (!row) throw new Error(`Missing verb: ${verb}`);
    for (let i = 0; i < pronouns.length; i++) {
      const answer = row[i];
      const wrong = [...new Set(row.filter(x => x !== answer))].slice(0, 3);
      if (wrong.length < 2) continue;
      quiz('Verb form practice', `Present tense: ${pronouns[i]} ___ (${verb})`, answer, wrong,
        `${verb}: ${pronouns.map((p, n) => `${p} ${row[n]}`).join(' · ')}`);
    }
  }
  lessons.push({slug: prefix, number, title: plan.title, goal: plan.goal, activities});
}

const groups = [
  {slug: 'a1-start-and-introductions', title: 'Start, Sounds and Introductions',
    goal: 'Learn greetings, sounds, letters, numbers, personal details, and how to introduce people.',
    members: ['greetings', 'origin', 'sounds-greetings', 'alphabet-numbers',
      'questions-conversation', 'people-family']},
  {slug: 'a1-people-nouns-and-articles', title: 'People, Nouns and Articles',
    goal: 'Learn noun gender and articles, then use core cases, pronouns, possessives, and negation.',
    members: ['articles-gender', 'case-tables', 'possessives-negation', 'pronouns-cases']},
  {slug: 'a1-verbs-sentences-and-routines', title: 'Verbs, Sentences and Daily Routines',
    goal: 'Conjugate common present-tense verbs, build statements and questions, and describe a daily routine.',
    members: ['present-tense', 'sentence-links', 'daily-routine']},
  {slug: 'a1-time-dates-and-appointments', title: 'Time, Dates and Appointments',
    goal: 'Tell the time, use days and dates, and arrange or change appointments.',
    members: ['time-calendar', 'dates-months-numbers', 'appointments-contact']},
  {slug: 'a1-food-shopping-and-home', title: 'Food, Shopping and Home',
    goal: 'Talk about meals, shop and ask prices, describe a home, and order in a restaurant.',
    members: ['food-drink', 'shopping-prices', 'home-rooms', 'restaurant-service']},
  {slug: 'a1-city-directions-and-travel', title: 'City, Directions and Travel',
    goal: 'Ask for places and directions, use common prepositions, and manage everyday travel.',
    members: ['city-directions', 'prepositions', 'transport-travel']},
  {slug: 'a1-work-study-and-free-time', title: 'Work, Study, Free Time and Plans',
    goal: 'Talk about jobs, learning, hobbies, invitations, plans, permission, and obligations.',
    members: ['work-study', 'hobbies-free-time', 'plans-permission']},
  {slug: 'a1-clothes-health-weather-and-description', title: 'Clothes, Health, Weather and Description',
    goal: 'Describe clothing, health, weather, seasons, and compare people and things.',
    members: ['clothes-colours', 'body-health', 'weather-seasons', 'comparisons-descriptions']},
  {slug: 'a1-past-and-written-communication', title: 'Past Events and Written Communication',
    goal: 'Talk about completed events with the Perfekt and understand everyday forms and short messages.',
    members: ['perfect-past', 'past-participles', 'reading-writing']},
  {slug: 'a1-requests-instructions-and-review', title: 'Requests, Instructions and A1 Review',
    goal: 'Make polite requests, understand simple instructions, and review the full A1 course.',
    members: ['instructions-imperative', 'a1-review']},
];

const sourceLessons = new Map(lessons.map(lesson => [lesson.slug, lesson]));
const assigned = groups.flatMap(group => group.members);
if (assigned.length !== lessons.length || new Set(assigned).size !== lessons.length ||
    lessons.some(lesson => !assigned.includes(lesson.slug))) {
  throw new Error('Every source lesson must appear exactly once in the 10-topic map.');
}
const groupedLessons = groups.map((group, index) => ({
  slug: group.slug,
  number: index + 1,
  title: group.title,
  goal: group.goal,
  activities: ['grammar', 'vocabulary', 'quiz'].flatMap(kind =>
    group.members.flatMap(slug => sourceLessons.get(slug).activities
      .filter(activity => activity.kind === kind))),
}));
const groupForSource = new Map(groups.flatMap(group =>
  group.members.map(sourceSlug => [sourceSlug, group.slug])));
const coveragePath = path.join(__dirname, 'video_coverage_0emzztSmKjA.json');
const coverage = JSON.parse(fs.readFileSync(coveragePath, 'utf8'));
coverage.minutes = coverage.minutes.map(minute => ({
  ...minute,
  lessons: [...new Set(minute.lessons.map(slug => {
    const groupedSlug = groupForSource.get(slug) ??
      (groups.some(group => group.slug === slug) ? slug : null);
    if (!groupedSlug) throw new Error(`No 10-topic lesson for video map entry: ${slug}`);
    return groupedSlug;
  }))],
}));
fs.writeFileSync(coveragePath, `${JSON.stringify(coverage, null, 2)}\n`, 'utf8');

const data = {book: {slug: base.book.slug, title: 'German A1 — Ich schaffe das',
  edition: 'Original expanded A1 course, 10-topic version', level: 'A1'},
  lessons: groupedLessons};
fs.writeFileSync(out, `${JSON.stringify(data, null, 2)}\n`, 'utf8');
const counts = data.lessons.map(x => x.activities.length);
console.log(`${data.lessons.length} lessons, ${counts.reduce((a, b) => a + b, 0)} activities, ${vocabulary.length} vocabulary entries`);
