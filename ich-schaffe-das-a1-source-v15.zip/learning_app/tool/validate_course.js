const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const course = JSON.parse(fs.readFileSync(path.join(root, 'assets', 'starter_content.json'), 'utf8'));
const audit = JSON.parse(fs.readFileSync(path.join(__dirname, 'video_coverage_0emzztSmKjA.json'), 'utf8'));
function check(condition, message) { if (!condition) throw new Error(message); }
const slugs = new Set();
const lessonSlugs = new Set();
let count = 0;
check(course.lessons.length === 10, 'A1 must be organized into 10 topic lessons');
for (const [i, lesson] of course.lessons.entries()) {
  check(lesson.number === i + 1, `Lesson order at ${lesson.slug}`);
  check(!lessonSlugs.has(lesson.slug), `Duplicate lesson ${lesson.slug}`);
  lessonSlugs.add(lesson.slug);
  const phases = lesson.activities.map(a => a.kind);
  check(['grammar', 'vocabulary', 'quiz'].every(k => phases.includes(k)), `Missing phase: ${lesson.slug}`);
  check(phases.join(',') === [...phases].sort((a, b) =>
    ['grammar', 'vocabulary', 'quiz'].indexOf(a) - ['grammar', 'vocabulary', 'quiz'].indexOf(b)).join(','),
    `Phase order: ${lesson.slug}`);
  for (const a of lesson.activities) {
    check(!slugs.has(a.slug), `Duplicate activity ${a.slug}`);
    slugs.add(a.slug);
    if (a.kind === 'quiz') {
      check(a.options.length >= 3 && new Set(a.options).size === a.options.length, `Quiz options ${a.slug}`);
      check(Number.isInteger(a.answer) && a.answer >= 0 && a.answer < a.options.length, `Quiz answer ${a.slug}`);
      check(a.question && a.explanation, `Quiz prompt ${a.slug}`);
    }
    if (a.kind === 'vocabulary') check(a.items.every(x => x.de && x.en && x.example), `Vocabulary ${a.slug}`);
    if (a.kind === 'grammar') check(a.body && a.example, `Grammar ${a.slug}`);
    count++;
  }
}
check(audit.minutes.length === 55, 'Video minute count');
audit.minutes.forEach((m, i) => {
  check(m.minute === i && m.concept, `Video minute ${i}`);
  check(m.lessons.length > 0 && m.lessons.every(slug => lessonSlugs.has(slug)), `Video mapping ${i}`);
});
console.log(`Validated ${course.lessons.length} lessons, ${count} activities, and all 55 video minute mappings.`);
const plus = JSON.parse(fs.readFileSync(path.join(root, 'assets', 'a1_plus_content.json'), 'utf8'));
check(plus.book.slug !== course.book.slug, 'A1+ course slug must differ');
check(plus.book.level === 'A1', 'A1+ CEFR level');
check(plus.lessons.length === 14, 'A1+ revision must contain 14 continuation chapters');
const plusSlugs = plus.lessons.flatMap(lesson => lesson.activities.map(a => a.slug));
check(plusSlugs.length > 0 && new Set(plusSlugs).size === plusSlugs.length,
  'A1+ activity IDs must be unique');
check(plusSlugs.every(slug => !slugs.has(slug)), 'A1+ activity IDs must not overlap A1');
const plusAudit = JSON.parse(fs.readFileSync(path.join(__dirname, 'a1_plus_video_coverage.json'), 'utf8'));
check(plusAudit.status === 'chapter_mapped' && plusAudit.chapter_count === 14,
  'A1+ transcript chapter audit is missing');
check(plusAudit.timestamp_count === plusAudit.timestamp_segments.length &&
  plusAudit.timestamp_count >= 800, 'A1+ transcript timestamps are not fully mapped');
let previousTime = -1;
for (const segment of plusAudit.timestamp_segments) {
  const [h, m, s] = segment.time.split(':').map(Number);
  const time = h * 3600 + m * 60 + s;
  check(time > previousTime, `Transcript timestamp order at ${segment.time}`);
  previousTime = time;
  check(plus.lessons.some(lesson => lesson.slug === segment.lesson_slug),
    `Transcript timestamp ${segment.time} has no A1+ lesson`);
}
for (const [i, chapter] of plusAudit.chapters.entries()) {
  const lesson = plus.lessons.find(item => item.slug === chapter.lesson_slug);
  check(chapter.number === i + 1 && lesson, `A1+ transcript chapter ${i + 1} missing`);
  check(chapter.timestamp_count > 0, `A1+ chapter ${i + 1} has no transcript markers`);
  check(lesson.activities.some(a => a.kind === 'grammar') &&
    lesson.activities.some(a => a.kind === 'vocabulary') &&
    lesson.activities.some(a => a.kind === 'quiz'), `A1+ chapter ${i + 1} is incomplete`);
}
const catalog = JSON.parse(fs.readFileSync(path.join(root, 'assets', 'shorts_catalog.json'), 'utf8'));
check(catalog.length >= 3, 'Need three opening Shorts');
check(catalog.every(video => /^[\w-]{11}$/.test(video.id) &&
  video.title && video.channel && video.tags.length), 'Invalid Shorts catalog');
console.log(`Validated separate A1+ revision with 14 continuation chapters across ${plusAudit.timestamp_count} transcript timestamps, and ${catalog.length} catalog Shorts.`);
