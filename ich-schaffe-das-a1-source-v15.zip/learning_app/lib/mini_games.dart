import 'dart:math';

import 'package:flutter/material.dart';

enum MiniGameKind { planks, territory }

extension MiniGameKindLabel on MiniGameKind {
  String get title => this == MiniGameKind.planks
      ? 'Wooden escape'
      : 'Color takeover';
  String get subtitle => this == MiniGameKind.planks
      ? 'Clear a path and slide the marked plank out.'
      : 'Grow your color across the map. Reach more than half.';
  IconData get icon => this == MiniGameKind.planks
      ? Icons.view_module_rounded
      : Icons.public_rounded;
}

class PlankPiece {
  const PlankPiece({required this.id, required this.row, required this.column,
    required this.length, required this.horizontal, this.target = false});
  final String id;
  final int row;
  final int column;
  final int length;
  final bool horizontal;
  final bool target;

  PlankPiece moveTo(int nextRow, int nextColumn) => PlankPiece(
        id: id,
        row: nextRow,
        column: nextColumn,
        length: length,
        horizontal: horizontal,
        target: target,
      );
}

class PlankLevel {
  const PlankLevel(this.number, this.pieces);
  final int number;
  final List<PlankPiece> pieces;
}

/// Twenty layouts add blockers through level eight, then add decoys and vary
/// the exit lane to keep the later boards crowded without overlapping planks.
List<PlankLevel> plankLevels() => List.generate(20, (index) {
      final number = index + 1;
      final targetRow = 1 + (index % 4);
      final blockers = min(8, 1 + index);
      final pieces = <PlankPiece>[
        PlankPiece(id: 'target', row: targetRow, column: 0,
            length: 2, horizontal: true, target: true),
      ];
      final occupied = <String>{'$targetRow:0', '$targetRow:1'};
      for (var obstacle = 0; obstacle < blockers; obstacle++) {
        final column = 2 + obstacle % 4;
        final candidateRows = <int>[
          targetRow - 1,
          targetRow + 1,
          0,
          2,
          4,
          1,
          3,
        ];
        final row = candidateRows.firstWhere((candidate) =>
            candidate >= 0 && candidate + 1 < 6 &&
            !occupied.contains('$candidate:$column') &&
            !occupied.contains('${candidate + 1}:$column'));
        pieces.add(PlankPiece(id: 'block-$obstacle', row: row,
            column: column, length: 2, horizontal: false));
        occupied
          ..add('$row:$column')
          ..add('${row + 1}:$column');
      }
      // Later boards add short decoy planks in any remaining free lanes.
      final decoys = min(6, max(0, index - 7));
      for (var decoy = 0; decoy < decoys; decoy++) {
        final candidates = [
          for (var row = 0; row < 6; row++)
            for (var column = 0; column < 5; column++) (row, column),
        ];
        final position = candidates.firstWhere((position) =>
            !occupied.contains('${position.$1}:${position.$2}') &&
            !occupied.contains('${position.$1}:${position.$2 + 1}'));
        pieces.add(PlankPiece(id: 'decoy-$decoy', row: position.$1,
            column: position.$2, length: 2, horizontal: true));
        occupied
          ..add('${position.$1}:${position.$2}')
          ..add('${position.$1}:${position.$2 + 1}');
      }
      return PlankLevel(number, List.unmodifiable(pieces));
    });

class TerritoryLevel {
  const TerritoryLevel({required this.number, required this.size,
    required this.blocked, required this.playerSeeds,
    required this.opponentSeeds});
  final int number;
  final int size;
  final Set<int> blocked;
  final Set<int> playerSeeds;
  final Set<int> opponentSeeds;
  int get playableCells => size * size - blocked.length;

  static List<TerritoryLevel> all() => List.generate(20, (index) {
        final size = 5 + min(index ~/ 3, 4).toInt();
        final blocked = <int>{};
        final obstacleCount = min(index ~/ 2, size - 2).toInt();
        for (var obstacle = 0; obstacle < obstacleCount; obstacle++) {
          final row = 1 + ((obstacle * 2 + index) % (size - 2));
          final column = 1 + ((obstacle * 3 + index ~/ 2) % (size - 2));
          final cell = row * size + column;
          final occupied = <int>{0, size, size * size - 1,
            size * size - size - 1};
          if (!occupied.contains(cell)) blocked.add(cell);
        }
        return TerritoryLevel(
          number: index + 1,
          size: size,
          blocked: Set.unmodifiable(blocked),
          playerSeeds: {0, size},
          opponentSeeds: {size * size - 1, size * size - size - 1},
        );
      });
}

enum TerritoryOutcome { playing, won, lost }

class TerritoryGameState {
  TerritoryGameState(this.level)
      : cells = List<int>.filled(level.size * level.size, 0) {
    for (final index in level.blocked) {
      cells[index] = -1;
    }
    for (final index in level.playerSeeds) {
      cells[index] = 1;
    }
    for (final index in level.opponentSeeds) {
      cells[index] = 2;
    }
  }

  final TerritoryLevel level;
  final List<int> cells;
  int turns = 0;
  TerritoryOutcome outcome = TerritoryOutcome.playing;
  int get playerCount => cells.where((cell) => cell == 1).length;
  int get opponentCount => cells.where((cell) => cell == 2).length;
  int get majority => level.playableCells ~/ 2 + 1;

  bool isAvailableToPlayer(int index) => cells[index] == 0 &&
      _neighbors(index).any((neighbor) => cells[neighbor] == 1);

  bool tap(int index) {
    if (outcome != TerritoryOutcome.playing ||
        index < 0 || index >= cells.length || !isAvailableToPlayer(index)) {
      return false;
    }
    final burst = <int>{index, ..._neighbors(index)}
        .where((cell) => cells[cell] == 0).toList();
    for (final cell in burst) {
      cells[cell] = 1;
    }
    turns++;
    if (_updateOutcome()) return true;
    _opponentSpreads();
    _updateOutcome();
    return true;
  }

  bool _updateOutcome() {
    if (playerCount >= majority) {
      outcome = TerritoryOutcome.won;
      return true;
    }
    if (opponentCount >= majority ||
        !cells.asMap().entries.any((entry) =>
            entry.value == 0 && isAvailableToPlayer(entry.key))) {
      outcome = TerritoryOutcome.lost;
      return true;
    }
    return false;
  }

  void _opponentSpreads() {
    final frontier = <int>[];
    for (var i = 0; i < cells.length; i++) {
      if (cells[i] == 0 && _neighbors(i).any((neighbor) => cells[neighbor] == 2)) {
        frontier.add(i);
      }
    }
    if (frontier.isEmpty) return;
    // The rival expands toward the board center, giving the learner time to
    // choose useful cells while keeping each level deterministic.
    final center = (level.size - 1) / 2;
    frontier.sort((a, b) {
      final scoreA = _distanceToCenter(a, center);
      final scoreB = _distanceToCenter(b, center);
      return scoreA.compareTo(scoreB);
    });
    cells[frontier.first] = 2;
  }

  double _distanceToCenter(int index, double center) {
    final row = index ~/ level.size;
    final column = index % level.size;
    return (row - center).abs() + (column - center).abs();
  }

  List<int> _neighbors(int index) {
    final row = index ~/ level.size;
    final column = index % level.size;
    return [
      if (row > 0) index - level.size,
      if (row < level.size - 1) index + level.size,
      if (column > 0) index - 1,
      if (column < level.size - 1) index + 1,
    ].where((neighbor) => cells[neighbor] != -1).toList();
  }
}

class GameBreakCard extends StatefulWidget {
  const GameBreakCard({super.key, required this.kind, required this.startLevel,
    required this.onLevelCompleted});
  final MiniGameKind kind;
  final int startLevel;
  final ValueChanged<int> onLevelCompleted;

  @override
  State<GameBreakCard> createState() => _GameBreakCardState();
}

class _GameBreakCardState extends State<GameBreakCard> {
  late int _level;
  late final List<PlankLevel> _plankLevels;
  late final List<TerritoryLevel> _territoryLevels;
  late List<PlankPiece> _pieces;
  late TerritoryGameState _territory;
  String? _dragging;
  double _dragDistance = 0;
  bool _cleared = false;

  @override
  void initState() {
    super.initState();
    _level = widget.startLevel.clamp(1, 20).toInt();
    _plankLevels = plankLevels();
    _territoryLevels = TerritoryLevel.all();
    _resetLevel();
  }

  @override
  void didUpdateWidget(covariant GameBreakCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.kind != oldWidget.kind) {
      _level = widget.startLevel.clamp(1, 20).toInt();
      _resetLevel();
    } else if (!_cleared && widget.startLevel > _level) {
      _level = widget.startLevel.clamp(1, 20).toInt();
      _resetLevel();
    }
  }

  void _resetLevel() {
    _pieces = List.of(_plankLevels[_level - 1].pieces);
    _territory = TerritoryGameState(_territoryLevels[_level - 1]);
    _cleared = false;
    _dragging = null;
    _dragDistance = 0;
  }

  bool _canMove(PlankPiece piece, int row, int column) {
    if (piece.horizontal && (row != piece.row || column < 0 ||
        column + piece.length > 7)) {
      return false;
    }
    if (!piece.horizontal && (column != piece.column || row < 0 ||
        row + piece.length > 6)) {
      return false;
    }
    for (var offset = 0; offset < piece.length; offset++) {
      final cellRow = row + (piece.horizontal ? 0 : offset);
      final cellColumn = column + (piece.horizontal ? offset : 0);
      if (cellColumn >= 6) continue;
      for (final other in _pieces) {
        if (other.id == piece.id) continue;
        for (var otherOffset = 0; otherOffset < other.length; otherOffset++) {
          final otherRow = other.row + (other.horizontal ? 0 : otherOffset);
          final otherColumn = other.column + (other.horizontal ? otherOffset : 0);
          if (cellRow == otherRow && cellColumn == otherColumn) return false;
        }
      }
    }
    return true;
  }

  void _moveSelected(DragUpdateDetails details, double cellSize) {
    final id = _dragging;
    if (id == null || _cleared) return;
    final pieceIndex = _pieces.indexWhere((piece) => piece.id == id);
    if (pieceIndex < 0) return;
    final piece = _pieces[pieceIndex];
    final delta = piece.horizontal ? details.delta.dx : details.delta.dy;
    _dragDistance += delta;
    while (_dragDistance.abs() >= cellSize * 0.55) {
      final direction = _dragDistance > 0 ? 1 : -1;
      final row = piece.row + (piece.horizontal ? 0 : direction);
      final column = piece.column + (piece.horizontal ? direction : 0);
      if (!_canMove(piece, row, column)) {
        _dragDistance = 0;
        break;
      }
      setState(() {
        _pieces[pieceIndex] = piece.moveTo(row, column);
        _dragDistance -= direction * cellSize;
        if (piece.target && column + piece.length > 6) {
          _cleared = true;
          widget.onLevelCompleted(_level);
        }
      });
      break;
    }
  }

  void _nextLevel() {
    if (_level >= 20) return;
    setState(() {
      _level++;
      _resetLevel();
    });
  }

  void _claimTerritory(int index) {
    setState(() => _territory.tap(index));
    if (_territory.outcome == TerritoryOutcome.won) {
      setState(() => _cleared = true);
      widget.onLevelCompleted(_level);
    }
  }

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: const Color(0xFF1D2940),
      borderRadius: BorderRadius.circular(26),
    ),
    padding: const EdgeInsets.fromLTRB(22, 96, 22, 22),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Icon(widget.kind.icon, color: const Color(0xFFF5C85B)),
        const SizedBox(width: 10),
        Expanded(child: Text(widget.kind.title.toUpperCase(),
            style: const TextStyle(color: Color(0xFFF5C85B),
                fontWeight: FontWeight.w800, letterSpacing: 1.2))),
        Text('LEVEL $_level / 20', style: const TextStyle(color: Colors.white70,
            fontWeight: FontWeight.w700)),
      ]),
      const SizedBox(height: 12),
      Text(widget.kind.subtitle, style: const TextStyle(
          color: Colors.white70, fontSize: 16)),
      const SizedBox(height: 16),
      Expanded(child: widget.kind == MiniGameKind.planks
          ? _buildPlankBoard()
          : _buildTerritoryBoard()),
      const SizedBox(height: 12),
      if (widget.kind == MiniGameKind.planks) ...[
        Text(_cleared ? 'Path clear!' : 'Drag each plank along its length.',
            style: const TextStyle(color: Colors.white70)),
        if (_cleared) _nextButton(),
      ] else ...[
        Text('Your color: ${_territory.playerCount} / ${_territory.majority} · '
            'Rival: ${_territory.opponentCount}',
            style: const TextStyle(color: Colors.white70)),
        if (_territory.outcome != TerritoryOutcome.playing) ...[
          const SizedBox(height: 8),
          Text(_territory.outcome == TerritoryOutcome.won
              ? 'More than half the map is yours!'
              : 'The rival took the majority. Try another path.',
              style: const TextStyle(fontWeight: FontWeight.w700)),
          if (_territory.outcome == TerritoryOutcome.won) _nextButton(),
          if (_territory.outcome == TerritoryOutcome.lost)
            TextButton(onPressed: () => setState(_resetLevel),
                child: const Text('Try this level again')),
        ] else
          const Text('Tap a glowing tile next to your color to expand.',
              style: TextStyle(color: Colors.white70)),
      ],
    ]),
  );

  Widget _nextButton() => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: FilledButton.icon(
      onPressed: _level < 20 ? _nextLevel : null,
      icon: const Icon(Icons.arrow_forward_rounded),
      label: Text(_level < 20 ? 'Next level' : 'All 20 levels complete'),
    ),
  );

  Widget _buildPlankBoard() => LayoutBuilder(builder: (context, constraints) {
    final boardSize = min(constraints.maxWidth, constraints.maxHeight);
    final cell = boardSize / 6;
    return Center(child: SizedBox(width: boardSize, height: boardSize,
      child: Container(
        decoration: BoxDecoration(color: const Color(0xFF111827),
          border: Border.all(color: Colors.white24, width: 2),
          borderRadius: BorderRadius.circular(14)),
        child: Stack(children: [
          for (var row = 0; row < 6; row++)
            for (var column = 0; column < 6; column++)
              Positioned(left: column * cell, top: row * cell,
                width: cell, height: cell,
                child: Container(margin: const EdgeInsets.all(2),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.035),
                    borderRadius: BorderRadius.circular(5)))),
          for (final piece in _pieces)
            Positioned(
              left: piece.column * cell + 2,
              top: piece.row * cell + 2,
              width: (piece.horizontal ? piece.length : 1) * cell - 4,
              height: (piece.horizontal ? 1 : piece.length) * cell - 4,
              child: GestureDetector(
                onPanStart: (_) => setState(() {
                  _dragging = piece.id;
                  _dragDistance = 0;
                }),
                onPanUpdate: (details) => _moveSelected(details, cell),
                onPanEnd: (_) => setState(() { _dragging = null; _dragDistance = 0; }),
                child: AnimatedContainer(duration: const Duration(milliseconds: 90),
                  decoration: BoxDecoration(
                    color: piece.target ? const Color(0xFFF5C85B)
                        : const Color(0xFF9B6846),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: piece.target
                        ? Colors.white : const Color(0xFFD3A47E), width: 2),
                    boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .3),
                        blurRadius: 6, offset: const Offset(0, 3))],
                  ),
                  child: Center(child: Icon(piece.target ? Icons.star_rounded
                      : piece.horizontal ? Icons.drag_handle_rounded
                          : Icons.drag_indicator_rounded,
                    color: piece.target ? const Color(0xFF4A3510) : Colors.white70)),
                ),
              ),
            ),
          Positioned(right: -2, top: 2 * cell + cell * .25,
            height: cell * .5, width: 15,
            child: const Icon(Icons.chevron_right, color: Color(0xFFF5C85B))),
        ]),
      ),
    ));
  });

  Widget _buildTerritoryBoard() => LayoutBuilder(builder: (context, constraints) {
    final level = _territory.level;
    final side = min(constraints.maxWidth, constraints.maxHeight);
    return Center(child: SizedBox.square(dimension: side,
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        padding: EdgeInsets.zero,
        itemCount: _territory.cells.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: level.size, crossAxisSpacing: 3, mainAxisSpacing: 3),
        itemBuilder: (context, index) {
          final value = _territory.cells[index];
          final available = _territory.isAvailableToPlayer(index) &&
              _territory.outcome == TerritoryOutcome.playing;
          final color = switch (value) {
            -1 => const Color(0xFF111827),
            1 => const Color(0xFF22A875),
            2 => const Color(0xFFE46A5D),
            _ => const Color(0xFF59677A),
          };
          return Material(
            color: color,
            borderRadius: BorderRadius.circular(5),
            child: InkWell(
              borderRadius: BorderRadius.circular(5),
              onTap: available ? () => _claimTerritory(index) : null,
              child: available
                  ? const Icon(Icons.add, size: 13, color: Colors.white70)
                  : null,
            ),
          );
        },
      ),
    ));
  });
}
