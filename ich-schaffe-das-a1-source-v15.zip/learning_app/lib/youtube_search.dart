import 'dart:convert';
import 'dart:io';

import 'shorts_catalog.dart';

const youtubeApiKey = String.fromEnvironment('YOUTUBE_API_KEY');
const _iosBundleId = 'de.ichschaffedas.a1';

Uri youtubeSearchUri(String keyword) => Uri.https(
      'www.googleapis.com',
      '/youtube/v3/search',
      {
        'part': 'snippet',
        'q': '#${keyword.trim().replaceFirst(RegExp(r'^#+'), '')} #shorts',
        'type': 'video',
        'videoDuration': 'short',
        'videoEmbeddable': 'true',
        'maxResults': '50',
      },
    );

List<YoutubeShort> parseYoutubeSearch(String body, String keyword) {
  final decoded = jsonDecode(body) as Map<String, dynamic>;
  final items = (decoded['items'] as List<dynamic>? ?? const []);
  return items.map((item) {
    final value = item as Map<String, dynamic>;
    final id = (value['id'] as Map<String, dynamic>?)?['videoId'] as String?;
    final snippet = value['snippet'] as Map<String, dynamic>? ?? const {};
    if (id == null || !RegExp(r'^[A-Za-z0-9_-]{11}$').hasMatch(id)) {
      return null;
    }
    return YoutubeShort(id, snippet['title'] as String? ?? 'YouTube Short',
        snippet['channelTitle'] as String? ?? 'YouTube', [keyword]);
  }).whereType<YoutubeShort>().toList();
}

Future<List<YoutubeShort>> searchSessionShorts(List<String> keywords) async {
  if (youtubeApiKey.isEmpty || keywords.isEmpty) return const [];
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final shorts = <YoutubeShort>[];
    final seen = <String>{};
    for (final keyword in keywords.take(4)) {
      try {
        final request = await client.getUrl(youtubeSearchUri(keyword));
        request.headers.set('X-Goog-Api-Key', youtubeApiKey);
        request.headers.set('X-Ios-Bundle-Identifier', _iosBundleId);
        final response = await request.close().timeout(const Duration(seconds: 12));
        if (response.statusCode != HttpStatus.ok) {
          await response.drain<void>();
          continue;
        }
        final body = await utf8.decoder.bind(response).join();
        for (final video in parseYoutubeSearch(body, keyword)) {
          if (seen.add(video.id)) shorts.add(video);
        }
      } catch (_) {
        // A failed interest does not block the rest of the session.
      }
    }
    return shorts;
  } finally {
    client.close(force: true);
  }
}
