import 'dart:math';

import 'mini_games.dart';

/// A feed item is either a course activity, a YouTube Short, or a mini-game.
class FeedSlot {
  const FeedSlot.activity(this.activityIndex)
      : shortIndex = null,
        game = null;
  const FeedSlot.short(this.shortIndex)
      : activityIndex = null,
        game = null;
  const FeedSlot.game(this.game)
      : activityIndex = null,
        shortIndex = null;

  final int? activityIndex;
  final int? shortIndex;
  final MiniGameKind? game;
  bool get isShort => shortIndex != null;
  bool get isGame => game != null;
  bool get isActivity => activityIndex != null;
}

/// Opens with four Shorts, then offers a break after each four course cards.
/// Four of each full lesson's breaks are games when game mode is enabled.
/// Their positions depend on the lesson's absolute card numbers, so reopening
/// a lesson cannot add extra game breaks to it.
List<FeedSlot> planSessionFeed({
  required int firstUnfinishedActivity,
  required int activityCount,
  required int availableShorts,
  List<int> lessonNumbers = const [],
  bool reelsEnabled = true,
  bool gamesEnabled = false,
  int randomSeed = 0,
}) {
  if (firstUnfinishedActivity < 0 ||
      activityCount < firstUnfinishedActivity ||
      availableShorts < 0 ||
      (lessonNumbers.isNotEmpty && lessonNumbers.length != activityCount)) {
    throw ArgumentError('Invalid session feed bounds');
  }
  final canShowReels = reelsEnabled && availableShorts > 0;
  final slots = <FeedSlot>[];
  final random = Random(randomSeed);
  var nextShort = 0;
  void addShort() => slots.add(FeedSlot.short(nextShort++ % availableShorts));

  if (canShowReels) {
    for (var i = 0; i < 4; i++) {
      addShort();
    }
  }

  var lessonStart = 0;
  while (lessonStart < activityCount) {
    var lessonEnd = lessonStart + 1;
    while (lessonEnd < activityCount &&
        (lessonNumbers.isEmpty ||
            lessonNumbers[lessonEnd] == lessonNumbers[lessonStart])) {
      lessonEnd++;
    }

    final breakCount = (lessonEnd - lessonStart) ~/ 4;
    final gameCount = gamesEnabled ? min(4, breakCount) : 0;
    final gameBreaks = <int>{
      for (var i = 1; i <= gameCount; i++)
        (i * breakCount / gameCount).ceil(),
    };

    for (var activity = max(lessonStart, firstUnfinishedActivity);
        activity < lessonEnd;
        activity++) {
      slots.add(FeedSlot.activity(activity));
      final cardNumber = activity - lessonStart + 1;
      if (cardNumber % 4 != 0) continue;
      final breakNumber = cardNumber ~/ 4;
      if (gameBreaks.contains(breakNumber)) {
        slots.add(FeedSlot.game(
            MiniGameKind.values[random.nextInt(MiniGameKind.values.length)]));
      } else if (canShowReels) {
        addShort();
      }
    }
    lessonStart = lessonEnd;
  }
  return slots;
}
