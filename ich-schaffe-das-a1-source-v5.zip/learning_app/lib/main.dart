import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

import 'feed_plan.dart';
import 'shorts_catalog.dart';

const _supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const _supabaseKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (_supabaseUrl.isNotEmpty && _supabaseKey.isNotEmpty) {
    await Supabase.initialize(url: _supabaseUrl, publishableKey: _supabaseKey);
  }
  runApp(const LearningApp());
}

class Activity {
  const Activity({
    required this.slug,
    required this.kind,
    required this.title,
    required this.lessonTitle,
    required this.lessonNumber,
    required this.payload,
  });

  final String slug;
  final String kind;
  final String title;
  final String lessonTitle;
  final int lessonNumber;
  final Map<String, dynamic> payload;

  factory Activity.fromJson(Map<String, dynamic> json, String lessonTitle,
      int lessonNumber) {
    return Activity(
      slug: json['slug'] as String,
      kind: json['kind'] as String,
      title: json['title'] as String,
      lessonTitle: lessonTitle,
      lessonNumber: lessonNumber,
      payload: json,
    );
  }
}

class Curriculum {
  const Curriculum(this.title, this.edition, this.slug, this.activities);

  final String title;
  final String edition;
  final String slug;
  final List<Activity> activities;

  factory Curriculum.fromJson(Map<String, dynamic> data) {
    final book = data['book'] as Map<String, dynamic>;
    final activities = <Activity>[];
    for (final lesson in data['lessons'] as List<dynamic>) {
      final row = lesson as Map<String, dynamic>;
      for (final item in row['activities'] as List<dynamic>) {
        activities.add(Activity.fromJson(
          item as Map<String, dynamic>,
          row['title'] as String,
          row['number'] as int,
        ));
      }
    }
    return Curriculum(
      book['title'] as String,
      book['edition'] as String,
      book['slug'] as String,
      activities,
    );
  }
}

class LearningStore {
  LearningStore(this.courseAsset, this.bookSlug, this.profileKey);

  final String courseAsset;
  final String bookSlug;
  final String profileKey;

  SupabaseClient? get _client =>
      _supabaseUrl.isEmpty || _supabaseKey.isEmpty ? null : Supabase.instance.client;

  Future<Curriculum> load() async {
    final client = _client;
    if (client == null) {
      final sample = await rootBundle.loadString(courseAsset);
      return Curriculum.fromJson(jsonDecode(sample) as Map<String, dynamic>);
    }
    if (client.auth.currentUser == null) {
      await client.auth.signInAnonymously();
    }
    final book = await client
        .from('learning_books')
        .select('id,slug,title,edition,level')
        .eq('slug', bookSlug)
        .single();
    final lessons = await client
        .from('learning_lessons')
        .select('id,slug,number,title,goal')
        .eq('book_id', book['id'])
        .order('number');
    final lessonData = <Map<String, dynamic>>[];
    for (final lesson in lessons) {
      final rows = await client
          .from('learning_activities')
          .select('slug,kind,title,payload')
          .eq('lesson_id', lesson['id'])
          .order('position');
      lessonData.add({
        ...lesson,
        'activities': rows.map((row) => {
              ...(row['payload'] as Map<String, dynamic>),
              'slug': row['slug'],
              'kind': row['kind'],
              'title': row['title'],
            }).toList(),
      });
    }
    return Curriculum.fromJson({'book': book, 'lessons': lessonData});
  }

  Future<Set<String>> completed(Curriculum curriculum) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'done:$profileKey:${curriculum.slug}';
    final done = prefs.getStringList(key)?.toSet() ?? <String>{};
    // Assign pre-profile A1 progress only to the first profile that opens A1.
    if (done.isEmpty && curriculum.slug == 'original-a1-starter') {
      final owner = prefs.getString('legacy_progress_owner');
      final legacy = prefs.getStringList('done:${curriculum.slug}');
      if (legacy != null && (owner == null || owner == profileKey)) {
        if (owner == null) await prefs.setString('legacy_progress_owner', profileKey);
        done.addAll(legacy);
        await prefs.setStringList(key, done.toList());
      }
    }
    final client = _client;
    if (client != null) {
      final userId = client.auth.currentUser!.id;
      final rows = await client
          .from('learner_activity_progress')
          .select('activity_slug')
          .eq('user_id', userId)
          .eq('profile_key', profileKey)
          .eq('book_slug', curriculum.slug);
      done.addAll(rows.map((row) => row['activity_slug'] as String));
      await prefs.setStringList(key, done.toList());
    }
    return done;
  }

  Future<bool> complete(Curriculum curriculum, Activity activity,
      Set<String> done, int? selectedAnswer) async {
    final client = _client;
    final prefs = await SharedPreferences.getInstance();
    if (selectedAnswer != null) {
      final key = 'answers:$profileKey:${curriculum.slug}';
      final attempts = prefs.getStringList(key) ?? <String>[];
      attempts.add(jsonEncode({
        'activity_slug': activity.slug,
        'selected_answer': selectedAnswer,
        'is_correct': selectedAnswer == activity.payload['answer'],
        'answered_at': DateTime.now().toUtc().toIso8601String(),
      }));
      await prefs.setStringList(key, attempts);
    }
    if (selectedAnswer != null && client != null) {
      await client.from('learner_answers').insert({
        'user_id': client.auth.currentUser!.id,
        'profile_key': profileKey,
        'book_slug': curriculum.slug,
        'activity_slug': activity.slug,
        'selected_answer': selectedAnswer,
        'is_correct': selectedAnswer == activity.payload['answer'],
      });
    }
    if (selectedAnswer != null && selectedAnswer != activity.payload['answer']) {
      return false;
    }
    done.add(activity.slug);
    await prefs.setStringList('done:$profileKey:${curriculum.slug}', done.toList());
    if (client != null) {
      final userId = client.auth.currentUser!.id;
      await client.from('learner_activity_progress').upsert({
        'user_id': userId,
        'profile_key': profileKey,
        'book_slug': curriculum.slug,
        'activity_slug': activity.slug,
        'completed_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id,profile_key,book_slug,activity_slug');
    }
    return true;
  }
}

class LearningApp extends StatelessWidget {
  const LearningApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ich schaffe das',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF10182A),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFF5C85B),
          brightness: Brightness.dark,
        ),
        textTheme: ThemeData.dark().textTheme.apply(fontFamily: 'Arial'),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _name = TextEditingController();
  final _keywords = TextEditingController();
  List<String> _profiles = [];
  String? _message;
  bool _reelsEnabled = true;
  bool _a1Complete = false;
  int _progressLookup = 0;
  int? _a1ActivityCount;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    final prefs = await SharedPreferences.getInstance();
    final last = prefs.getString('last_profile') ?? '';
    if (!mounted) return;
    setState(() {
      _profiles = prefs.getStringList('profiles') ?? [];
      _name.text = last;
      _keywords.text = prefs.getString('keywords:${last.toLowerCase()}') ?? 'German';
      _reelsEnabled = prefs.getBool('reels:${last.toLowerCase()}') ?? true;
    });
    await _refreshA1Completion(last);
  }

  Future<void> _refreshA1Completion(String profile) async {
    final lookup = ++_progressLookup;
    final key = profile.trim().toLowerCase();
    if (key.isEmpty) {
      if (mounted && lookup == _progressLookup) {
        setState(() => _a1Complete = false);
      }
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    var activityCount = _a1ActivityCount;
    if (activityCount == null) {
      final raw = await rootBundle.loadString('assets/starter_content.json');
      activityCount = Curriculum.fromJson(
          jsonDecode(raw) as Map<String, dynamic>).activities.length;
      _a1ActivityCount = activityCount;
    }
    final done = prefs.getStringList('done:$key:original-a1-starter') ??
        (prefs.getString('legacy_progress_owner') == null ||
                prefs.getString('legacy_progress_owner') == key
            ? prefs.getStringList('done:original-a1-starter') ?? <String>[]
            : <String>[]);
    if (mounted && lookup == _progressLookup) {
      setState(() => _a1Complete = done.length >= activityCount!);
    }
  }

  Future<void> _chooseProfile(String profile) async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _name.text = profile;
      _keywords.text = prefs.getString('keywords:${profile.toLowerCase()}') ?? 'German';
      _reelsEnabled = prefs.getBool('reels:${profile.toLowerCase()}') ?? true;
      _message = null;
    });
    await _refreshA1Completion(profile);
  }

  Future<void> _start(String asset, String bookSlug) async {
    final displayName = _name.text.trim();
    if (displayName.isEmpty) {
      setState(() => _message = 'Enter a profile name to save your place.');
      return;
    }
    final profileKey = displayName.toLowerCase();
    final prefs = await SharedPreferences.getInstance();
    final profiles = prefs.getStringList('profiles') ?? [];
    if (!profiles.any((name) => name.toLowerCase() == profileKey)) {
      profiles.add(displayName);
      await prefs.setStringList('profiles', profiles);
    }
    await prefs.setString('last_profile', displayName);
    await prefs.setString('keywords:$profileKey', _keywords.text.trim());
    await prefs.setBool('reels:$profileKey', _reelsEnabled);
    if (!mounted) return;
    setState(() { _profiles = profiles; _message = null; });
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => LearningScreen(
        courseAsset: asset,
        bookSlug: bookSlug,
        profileKey: profileKey,
        profileName: displayName,
        keywords: parseInterestKeywords(_keywords.text),
        includeReels: _reelsEnabled,
      ),
    ));
    await _refreshA1Completion(displayName);
  }

  @override
  void dispose() {
    _name.dispose();
    _keywords.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(24), children: [
      const SizedBox(height: 20),
      const Text('Ich schaffe das', style: TextStyle(
          fontSize: 34, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      const Text('Learn a little. Keep going tomorrow.',
          style: TextStyle(color: Colors.white70, fontSize: 16)),
      const SizedBox(height: 32),
      TextField(controller: _name, textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Profile name',
              hintText: 'Enter your name the first time', border: OutlineInputBorder()),
          onChanged: (value) {
            setState(() {});
            _refreshA1Completion(value);
          }),
      if (_profiles.isNotEmpty) ...[
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: _profiles.map((profile) =>
          ActionChip(label: Text(profile), onPressed: () => _chooseProfile(profile))
        ).toList()),
      ],
      const SizedBox(height: 18),
      const SizedBox(height: 10),
      const Text('YouTube Reels', style: TextStyle(
          fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      TextField(controller: _keywords,
          decoration: const InputDecoration(
            labelText: 'Reels keywords',
            hintText: 'German, travel, football',
            helperText: 'Comma-separated interests used to rank the test Reels catalog.',
            border: OutlineInputBorder(),
          ),
          onChanged: (value) async {
            final key = _name.text.trim().toLowerCase();
            if (key.isNotEmpty) {
              final prefs = await SharedPreferences.getInstance();
              await prefs.setString('keywords:$key', value);
            }
          }),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Include Reels in my session'),
        subtitle: Text(_reelsEnabled
            ? 'Three at the start, then one after every four learning cards.'
            : 'Learning session without videos.'),
        value: _reelsEnabled,
        onChanged: (enabled) async {
          setState(() => _reelsEnabled = enabled);
          final profileKey = _name.text.trim().toLowerCase();
          if (profileKey.isNotEmpty) {
            final prefs = await SharedPreferences.getInstance();
            await prefs.setBool('reels:$profileKey', enabled);
          }
        },
      ),
      if (_message != null) ...[
        const SizedBox(height: 12),
        Text(_message!, style: const TextStyle(color: Colors.orangeAccent)),
      ],
      const SizedBox(height: 30),
      const Text('Choose a course', style: TextStyle(
          fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 14),
      _CourseTile(title: 'A1', subtitle: '35 lessons · start or continue',
          icon: Icons.auto_stories_rounded,
          enabled: _name.text.trim().isNotEmpty,
          onTap: () => _start('assets/starter_content.json', 'original-a1-starter')),
      const SizedBox(height: 14),
      _CourseTile(title: 'A1+ Revision',
          icon: _a1Complete ? Icons.add_circle_outline_rounded : Icons.lock_outline_rounded,
          enabled: _a1Complete,
          subtitle: _a1Complete
              ? '14 revision lessons · unlocked after A1'
              : 'Locked · complete A1 to unlock',
          onTap: () => _start('assets/a1_plus_content.json', 'ich-schaffe-das-a1-plus')),
      const SizedBox(height: 20),
      const Text('Progress is saved on this device for each profile and course. '
          'The test Shorts catalog is limited; keywords prioritize matching videos.',
          style: TextStyle(color: Colors.white54, height: 1.5)),
    ])),
  );
}

class _CourseTile extends StatelessWidget {
  const _CourseTile({required this.title, required this.subtitle,
      required this.icon, required this.onTap, this.enabled = true});
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final bool enabled;

  @override
  Widget build(BuildContext context) => Material(
    color: enabled ? const Color(0xFF1D2940) : const Color(0xFF171F30),
    borderRadius: BorderRadius.circular(24),
    child: InkWell(borderRadius: BorderRadius.circular(24),
      onTap: enabled ? onTap : null,
      child: Padding(padding: const EdgeInsets.all(22), child: Row(children: [
        Icon(icon, color: enabled ? const Color(0xFFF5C85B) : Colors.white30, size: 30),
        const SizedBox(width: 18),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          children: [Text(title, style: TextStyle(fontSize: 24,
              fontWeight: FontWeight.w800,
              color: enabled ? Colors.white : Colors.white38)), const SizedBox(height: 5),
            Text(subtitle, style: TextStyle(color: enabled ? Colors.white70 : Colors.white38))])),
        Icon(enabled ? Icons.chevron_right_rounded : Icons.lock_outline_rounded,
            color: enabled ? Colors.white70 : Colors.white30),
      ])),
    ),
  );
}

class LearningScreen extends StatefulWidget {
  const LearningScreen({super.key, required this.courseAsset,
      required this.bookSlug, required this.profileKey,
      required this.profileName, required this.keywords,
      required this.includeReels});

  final String courseAsset;
  final String bookSlug;
  final String profileKey;
  final String profileName;
  final List<String> keywords;
  final bool includeReels;

  @override
  State<LearningScreen> createState() => _LearningScreenState();
}

class _LearningScreenState extends State<LearningScreen> {
  late final LearningStore _store;
  final _controller = PageController();
  Curriculum? _curriculum;
  List<YoutubeShort> _shorts = [];
  List<FeedSlot> _feed = [];
  Set<String> _done = {};
  int _index = 0;
  int _feedIndex = 0;
  int? _selected;
  bool _busy = false;
  double _upwardOverscroll = 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _store = LearningStore(
        widget.courseAsset, widget.bookSlug, widget.profileKey);
    _load();
  }

  Future<void> _load() async {
    try {
      final curriculum = await _store.load();
      if (curriculum.activities.isEmpty) {
        throw StateError('This book has no published activities yet.');
      }
      final done = await _store.completed(curriculum);
      var index = curriculum.activities.indexWhere((a) => !done.contains(a.slug));
      if (index < 0) index = curriculum.activities.length - 1;
      final shorts = widget.includeReels
          ? await loadShortsCatalog(widget.keywords)
          : <YoutubeShort>[];
      final remaining = curriculum.activities.length - index;
      final plannedShorts = shorts.isEmpty ? 0 : 3 + (remaining ~/ 4);
      final feed = planSessionFeed(
        firstUnfinishedActivity: index,
        activityCount: curriculum.activities.length,
        availableShorts: plannedShorts,
      );
      if (!mounted) return;
      setState(() {
        _curriculum = curriculum;
        _shorts = shorts;
        _feed = feed;
        _done = done;
        _index = index;
        _feedIndex = 0;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_controller.hasClients) _controller.jumpToPage(0);
      });
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    }
  }

  Future<void> _complete(Activity activity) async {
    final curriculum = _curriculum!;
    final selected = _selected;
    if (activity.kind == 'quiz' && selected == null &&
        !_done.contains(activity.slug)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Choose an answer before continuing.')),
      );
      return;
    }
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final passed = await _store.complete(curriculum, activity, _done, selected);
      if (!mounted) return;
      if (!passed) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Try another answer to unlock the next card.')),
        );
        return;
      }
      setState(() => _selected = null);
      if (_feedIndex < _feed.length - 1) {
        await _controller.nextPage(
          duration: const Duration(milliseconds: 330),
          curve: Curves.easeOutCubic,
        );
      } else {
        setState(() {});
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save progress: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.cloud_off, size: 48),
                const SizedBox(height: 18),
                const Text('Could not load the course',
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Text(_error!, textAlign: TextAlign.center),
                const SizedBox(height: 24),
                FilledButton(onPressed: () {
                  setState(() => _error = null);
                  _load();
                }, child: const Text('Try again')),
              ]),
            ),
          ),
        ),
      );
    }
    final curriculum = _curriculum;
    if (curriculum == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final activities = curriculum.activities;
    final current = activities[_index];
    final unlockIndex = activities.indexWhere((a) => !_done.contains(a.slug));
    final maxIndex = unlockIndex < 0 ? activities.length - 1 : unlockIndex;
    final frontier = unlockIndex < 0
        ? _feed.length - 1
        : _feed.indexWhere((slot) => slot.activityIndex == maxIndex);
    final maxFeedIndex = frontier < 0 ? _feed.length - 1 : frontier;
    final atLearningFrontier = _feedIndex == maxFeedIndex &&
        _feed[_feedIndex].activityIndex == maxIndex &&
        !_done.contains(activities[maxIndex].slug);
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 16, 22, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                IconButton(onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.arrow_back_ios_new_rounded),
                    tooltip: 'Courses'),
                Expanded(child: Text(widget.profileName,
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800))),
                Text('${_done.length}/${activities.length}',
                    style: const TextStyle(color: Color(0xFFF5C85B), fontSize: 15)),
              ]),
              const SizedBox(height: 12),
              LinearProgressIndicator(
                value: _done.length / activities.length,
                minHeight: 5,
                borderRadius: BorderRadius.circular(20),
                backgroundColor: Colors.white12,
                color: const Color(0xFFF5C85B),
              ),
              const SizedBox(height: 12),
              Text('${curriculum.title}  •  Lesson ${current.lessonNumber}: ${current.lessonTitle}',
                  style: const TextStyle(color: Colors.white70, fontSize: 13)),
            ]),
          ),
          Expanded(
            child: NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                if (notification is ScrollStartNotification) {
                  _upwardOverscroll = 0;
                } else if (notification is OverscrollNotification &&
                    atLearningFrontier &&
                    notification.overscroll > 0) {
                  _upwardOverscroll += notification.overscroll;
                } else if (notification is ScrollEndNotification) {
                  if (_upwardOverscroll > 28 && !_busy &&
                      atLearningFrontier) {
                    _complete(activities[_index]);
                  }
                  _upwardOverscroll = 0;
                }
                return false;
              },
              child: PageView.builder(
              controller: _controller,
              scrollDirection: Axis.vertical,
              physics: const ClampingScrollPhysics(),
              itemCount: maxFeedIndex + 1,
              onPageChanged: (index) {
                if (index > maxFeedIndex) {
                  _controller.animateToPage(maxFeedIndex,
                      duration: const Duration(milliseconds: 220),
                      curve: Curves.easeOut);
                  return;
                }
                setState(() {
                  _feedIndex = index;
                  final activityIndex = _feed[index].activityIndex;
                  if (activityIndex != null) {
                    _index = activityIndex;
                    _selected = null;
                  }
                });
              },
              itemBuilder: (context, index) {
                final slot = _feed[index];
                if (slot.isShort) {
                  final video = _shorts[slot.shortIndex! % _shorts.length];
                  return _ShortsCard(
                    video: video,
                    active: index == _feedIndex,
                    onContinue: index < maxFeedIndex
                        ? () => _controller.nextPage(
                            duration: const Duration(milliseconds: 330),
                            curve: Curves.easeOutCubic)
                        : () => Navigator.of(context).pop(),
                  );
                }
                final activity = activities[slot.activityIndex!];
                return _ActivityCard(
                  activity: activity,
                  selected: index == _feedIndex ? _selected : null,
                  completed: _done.contains(activity.slug),
                  busy: _busy,
                  onSelect: (value) => setState(() => _selected = value),
                  onContinue: () => _complete(activity),
                );
              },
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(bottom: 10, top: 4),
            child: Text('SWIPE UP FOR THE NEXT CARD  ↑',
                style: TextStyle(color: Colors.white38, fontSize: 11,
                    letterSpacing: 1.5)),
          ),
        ]),
      ),
    );
  }
}

class _ShortsCard extends StatelessWidget {
  const _ShortsCard({required this.video, required this.active,
      required this.onContinue});

  final YoutubeShort video;
  final bool active;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
    child: Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1D2940),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white10),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('SHORT BREAK', style: TextStyle(
                color: Color(0xFFF5C85B), fontSize: 12,
                fontWeight: FontWeight.w800, letterSpacing: 1.5)),
              const SizedBox(height: 12),
              Expanded(child: LayoutBuilder(builder: (context, size) {
                final width = size.maxWidth < size.maxHeight * 9 / 16
                    ? size.maxWidth : size.maxHeight * 9 / 16;
                return Center(child: SizedBox(width: width,
                  child: ClipRRect(borderRadius: BorderRadius.circular(18),
                    child: active
                      ? _EmbeddedShort(key: ValueKey(video.id), videoId: video.id)
                      : Image.network(
                          'https://i.ytimg.com/vi/${video.id}/hqdefault.jpg',
                          fit: BoxFit.cover),
                  )),
                );
              })),
              const SizedBox(height: 12),
              Text(video.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
              Text(video.channel, style: const TextStyle(color: Colors.white60)),
              const SizedBox(height: 12),
              SizedBox(width: double.infinity, child: FilledButton(
                onPressed: onContinue,
                child: const Text('Continue learning ↑'),
              )),
            ],
          ),
        ),
      ),
    ),
  );
}

class _EmbeddedShort extends StatefulWidget {
  const _EmbeddedShort({super.key, required this.videoId});
  final String videoId;

  @override
  State<_EmbeddedShort> createState() => _EmbeddedShortState();
}

class _EmbeddedShortState extends State<_EmbeddedShort> {
  late final YoutubePlayerController _player;

  @override
  void initState() {
    super.initState();
    _player = YoutubePlayerController.fromVideoId(
      videoId: widget.videoId,
      autoPlay: true,
      params: const YoutubePlayerParams(
        showControls: true,
        showFullscreenButton: false,
        playsInline: true,
      ),
    );
  }

  @override
  void dispose() {
    _player.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => YoutubePlayer(
      controller: _player, aspectRatio: 9 / 16);
}

class _ActivityCard extends StatelessWidget {
  const _ActivityCard({
    required this.activity,
    required this.selected,
    required this.completed,
    required this.busy,
    required this.onSelect,
    required this.onContinue,
  });

  final Activity activity;
  final int? selected;
  final bool completed;
  final bool busy;
  final ValueChanged<int> onSelect;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    final payload = activity.payload;
    final kind = activity.kind;
    final label = switch (kind) {
      'grammar' => 'GRAMMAR',
      'vocabulary' => 'VOCABULARY',
      'quiz' => 'QUICK CHECK',
      _ => kind.toUpperCase(),
    };
    final icon = switch (kind) {
      'grammar' => Icons.menu_book_rounded,
      'vocabulary' => Icons.translate_rounded,
      'quiz' => Icons.psychology_alt_rounded,
      _ => Icons.auto_stories,
    };
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1D2940),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white10),
        ),
        child: Padding(
          padding: const EdgeInsets.all(26),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5C85B).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(icon, color: const Color(0xFFF5C85B)),
              ),
              const SizedBox(width: 12),
              Text(label, style: const TextStyle(
                  color: Color(0xFFF5C85B), fontSize: 12,
                  fontWeight: FontWeight.w800, letterSpacing: 1.5)),
              const Spacer(),
              if (completed) const Icon(Icons.check_circle,
                  color: Color(0xFF70D6AB)),
            ]),
            const SizedBox(height: 30),
            Text(activity.title, style: const TextStyle(
                fontSize: 30, fontWeight: FontWeight.w800, height: 1.1)),
            const SizedBox(height: 22),
            Expanded(child: SingleChildScrollView(child: switch (kind) {
              'grammar' => _GrammarBody(payload: payload),
              'vocabulary' => _VocabularyBody(payload: payload),
              'quiz' => _QuizBody(payload: payload, selected: selected,
                  onSelect: onSelect),
              _ => Text(payload['body']?.toString() ?? ''),
            })),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton(
              onPressed: busy || (kind == 'quiz' && selected == null && !completed)
                  ? null : onContinue,
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFF5C85B),
                foregroundColor: const Color(0xFF152039),
                padding: const EdgeInsets.symmetric(vertical: 17),
              ),
              child: Text(busy ? 'Saving…' : completed ? 'Continue' :
                kind == 'quiz' ? 'Check & continue' : 'Got it · continue',
                style: const TextStyle(fontWeight: FontWeight.w800)),
            )),
          ]),
        ),
      ),
    );
  }
}

class _GrammarBody extends StatelessWidget {
  const _GrammarBody({required this.payload});
  final Map<String, dynamic> payload;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(payload['body']?.toString() ?? '',
          style: const TextStyle(fontSize: 18, height: 1.55)),
      if (payload['example'] != null) ...[
        const SizedBox(height: 25),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.07),
            borderRadius: BorderRadius.circular(17),
          ),
          child: Text(payload['example'].toString(),
              style: const TextStyle(fontSize: 17, color: Color(0xFFF5C85B))),
        ),
      ],
    ],
  );
}

class _VocabularyBody extends StatelessWidget {
  const _VocabularyBody({required this.payload});
  final Map<String, dynamic> payload;

  @override
  Widget build(BuildContext context) {
    final items = payload['items'] as List<dynamic>? ?? [];
    return Column(children: items.map((entry) {
      final item = entry as Map<String, dynamic>;
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.06),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(item['de'].toString(),
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold))),
            Text(item['en'].toString(),
                style: const TextStyle(color: Color(0xFFF5C85B))),
          ]),
          const SizedBox(height: 7),
          Text(item['example'].toString(),
              style: const TextStyle(color: Colors.white60)),
        ]),
      );
    }).toList());
  }
}

class _QuizBody extends StatelessWidget {
  const _QuizBody({required this.payload, required this.selected,
      required this.onSelect});
  final Map<String, dynamic> payload;
  final int? selected;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final options = payload['options'] as List<dynamic>? ?? [];
    final correct = payload['answer'] as int;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(payload['question'].toString(),
          style: const TextStyle(fontSize: 20, height: 1.4)),
      const SizedBox(height: 20),
      for (var i = 0; i < options.length; i++)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: InkWell(
            onTap: () => onSelect(i),
            borderRadius: BorderRadius.circular(15),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(17),
              decoration: BoxDecoration(
                color: selected == i ? const Color(0xFFF5C85B)
                    .withValues(alpha: 0.18) : Colors.white.withValues(alpha: 0.06),
                border: Border.all(color: selected == i
                    ? const Color(0xFFF5C85B) : Colors.white12),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Text(options[i].toString(),
                  style: const TextStyle(fontSize: 17)),
            ),
          ),
        ),
      if (selected != null) ...[
        const SizedBox(height: 13),
        Text(selected == correct ? 'Correct! ✓' :
            'Not quite. Correct: ${options[correct]}',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold,
                color: selected == correct ? const Color(0xFF70D6AB)
                    : const Color(0xFFFFB684))),
        const SizedBox(height: 6),
        Text(payload['explanation']?.toString() ?? '',
            style: const TextStyle(color: Colors.white70)),
      ],
    ]);
  }
}
