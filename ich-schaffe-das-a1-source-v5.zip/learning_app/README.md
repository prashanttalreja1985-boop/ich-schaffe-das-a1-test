# Ich schaffe das — A1 test app

A swipe-up German lesson app for iPhone. It has no login screen and does not call
an AI service while a learner uses it. Grammar cards come first, then vocabulary,
then quizzes. Swiping up at the current card completes it; quizzes require a
correct answer. The app reopens at the first unfinished card.

The home screen asks for a profile name, shows A1 as the available course, and
keeps A1+ Revision greyed out until that profile completes A1. A1+ is a separate
course and database book. The YouTube Reels section accepts comma-separated
interest keywords and has a per-profile toggle for sessions with or without
videos. When enabled, a session opens with three video cards, followed by one
video after every four learning cards.
Videos use YouTube's embedded player inside the card. They may repeat, and
some videos may be unavailable if a creator blocks embedding. This test catalog
is not the user's YouTube feed or a live keyword search. Neither YouTube login
nor an API key is used.

## Current content status

`assets/starter_content.json` contains an original expanded A1 course with
35 lessons, over 1,400 cards, and 400 vocabulary entries. It includes articles,
cases, present and perfect forms, modal and separable verbs, questions, time,
dates, and everyday situations. Repeated quizzes practice articles, meanings,
and verb forms. `tool/video_coverage_0emzztSmKjA.json` maps every minute of the
supplied A1 video to course lessons. Its auto-generated captions mishear some
German words; the course uses corrected, original examples. Listening and
speaking assessment are not yet in this text-based app.

`assets/a1_plus_content.json` is a separate A1+ revision course for use after the
35-lesson A1 course. It contains 14 original revision lessons aligned to the transcript
supplied for the 9.5-hour video. The transcript audit maps all 868 timestamp
markers to one of the 14 chapter lessons; the full transcript text is not bundled.
A1+ has 145 activities and 208 vocabulary entries, with separate database
content and progress and unique activity IDs. Lessons review and extend alphabet and pronunciation,
articles, pronouns and plurals, present/past/Perfekt verb forms, sentence order,
questions, adjective endings, modals, accusative and dative introductions,
prepositions, comparisons, demonstratives, shopping, imperative, health and
appointments. `tool/a1_plus_import.sql` imports this as a **draft** course into
the existing normalized Supabase course tables. The SQL has not been installed
in a live Supabase project.

This course is not a reproduction of *Netzwerk neu A1* and has not been checked
against the complete book. After the book's edition,
table of contents, and usable source material are supplied, build a coverage map
for every lesson, grammar point, vocabulary set, and exercise goal. Review that map
against the source before marking the book `published`. Use original explanations
and questions unless you have the rights to reproduce the book's text and layout.

## Content and progress

- Without Supabase configuration, the app loads the selected bundled course JSON
  and saves completed cards by profile and course on the device with SharedPreferences.
- With Supabase configuration, it reads a published book, ordered lessons, and
  ordered activities from database tables. It silently creates a Supabase anonymous
  user so progress and answer attempts are private to that installation. There is
  no account UI. Removing the app or its data can make anonymous progress
  unrecoverable; cross-device recovery needs a later account-linking feature.
- `supabase/schema.sql` creates the tables and row-level policies. Run it in a
  **separate Supabase project** for this app. Enable Anonymous Sign-Ins in Auth.
  Never put a service-role key in the app.
- A book import happens outside the app. Validate a reviewed JSON file and emit SQL:

  ```sh
  python tool/import_book.py assets/starter_content.json tool/starter_import.sql --publish
  ```

  Review and run the emitted SQL in the Supabase SQL editor. Omit `--publish`
  while the coverage audit is incomplete. The importer is idempotent for known
  books, lessons, and activities, but deletion of removed content is a separate
  editorial step. Existing learner progress uses stable activity slugs.

Edit `tool/build_a1_course.js`, then run `node tool/build_a1_course.js` and
`node tool/validate_course.js` to regenerate and check the bundled course. The
first eight starter cards retain their slugs, so earlier progress carries over.

## Build an IPA for Sideloadly

iOS builds require Xcode on macOS. The repository's
`.github/workflows/ich-schaffe-das-ipa.yml` runs the iOS build on a GitHub macOS
runner and uploads `Ich-schaffe-das-A1-unsigned.ipa`. Sideloadly can sign the IPA
with your Apple ID when installing it. Trigger the workflow manually from GitHub
Actions, or push changes under `learning_app/`.

For the bundled course, leave the workflow variables unset. For a published
Supabase course, set repository variables `LEARNING_SUPABASE_URL` and
`LEARNING_SUPABASE_PUBLISHABLE_KEY`, and publish the course under slug
`netzwerk-neu-a1`. Then run the workflow and download its artifact. The build
embeds only the public project URL and publishable key.

Locally on a Mac:

```sh
flutter pub get
flutter analyze
flutter test
flutter build ios --release --no-codesign
mkdir -p build/ipa/Payload
cp -R build/ios/iphoneos/Runner.app build/ipa/Payload/
(cd build/ipa && zip -qr Ich-schaffe-das-A1-unsigned.ipa Payload)
```

This is a testing package, not an App Store signed distribution. The iOS bundle ID
is `de.ichschaffedas.a1` and the display name is **Ich schaffe das**.
