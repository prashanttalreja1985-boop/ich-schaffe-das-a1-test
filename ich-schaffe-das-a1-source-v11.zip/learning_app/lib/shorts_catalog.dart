import 'dart:convert';

import 'package:flutter/services.dart';

class YoutubeShort {
  const YoutubeShort(this.id, this.title, this.channel, this.tags);

  final String id;
  final String title;
  final String channel;
  final List<String> tags;

  factory YoutubeShort.fromJson(Map<String, dynamic> json) => YoutubeShort(
        json['id'] as String,
        json['title'] as String,
        json['channel'] as String,
        (json['tags'] as List<dynamic>).cast<String>(),
      );
}

List<String> parseInterestKeywords(String value) => value
    .split(',')
    .map((keyword) => keyword.trim().toLowerCase())
    .where((keyword) => keyword.isNotEmpty)
    .toSet()
    .toList();

List<YoutubeShort> rankShorts(
    List<YoutubeShort> catalog, List<String> keywords) {
  if (keywords.isEmpty) return const [];

  final scored = catalog.asMap().entries.map((entry) {
    final video = entry.value;
    final searchable = [...video.tags, video.title];
    final score = keywords.where((keyword) => searchable.any(
        (value) => _containsInterest(value, keyword))).length;
    return (video: video, score: score, originalIndex: entry.key);
  }).where((entry) => entry.score > 0).toList();
  scored.sort((a, b) {
    final byScore = b.score.compareTo(a.score);
    return byScore != 0 ? byScore : a.originalIndex.compareTo(b.originalIndex);
  });
  return scored.map((entry) => entry.video).toList();
}

bool _containsInterest(String text, String keyword) {
  final escaped = RegExp.escape(keyword.trim());
  if (escaped.isEmpty) return false;
  return RegExp('(^|[^a-z0-9])$escaped([^a-z0-9]|\$)',
          caseSensitive: false)
      .hasMatch(text);
}

Future<List<YoutubeShort>> loadShortsCatalog(List<String> keywords) async {
  final raw = await rootBundle.loadString('assets/shorts_catalog.json');
  final catalog = (jsonDecode(raw) as List<dynamic>)
      .map((item) => YoutubeShort.fromJson(item as Map<String, dynamic>))
      .toList();
  return rankShorts(catalog, keywords);
}
