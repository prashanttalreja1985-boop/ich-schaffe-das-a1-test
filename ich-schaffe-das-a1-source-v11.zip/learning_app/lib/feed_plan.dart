import 'dart:math';

import 'mini_games.dart';

/// A feed item is either a course activity, a YouTube Short, or a mini-game.
class FeedSlot {
  const FeedSlot.activity(this.activityIndex)
      : shortIndex = null,
        game = null;
  const FeedSlot.short(this.shortIndex)
      : activityIndex = null,
        game = null;
  const FeedSlot.game(this.game)
      : activityIndex = null,
        shortIndex = null;

  final int? activityIndex;
  final int? shortIndex;
  final MiniGameKind? game;
  bool get isShort => shortIndex != null;
  bool get isGame => game != null;
  bool get isActivity => activityIndex != null;
}

/// Starts with three break cards and adds another after every four learning
/// activities. When both modes are enabled, each break randomly picks one.
List<FeedSlot> planSessionFeed({
  required int firstUnfinishedActivity,
  required int activityCount,
  required int availableShorts,
  List<int> lessonNumbers = const [],
  bool reelsEnabled = true,
  bool gamesEnabled = false,
  int randomSeed = 0,
}) {
  if (firstUnfinishedActivity < 0 ||
      activityCount < firstUnfinishedActivity ||
      availableShorts < 0) {
    throw ArgumentError('Invalid session feed bounds');
  }
  final canShowReels = reelsEnabled && availableShorts > 0;
  if (!canShowReels && !gamesEnabled) {
    return [
      for (var activity = firstUnfinishedActivity;
          activity < activityCount;
          activity++)
        FeedSlot.activity(activity),
    ];
  }

  final random = Random(randomSeed);
  final slots = <FeedSlot>[];
  var nextShort = 0;
  final gamesByLesson = <int, int>{};

  void addGame(int? lessonNumber) {
    slots.add(FeedSlot.game(
        MiniGameKind.values[random.nextInt(MiniGameKind.values.length)]));
    if (lessonNumber != null) {
      gamesByLesson.update(lessonNumber, (count) => count + 1,
          ifAbsent: () => 1);
    }
  }

  void addBreak({int? lessonNumber, bool requireGame = false}) {
    if (canShowReels && gamesEnabled) {
      if (!requireGame && random.nextBool()) {
        slots.add(FeedSlot.short(nextShort++ % availableShorts));
      } else {
        addGame(lessonNumber);
      }
    } else if (canShowReels) {
      slots.add(FeedSlot.short(nextShort++ % availableShorts));
    } else {
      addGame(lessonNumber);
    }
  }

  // Preserve the three-Short opening when video is the only mode. With both
  // modes on, these opening breaks join the same randomized mix as later ones.
  if (canShowReels) {
    for (var i = 0; i < 3; i++) {
      if (gamesEnabled && i > 0 && random.nextBool()) {
        addGame(lessonNumbers.isEmpty ? null : lessonNumbers[firstUnfinishedActivity]);
      } else {
        slots.add(FeedSlot.short(nextShort++ % availableShorts));
      }
    }
  }
  var cardsSinceBreak = 0;
  final remainingByLesson = <int, int>{};
  if (lessonNumbers.length == activityCount) {
    for (var i = firstUnfinishedActivity; i < activityCount; i++) {
      remainingByLesson.update(lessonNumbers[i], (count) => count + 1,
          ifAbsent: () => 1);
    }
  }
  final seenByLesson = <int, int>{};
  int? previousLesson;
  for (var activity = firstUnfinishedActivity;
      activity < activityCount;
      activity++) {
    final lesson = lessonNumbers.length == activityCount
        ? lessonNumbers[activity]
        : null;
    if (gamesEnabled && lesson != null && previousLesson != lesson) {
      cardsSinceBreak = 0;
      previousLesson = lesson;
    }
    if (gamesEnabled && lesson != null) {
      final seen = seenByLesson[lesson] ?? 0;
      final lessonSize = remainingByLesson[lesson] ?? 1;
      final priorGames = gamesByLesson[lesson] ?? 0;
      if (priorGames < 2 &&
          (seen == (lessonSize / 3).ceil() ||
              (priorGames == 1 && seen == (lessonSize * 2 / 3).ceil()))) {
        addBreak(lessonNumber: lesson, requireGame: true);
      }
    }
    slots.add(FeedSlot.activity(activity));
    if (lesson != null) seenByLesson.update(lesson, (count) => count + 1,
        ifAbsent: () => 1);
    cardsSinceBreak++;
    final lessonEnds = activity == activityCount - 1 ||
        (lesson != null && lessonNumbers[activity + 1] != lesson);
    if (gamesEnabled && lessonEnds && lesson != null) {
      while ((gamesByLesson[lesson] ?? 0) < 2) {
        addBreak(lessonNumber: lesson, requireGame: true);
      }
    }
    if (canShowReels && cardsSinceBreak == 4 && !lessonEnds) {
      addBreak(lessonNumber: lesson);
      cardsSinceBreak = 0;
    }
  }
  return slots;
}
