import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/feed_plan.dart';

void main() {
  test('keeps the three Short opening and then one after four cards', () {
    final feed = planSessionFeed(
        firstUnfinishedActivity: 7, activityCount: 16, availableShorts: 10,
        reelsEnabled: true, gamesEnabled: false);
    expect(feed.take(3).map((slot) => slot.shortIndex), [0, 1, 2]);
    expect(feed.where((slot) => slot.isActivity)
        .map((slot) => slot.activityIndex), [7, 8, 9, 10, 11, 12, 13, 14, 15]);
    expect(feed.where((slot) => slot.isShort).map((slot) => slot.shortIndex),
        [0, 1, 2, 3, 4]);
    expect(feed[7].shortIndex, 3);
    expect(feed[12].shortIndex, 4);
  });

  test('adds two game breaks per lesson and no video when games are solo', () {
    final lessons = [for (var i = 0; i < 12; i++) 1,
      for (var i = 0; i < 8; i++) 2];
    final feed = planSessionFeed(firstUnfinishedActivity: 0,
        activityCount: lessons.length, availableShorts: 0,
        lessonNumbers: lessons, reelsEnabled: false, gamesEnabled: true);
    final games = feed.where((slot) => slot.isGame).toList();
    expect(games, hasLength(4));
    expect(feed.where((slot) => slot.isShort), isEmpty);
    expect(feed.where((slot) => slot.isActivity), hasLength(20));
  });

  test('mixes games and Shorts in randomized breaks while retaining lesson games', () {
    final lessons = List<int>.filled(16, 1);
    final feed = planSessionFeed(firstUnfinishedActivity: 0,
        activityCount: lessons.length, availableShorts: 30,
        lessonNumbers: lessons, reelsEnabled: true, gamesEnabled: true,
        randomSeed: 1);
    expect(feed.where((slot) => slot.isGame).length, greaterThanOrEqualTo(2));
    expect(feed.where((slot) => slot.isShort), isNotEmpty);
    expect(feed.where((slot) => slot.isActivity), hasLength(16));
    expect(feed.where((slot) => slot.isShort || slot.isGame).length,
        greaterThan(2));
  });

  test('keeps lessons usable without video or game access', () {
    final feed = planSessionFeed(firstUnfinishedActivity: 2,
        activityCount: 6, availableShorts: 0,
        reelsEnabled: false, gamesEnabled: false);
    expect(feed.map((slot) => slot.activityIndex), [2, 3, 4, 5]);
  });
}
