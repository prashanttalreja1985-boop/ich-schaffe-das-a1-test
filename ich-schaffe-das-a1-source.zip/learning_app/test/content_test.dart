import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ich_schaffe_das/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('starter curriculum has ordered learning phases and valid quiz answers',
      () async {
    final raw = await rootBundle.loadString('assets/starter_content.json');
    final curriculum = Curriculum.fromJson(jsonDecode(raw));
    expect(curriculum.activities, isNotEmpty);
    final lessonNumbers = curriculum.activities.map((a) => a.lessonNumber).toList();
    expect(lessonNumbers, orderedEquals([...lessonNumbers]..sort()));
    for (final activity in curriculum.activities.where((a) => a.kind == 'quiz')) {
      final options = activity.payload['options'] as List<dynamic>;
      final answer = activity.payload['answer'] as int;
      expect(answer, inInclusiveRange(0, options.length - 1));
    }
  });
}
