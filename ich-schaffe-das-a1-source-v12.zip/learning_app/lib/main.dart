import 'dart:convert';
import 'dart:math' show max, min;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

import 'feed_plan.dart';
import 'lexicon.dart';
import 'mini_games.dart';
import 'shorts_catalog.dart';

const _supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const _supabaseKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
const _starterReelKeywords = 'travel, football';
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (_supabaseUrl.isNotEmpty && _supabaseKey.isNotEmpty) {
    await Supabase.initialize(url: _supabaseUrl, publishableKey: _supabaseKey);
  }
  runApp(const LearningApp());
}

class Activity {
  const Activity({
    required this.slug,
    required this.kind,
    required this.title,
    required this.lessonTitle,
    required this.lessonNumber,
    required this.cardNumber,
    required this.lessonCardCount,
    required this.payload,
  });

  final String slug;
  final String kind;
  final String title;
  final String lessonTitle;
  final int lessonNumber;
  final int cardNumber;
  final int lessonCardCount;
  final Map<String, dynamic> payload;

  factory Activity.fromJson(Map<String, dynamic> json, String lessonTitle,
      int lessonNumber, int cardNumber, int lessonCardCount) {
    return Activity(
      slug: json['slug'] as String,
      kind: json['kind'] as String,
      title: json['title'] as String,
      lessonTitle: lessonTitle,
      lessonNumber: lessonNumber,
      cardNumber: cardNumber,
      lessonCardCount: lessonCardCount,
      payload: json,
    );
  }
}

class Curriculum {
  const Curriculum(this.title, this.edition, this.slug, this.activities);

  final String title;
  final String edition;
  final String slug;
  final List<Activity> activities;

  factory Curriculum.fromJson(Map<String, dynamic> data) {
    final book = data['book'] as Map<String, dynamic>;
    final activities = <Activity>[];
    final lessons = (data['lessons'] as List<dynamic>).cast<Map<String, dynamic>>()
      ..sort((a, b) => (a['number'] as int).compareTo(b['number'] as int));
    for (final lesson in lessons) {
      final row = lesson as Map<String, dynamic>;
      final lessonActivities = row['activities'] as List<dynamic>;
      for (var index = 0; index < lessonActivities.length; index++) {
        activities.add(Activity.fromJson(
          lessonActivities[index] as Map<String, dynamic>,
          row['title'] as String,
          row['number'] as int,
          index + 1,
          lessonActivities.length,
        ));
      }
    }
    return Curriculum(
      book['title'] as String,
      book['edition'] as String,
      book['slug'] as String,
      activities,
    );
  }
}

class LearningStore {
  LearningStore(this.courseAsset, this.bookSlug, this.profileKey);

  final String courseAsset;
  final String bookSlug;
  final String profileKey;

  SupabaseClient? get _client =>
      _supabaseUrl.isEmpty || _supabaseKey.isEmpty ? null : Supabase.instance.client;

  Future<Curriculum> load() async {
    final sample = await rootBundle.loadString(courseAsset);
    final fallback = Curriculum.fromJson(
        jsonDecode(sample) as Map<String, dynamic>);
    final client = _client;
    if (client == null) return fallback;
    try {
      if (client.auth.currentUser == null) {
        try {
          await client.auth.signInAnonymously();
        } catch (_) {
          // Public course reads and local-only profile progress work without
          // anonymous sign-in being enabled in the Supabase project.
        }
      }
      final book = await client
          .from('learning_books')
          .select('id,slug,title,edition,level')
          .eq('slug', bookSlug)
          .single();
      final lessons = await client
          .from('learning_lessons')
          .select('id,slug,number,title,goal')
          .eq('book_id', book['id'])
          .order('number');
      final lessonIds = lessons.map((lesson) => lesson['id']).toList();
      final rows = <Map<String, dynamic>>[];
      for (var offset = 0;; offset += 1000) {
        final page = await client
            .from('learning_activities')
            .select('lesson_id,slug,kind,title,payload,sequence_number')
            .inFilter('lesson_id', lessonIds)
            .order('lesson_id')
            .order('sequence_number')
            .range(offset, offset + 999);
        rows.addAll(page);
        if (page.length < 1000) break;
      }
      final lessonData = lessons.map((lesson) {
        final activities = rows
            .where((row) => row['lesson_id'] == lesson['id'])
            .map((row) => {
                  ...(row['payload'] as Map<String, dynamic>),
                  'slug': row['slug'],
                  'kind': row['kind'],
                  'title': row['title'],
                })
            .toList();
        return {...lesson, 'activities': activities};
      }).toList();
      return Curriculum.fromJson({'book': book, 'lessons': lessonData});
    } catch (_) {
      return fallback;
    }
  }

  Future<Lexicon> loadLexicon() async {
    final bundled = jsonDecode(await rootBundle.loadString('assets/lexicon.json'))
        as Map<String, dynamic>;
    final fallback = Lexicon.fromJson(bundled, bookSlug);
    final client = _client;
    if (client == null) return fallback;
    try {
      final rows = await client
          .from('learning_lexicon')
          .select('book_slug,lemma,word_type,meaning_en,article,forms')
          .eq('book_slug', bookSlug);
      if (rows.isEmpty) return fallback;
      return Lexicon(rows.map((row) => Lexeme.fromJson(row)));
    } catch (_) {
      // A bundled lexicon keeps the course usable before the optional table is
      // installed or published in Supabase.
      return fallback;
    }
  }

  Future<Set<String>> completed(Curriculum curriculum) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'done:$profileKey:${curriculum.slug}';
    final done = prefs.getStringList(key)?.toSet() ?? <String>{};
    final resetReady = await syncPendingProgressReset();
    final client = _client;
    if (resetReady && client != null && client.auth.currentUser != null) {
      try {
        final userId = client.auth.currentUser!.id;
        final rows = await client
            .from('learner_activity_progress')
            .select('activity_slug')
            .eq('user_id', userId)
            .eq('profile_key', profileKey)
            .eq('book_slug', curriculum.slug);
        final remoteDone = rows.map((row) => row['activity_slug'] as String).toSet();
        done.addAll(remoteDone);
        await prefs.setStringList(key, done.toList());
        final validSlugs = curriculum.activities.map((a) => a.slug).toSet();
        final pending = done.intersection(validSlugs).difference(remoteDone);
        if (pending.isNotEmpty) {
          await client.from('learner_activity_progress').upsert([
            for (final slug in pending)
              {
                'user_id': userId,
                'profile_key': profileKey,
                'book_slug': curriculum.slug,
                'activity_slug': slug,
              }
          ], onConflict: 'user_id,profile_key,book_slug,activity_slug');
        }
      } catch (_) {
        // Keep local progress available while the database is offline.
      }
    }
    return done;
  }

  Future<Map<MiniGameKind, int>> gameProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final progress = <MiniGameKind, int>{
      for (final kind in MiniGameKind.values)
        kind: (prefs.getInt('game-level:$profileKey:${kind.name}') ?? 1)
            .clamp(1, 20).toInt(),
    };
    if (!await syncPendingProgressReset()) return progress;
    final client = _client;
    final user = client?.auth.currentUser;
    if (client == null || user == null) return progress;
    try {
      final rows = await client.from('learner_game_progress')
          .select('game_slug,highest_level')
          .eq('user_id', user.id).eq('profile_key', profileKey);
      for (final row in rows) {
        final matches = MiniGameKind.values
            .where((value) => value.name == row['game_slug']);
        if (matches.isEmpty) continue;
        final kind = matches.first;
        final level = (row['highest_level'] as int).clamp(1, 20).toInt();
        progress[kind] = max(progress[kind] ?? 1, level).toInt();
        await prefs.setInt('game-level:$profileKey:${kind.name}', progress[kind]!);
      }
      for (final kind in MiniGameKind.values) {
        final level = progress[kind] ?? 1;
        await client.from('learner_game_progress').upsert({
          'user_id': user.id,
          'profile_key': profileKey,
          'game_slug': kind.name,
          'highest_level': level,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        }, onConflict: 'user_id,profile_key,game_slug');
      }
    } catch (_) {
      // Local game progress remains usable when the network or table is absent.
    }
    return progress;
  }

  Future<int> saveGameProgress(MiniGameKind kind, int unlockedLevel) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'game-level:$profileKey:${kind.name}';
    final level = max((prefs.getInt(key) ?? 1).clamp(1, 20).toInt(),
        unlockedLevel.clamp(1, 20).toInt()).toInt();
    await prefs.setInt(key, level);
    final client = _client;
    final user = client?.auth.currentUser;
    if (client != null && user != null) {
      try {
        await client.from('learner_game_progress').upsert({
          'user_id': user.id,
          'profile_key': profileKey,
          'game_slug': kind.name,
          'highest_level': level,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        }, onConflict: 'user_id,profile_key,game_slug');
      } catch (_) {
        // A later session retries syncing this level from local preferences.
      }
    }
    return level;
  }

  Future<bool> resetProfileProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('reset-pending:$profileKey', true);
    final client = _client;
    final user = client?.auth.currentUser;
    var synced = false;
    if (client != null && user != null) {
      try {
        await _deleteRemoteProgress(client, user.id);
        await prefs.remove('reset-pending:$profileKey');
        synced = true;
      } catch (_) {
        // The reset tombstone retries cloud deletion when this profile returns.
      }
    }
    for (final key in prefs.getKeys().where((key) =>
        key.startsWith('done:$profileKey:') ||
        key.startsWith('answers:$profileKey:') ||
        key.startsWith('game-level:$profileKey:'))) {
      await prefs.remove(key);
    }
    if (prefs.getString('legacy_progress_owner')?.toLowerCase() == profileKey) {
      await prefs.remove('done:original-a1-starter');
      await prefs.setString('legacy_progress_owner', profileKey);
    }
    return synced;
  }

  Future<bool> syncPendingProgressReset() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool('reset-pending:$profileKey') != true) return true;
    final client = _client;
    final user = client?.auth.currentUser;
    if (client == null || user == null) return false;
    try {
      await _deleteRemoteProgress(client, user.id);
      await prefs.remove('reset-pending:$profileKey');
      return true;
    } catch (_) {
      // Retry the tombstone at the next profile session.
      return false;
    }
  }

  Future<void> _deleteRemoteProgress(SupabaseClient client, String userId) async {
    for (final table in [
      'learner_activity_progress',
      'learner_answers',
      'learner_game_progress',
    ]) {
      await client.from(table).delete()
          .eq('user_id', userId)
          .eq('profile_key', profileKey);
    }
  }

  Future<Set<String>> flagged(Curriculum curriculum) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs
            .getStringList('flagged:$profileKey:${curriculum.slug}')
            ?.toSet() ??
        <String>{};
  }

  Future<bool> flag(Curriculum curriculum, Activity activity) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'flagged:$profileKey:${curriculum.slug}';
    final local = prefs.getStringList(key) ?? <String>[];
    if (!local.contains(activity.slug)) {
      local.add(activity.slug);
      await prefs.setStringList(key, local);
    }
    final client = _client;
    if (client == null) return false;
    try {
      await client.from('learning_content_flags').upsert({
        'book_slug': curriculum.slug,
        'activity_slug': activity.slug,
      }, onConflict: 'book_slug,activity_slug', ignoreDuplicates: true);
      return true;
    } catch (_) {
      // Keep the local flag if network access or the review table is unavailable.
      return false;
    }
  }

  Future<bool> complete(Curriculum curriculum, Activity activity,
      Set<String> done, int? selectedAnswer) async {
    final client = _client;
    final prefs = await SharedPreferences.getInstance();
    if (selectedAnswer != null) {
      final key = 'answers:$profileKey:${curriculum.slug}';
      final attempts = prefs.getStringList(key) ?? <String>[];
      attempts.add(jsonEncode({
        'activity_slug': activity.slug,
        'selected_answer': selectedAnswer,
        'is_correct': selectedAnswer == activity.payload['answer'],
        'answered_at': DateTime.now().toUtc().toIso8601String(),
      }));
      await prefs.setStringList(key, attempts);
    }
    if (selectedAnswer != null && client != null &&
        client.auth.currentUser != null) {
      try {
        await client.from('learner_answers').insert({
          'user_id': client.auth.currentUser!.id,
          'profile_key': profileKey,
          'book_slug': curriculum.slug,
          'activity_slug': activity.slug,
          'selected_answer': selectedAnswer,
          'is_correct': selectedAnswer == activity.payload['answer'],
        });
      } catch (_) {
        // The answer attempt is already saved on device.
      }
    }
    if (selectedAnswer != null && selectedAnswer != activity.payload['answer']) {
      return false;
    }
    done.add(activity.slug);
    await prefs.setStringList('done:$profileKey:${curriculum.slug}', done.toList());
    if (client != null && client.auth.currentUser != null) {
      try {
        final userId = client.auth.currentUser!.id;
        await client.from('learner_activity_progress').upsert({
          'user_id': userId,
          'profile_key': profileKey,
          'book_slug': curriculum.slug,
          'activity_slug': activity.slug,
          'completed_at': DateTime.now().toUtc().toIso8601String(),
        }, onConflict: 'user_id,profile_key,book_slug,activity_slug');
      } catch (_) {
        // A later session retries syncing local completion records.
      }
    }
    return true;
  }
}

class LearningApp extends StatelessWidget {
  const LearningApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ich schaffe das',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF10182A),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFF5C85B),
          brightness: Brightness.dark,
        ),
        textTheme: ThemeData.dark().textTheme.apply(fontFamily: 'Arial'),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _name = TextEditingController();
  final _keywords = TextEditingController();
  List<String> _profiles = [];
  String? _message;
  bool _reelsEnabled = true;
  bool _gamesEnabled = true;
  bool _a1Complete = false;
  int _progressLookup = 0;
  int? _a1ActivityCount;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    final prefs = await SharedPreferences.getInstance();
    final last = prefs.getString('last_profile') ?? '';
    await _initializeBreakModes(prefs, last);
    final savedKeywords = prefs.getString('keywords:${last.toLowerCase()}');
    if (!mounted) return;
    setState(() {
      _profiles = prefs.getStringList('profiles') ?? [];
      _name.text = last;
      _keywords.text = _interestsOrStarter(savedKeywords);
      _reelsEnabled = prefs.getBool('reels:${last.toLowerCase()}') ?? true;
      _gamesEnabled = prefs.getBool('games:${last.toLowerCase()}') ?? true;
    });
    await _refreshA1Completion(last);
  }

  Future<void> _initializeBreakModes(
      SharedPreferences prefs, String lastProfile) async {
    if (prefs.getBool('break_modes_initialized_v2') == true) return;
    final profiles = <String>{
      ...(prefs.getStringList('profiles') ?? []),
      if (lastProfile.trim().isNotEmpty) lastProfile,
    };
    for (final profile in profiles) {
      final key = profile.trim().toLowerCase();
      if (key.isEmpty) continue;
      final keywords = prefs.getString('keywords:$key');
      if (_interestsOrStarter(keywords) == _starterReelKeywords) {
        await prefs.setString('keywords:$key', _starterReelKeywords);
      }
      // The previous defaults left games off and the keyword field empty,
      // which made every session look as if break cards had disappeared.
      await prefs.setBool('reels:$key', true);
      await prefs.setBool('games:$key', true);
    }
    await prefs.setBool('break_modes_initialized_v2', true);
  }

  Future<void> _refreshA1Completion(String profile) async {
    final lookup = ++_progressLookup;
    final key = profile.trim().toLowerCase();
    if (key.isEmpty) {
      if (mounted && lookup == _progressLookup) {
        setState(() => _a1Complete = false);
      }
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    var activityCount = _a1ActivityCount;
    if (activityCount == null) {
      final raw = await rootBundle.loadString('assets/starter_content.json');
      activityCount = Curriculum.fromJson(
          jsonDecode(raw) as Map<String, dynamic>).activities.length;
      _a1ActivityCount = activityCount;
    }
    final done = prefs.getStringList('done:$key:original-a1-starter') ?? <String>[];
    if (mounted && lookup == _progressLookup) {
      setState(() => _a1Complete = done.length >= activityCount!);
    }
  }

  Future<void> _chooseProfile(String profile) async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _name.text = profile;
      _keywords.text = _interestsOrStarter(
          prefs.getString('keywords:${profile.toLowerCase()}'));
      _reelsEnabled = prefs.getBool('reels:${profile.toLowerCase()}') ?? true;
      _gamesEnabled = prefs.getBool('games:${profile.toLowerCase()}') ?? true;
      _message = null;
    });
    await _refreshA1Completion(profile);
  }

  Future<void> _resetSelectedProfile() async {
    final selectedProfiles = _profiles.where((profile) =>
        profile.toLowerCase() == _name.text.trim().toLowerCase()).toList();
    if (selectedProfiles.isEmpty) return;
    final profile = selectedProfiles.first;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Reset progress for $profile?'),
        content: const Text(
          'This clears completed lessons, quiz history, and game levels for '
          'this profile on this device and in Supabase. Your profile and settings stay saved.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('Reset progress')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final store = LearningStore('', 'original-a1-starter', profile.toLowerCase());
    final synced = await store.resetProfileProgress();
    if (!mounted) return;
    await _refreshA1Completion(profile);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(synced
          ? 'Progress reset for $profile.'
          : 'Device progress reset. Supabase will sync the reset when available.'),
    ));
    setState(() {});
  }

  String _interestsOrStarter(String? value) => value == null ||
          value.trim().isEmpty || value.trim().toLowerCase() == 'german'
      ? _starterReelKeywords
      : value;

  Future<void> _start(String asset, String bookSlug) async {
    final displayName = _name.text.trim();
    if (displayName.isEmpty) {
      setState(() => _message = 'Enter a profile name to save your place.');
      return;
    }
    final profileKey = displayName.toLowerCase();
    final prefs = await SharedPreferences.getInstance();
    final profiles = prefs.getStringList('profiles') ?? [];
    final isNewProfile =
        !profiles.any((name) => name.trim().toLowerCase() == profileKey);
    if (isNewProfile) {
      // Remove orphaned local progress left by an earlier profile with the
      // same normalized key, so a genuinely new profile always starts at A1/1.
      for (final key in prefs.getKeys().where((key) =>
          key.startsWith('done:$profileKey:') ||
          key.startsWith('answers:$profileKey:') ||
          key.startsWith('game-level:$profileKey:'))) {
        await prefs.remove(key);
      }
    }
    final priorProfile = prefs.getString('last_profile')?.trim().toLowerCase();
    final legacyOwner = prefs.getString('legacy_progress_owner');
    final legacyDone = prefs.getStringList('done:original-a1-starter');
    if (legacyOwner == null && legacyDone != null) {
      if (priorProfile == profileKey) {
        await prefs.setStringList(
            'done:$profileKey:original-a1-starter', legacyDone);
        await prefs.setString('legacy_progress_owner', profileKey);
      } else {
        // Unscoped progress cannot be attributed to a newly created profile.
        await prefs.setString('legacy_progress_owner', '__unassigned__');
      }
    }
    if (!profiles.any((name) => name.toLowerCase() == profileKey)) {
      profiles.add(displayName);
      await prefs.setStringList('profiles', profiles);
    }
    await prefs.setString('last_profile', displayName);
    final interests = _interestsOrStarter(_keywords.text);
    _keywords.text = interests;
    await prefs.setString('keywords:$profileKey', interests);
    await prefs.setBool('reels:$profileKey', _reelsEnabled);
    await prefs.setBool('games:$profileKey', _gamesEnabled);
    if (!mounted) return;
    setState(() { _profiles = profiles; _message = null; });
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => LearningScreen(
        courseAsset: asset,
        bookSlug: bookSlug,
        profileKey: profileKey,
        profileName: displayName,
        keywords: parseInterestKeywords(_keywords.text),
        includeReels: _reelsEnabled,
        includeGames: _gamesEnabled,
      ),
    ));
    await _refreshA1Completion(displayName);
  }

  @override
  void dispose() {
    _name.dispose();
    _keywords.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(24), children: [
      const SizedBox(height: 20),
      const Text('Ich schaffe das', style: TextStyle(
          fontSize: 34, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      const Text('Learn a little. Keep going tomorrow.',
          style: TextStyle(color: Colors.white70, fontSize: 16)),
      const SizedBox(height: 32),
      TextField(controller: _name, textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Profile name',
              hintText: 'Enter your name the first time', border: OutlineInputBorder()),
          onChanged: (value) {
            setState(() {});
            _refreshA1Completion(value);
          }),
      if (_profiles.isNotEmpty) ...[
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: _profiles.map((profile) =>
          ActionChip(label: Text(profile), onPressed: () => _chooseProfile(profile))
        ).toList()),
        if (_profiles.any((profile) =>
            profile.toLowerCase() == _name.text.trim().toLowerCase())) ...[
          const SizedBox(height: 8),
          Align(alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: _resetSelectedProfile,
              icon: const Icon(Icons.restart_alt_rounded),
              label: const Text('Reset selected profile progress'),
            ),
          ),
        ],
      ],
      const SizedBox(height: 18),
      const SizedBox(height: 10),
      _HomeSection(
        title: 'YouTube', icon: Icons.smart_display_rounded,
        subtitle: 'Shorts matched to your interests',
        child: Column(children: [
          TextField(controller: _keywords,
              decoration: const InputDecoration(
                labelText: 'Reels keywords',
                hintText: 'Travel, football, cooking',
                helperText: 'Only Shorts matching these interests are shown.',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) async {
                final key = _name.text.trim().toLowerCase();
                if (key.isNotEmpty) {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setString('keywords:$key', value);
                }
              }),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Include YouTube Shorts'),
            subtitle: Text(_reelsEnabled
                ? 'Matching Shorts can appear in session breaks.'
                : 'Shorts are off for this profile.'),
            value: _reelsEnabled,
            onChanged: (enabled) async {
              setState(() => _reelsEnabled = enabled);
              final key = _name.text.trim().toLowerCase();
              if (key.isNotEmpty) {
                final prefs = await SharedPreferences.getInstance();
                await prefs.setBool('reels:$key', enabled);
              }
            },
          ),
        ]),
      ),
      const SizedBox(height: 14),
      _HomeSection(
        title: 'Games', icon: Icons.sports_esports_rounded,
        subtitle: 'Quick puzzles between lesson cards',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _GamePreview(kind: MiniGameKind.planks),
          const SizedBox(height: 8),
          _GamePreview(kind: MiniGameKind.territory),
          const SizedBox(height: 6),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Include games'),
            subtitle: Text(_gamesEnabled
                ? 'At least two game levels appear in each lesson.'
                : 'Games are off for this profile.'),
            value: _gamesEnabled,
            onChanged: (enabled) async {
              setState(() => _gamesEnabled = enabled);
              final key = _name.text.trim().toLowerCase();
              if (key.isNotEmpty) {
                final prefs = await SharedPreferences.getInstance();
                await prefs.setBool('games:$key', enabled);
              }
            },
          ),
        ]),
      ),
      if (_message != null) ...[
        const SizedBox(height: 12),
        Text(_message!, style: const TextStyle(color: Colors.orangeAccent)),
      ],
      const SizedBox(height: 30),
      const Text('Choose a course', style: TextStyle(
          fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 14),
      _CourseTile(title: 'A1', subtitle: '10 lessons · start or continue',
          icon: Icons.auto_stories_rounded,
          enabled: _name.text.trim().isNotEmpty,
          onTap: () => _start('assets/starter_content.json', 'original-a1-starter')),
      const SizedBox(height: 14),
      _CourseTile(title: 'A1+ Revision',
          icon: _a1Complete ? Icons.add_circle_outline_rounded : Icons.lock_outline_rounded,
          enabled: _a1Complete,
          subtitle: _a1Complete
              ? '14 revision lessons · unlocked after A1'
              : 'Locked · complete A1 to unlock',
          onTap: () => _start('assets/a1_plus_content.json', 'ich-schaffe-das-a1-plus')),
      const SizedBox(height: 20),
      const Text('Progress is saved on this device for each profile and course. '
          'New profiles start with travel and football interests plus both break modes on. '
          'You can change the keywords or switch either mode off above.',
          style: TextStyle(color: Colors.white54, height: 1.5)),
    ])),
  );
}

class _HomeSection extends StatelessWidget {
  const _HomeSection({required this.title, required this.icon,
      required this.subtitle, required this.child});
  final String title;
  final IconData icon;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(color: const Color(0xFF1D2940),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white10)),
    child: Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        leading: Icon(icon, color: const Color(0xFFF5C85B)),
        title: Text(title, style: const TextStyle(fontSize: 21,
            fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.white60)),
        tilePadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
        childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
        children: [child],
      ),
    ),
  );
}

class _GamePreview extends StatelessWidget {
  const _GamePreview({required this.kind});
  final MiniGameKind kind;

  @override
  Widget build(BuildContext context) => Row(children: [
    Icon(kind.icon, color: Colors.white70, size: 19),
    const SizedBox(width: 9),
    Expanded(child: Text(kind.title,
        style: const TextStyle(fontWeight: FontWeight.w700))),
    const Text('20 levels', style: TextStyle(color: Colors.white54)),
  ]);
}

class _CourseTile extends StatelessWidget {
  const _CourseTile({required this.title, required this.subtitle,
      required this.icon, required this.onTap, this.enabled = true});
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final bool enabled;

  @override
  Widget build(BuildContext context) => Material(
    color: enabled ? const Color(0xFF1D2940) : const Color(0xFF171F30),
    borderRadius: BorderRadius.circular(24),
    child: InkWell(borderRadius: BorderRadius.circular(24),
      onTap: enabled ? onTap : null,
      child: Padding(padding: const EdgeInsets.all(22), child: Row(children: [
        Icon(icon, color: enabled ? const Color(0xFFF5C85B) : Colors.white30, size: 30),
        const SizedBox(width: 18),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          children: [Text(title, style: TextStyle(fontSize: 24,
              fontWeight: FontWeight.w800,
              color: enabled ? Colors.white : Colors.white38)), const SizedBox(height: 5),
            Text(subtitle, style: TextStyle(color: enabled ? Colors.white70 : Colors.white38))])),
        Icon(enabled ? Icons.chevron_right_rounded : Icons.lock_outline_rounded,
            color: enabled ? Colors.white70 : Colors.white30),
      ])),
    ),
  );
}

class LearningScreen extends StatefulWidget {
  const LearningScreen({super.key, required this.courseAsset,
      required this.bookSlug, required this.profileKey,
      required this.profileName, required this.keywords,
      required this.includeReels, required this.includeGames});

  final String courseAsset;
  final String bookSlug;
  final String profileKey;
  final String profileName;
  final List<String> keywords;
  final bool includeReels;
  final bool includeGames;

  @override
  State<LearningScreen> createState() => _LearningScreenState();
}

class _LearningScreenState extends State<LearningScreen> {
  late final LearningStore _store;
  final _controller = PageController();
  Curriculum? _curriculum;
  Lexicon? _lexicon;
  List<YoutubeShort> _shorts = [];
  List<FeedSlot> _feed = [];
  final Map<MiniGameKind, int> _gameProgress = {};
  Set<String> _done = {};
  Set<String> _flagged = {};
  int _index = 0;
  int _feedIndex = 0;
  int? _selected;
  bool _busy = false;
  double _upwardOverscroll = 0;
  Offset? _swipeStart;
  String? _error;

  @override
  void initState() {
    super.initState();
    _store = LearningStore(
        widget.courseAsset, widget.bookSlug, widget.profileKey);
    _load();
  }

  Future<void> _load() async {
    try {
      final curriculum = await _store.load();
      final lexicon = await _store.loadLexicon();
      if (curriculum.activities.isEmpty) {
        throw StateError('This book has no published activities yet.');
      }
      final done = await _store.completed(curriculum);
      final flagged = await _store.flagged(curriculum);
      var index = curriculum.activities.indexWhere((a) => !done.contains(a.slug));
      if (index < 0) index = curriculum.activities.length - 1;
      final shorts = widget.includeReels
          ? await loadShortsCatalog(widget.keywords)
          : <YoutubeShort>[];
      final gameProgress = widget.includeGames
          ? await _store.gameProgress()
          : <MiniGameKind, int>{};
      final remaining = curriculum.activities.length - index;
      final plannedShorts = shorts.isEmpty ? 0 : 3 + (remaining ~/ 4);
      final feed = planSessionFeed(
        firstUnfinishedActivity: index,
        activityCount: curriculum.activities.length,
        availableShorts: plannedShorts,
        lessonNumbers: curriculum.activities.map((a) => a.lessonNumber).toList(),
        reelsEnabled: widget.includeReels,
        gamesEnabled: widget.includeGames,
        randomSeed: DateTime.now().microsecondsSinceEpoch,
      );
      if (!mounted) return;
      setState(() {
        _curriculum = curriculum;
        _lexicon = lexicon;
        _shorts = shorts;
        _feed = feed;
        _gameProgress
          ..clear()
          ..addAll(gameProgress);
        _done = done;
        _flagged = flagged;
        _index = index;
        _feedIndex = 0;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_controller.hasClients) _controller.jumpToPage(0);
      });
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    }
  }

  Future<void> _complete(Activity activity) async {
    final curriculum = _curriculum!;
    final selected = _selected;
    if (activity.kind == 'quiz' && selected == null &&
        !_done.contains(activity.slug)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Choose an answer before continuing.')),
      );
      return;
    }
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final passed = await _store.complete(curriculum, activity, _done, selected);
      if (!mounted) return;
      if (!passed) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Try another answer to unlock the next card.')),
        );
        return;
      }
      setState(() => _selected = null);
      if (_feedIndex < _feed.length - 1) {
        await _controller.nextPage(
          duration: const Duration(milliseconds: 330),
          curve: Curves.easeOutCubic,
        );
      } else {
        setState(() {});
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save progress: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _flag(Activity activity) async {
    if (_flagged.contains(activity.slug)) return;
    setState(() {
      _flagged.add(activity.slug);
    });
    final synced = await _store.flag(_curriculum!, activity);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(synced
            ? 'Flagged for review.'
            : 'Saved on this device; could not sync the review flag.'),
      ));
    }
  }

  Future<void> _saveGameProgress(MiniGameKind kind, int completedLevel) async {
    final unlocked = min(20, completedLevel + 1).toInt();
    final current = _gameProgress[kind] ?? 1;
    if (unlocked <= current) return;
    final saved = await _store.saveGameProgress(kind, unlocked);
    if (mounted) setState(() => _gameProgress[kind] = saved);
  }

  void _swipeFromVideo(DragEndDetails details, int maxFeedIndex) {
    final velocity = details.primaryVelocity ?? 0;
    if (velocity.abs() < 80 || !_controller.hasClients) return;
    final target = (_feedIndex + (velocity < 0 ? 1 : -1))
        .clamp(0, maxFeedIndex).toInt();
    if (target == _feedIndex) return;
    _controller.animateToPage(
      target,
      duration: const Duration(milliseconds: 330),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.cloud_off, size: 48),
                const SizedBox(height: 18),
                const Text('Could not load the course',
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Text(_error!, textAlign: TextAlign.center),
                const SizedBox(height: 24),
                FilledButton(onPressed: () {
                  setState(() => _error = null);
                  _load();
                }, child: const Text('Try again')),
              ]),
            ),
          ),
        ),
      );
    }
    final curriculum = _curriculum;
    if (curriculum == null || _lexicon == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final activities = curriculum.activities;
    final current = activities[_index];
    final unlockIndex = activities.indexWhere((a) => !_done.contains(a.slug));
    final maxIndex = unlockIndex < 0 ? activities.length - 1 : unlockIndex;
    final frontier = unlockIndex < 0
        ? _feed.length - 1
        : _feed.indexWhere((slot) => slot.activityIndex == maxIndex);
    final maxFeedIndex = frontier < 0 ? _feed.length - 1 : frontier;
    final atLearningFrontier = _feedIndex == maxFeedIndex &&
        _feed[_feedIndex].activityIndex == maxIndex &&
        !_done.contains(activities[maxIndex].slug);
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          Positioned.fill(
            child: Listener(
              onPointerDown: (event) => _swipeStart = event.position,
              onPointerCancel: (_) => _swipeStart = null,
              onPointerUp: (event) {
                final start = _swipeStart;
                _swipeStart = null;
                if (start != null && atLearningFrontier && !_busy &&
                    start.dy - event.position.dy > 56) {
                  _complete(activities[_index]);
                }
              },
              child: NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                if (notification is ScrollStartNotification) {
                  _upwardOverscroll = 0;
                } else if (notification is OverscrollNotification &&
                    atLearningFrontier &&
                    notification.overscroll > 0) {
                  _upwardOverscroll += notification.overscroll;
                } else if (notification is ScrollEndNotification) {
                  if (_upwardOverscroll > 28 && !_busy &&
                      atLearningFrontier) {
                    _complete(activities[_index]);
                  }
                  _upwardOverscroll = 0;
                }
                return false;
              },
              child: PageView.builder(
              controller: _controller,
              scrollDirection: Axis.vertical,
              physics: const ClampingScrollPhysics(),
              itemCount: maxFeedIndex + 1,
              onPageChanged: (index) {
                if (index > maxFeedIndex) {
                  _controller.animateToPage(maxFeedIndex,
                      duration: const Duration(milliseconds: 220),
                      curve: Curves.easeOut);
                  return;
                }
                setState(() {
                  _feedIndex = index;
                  final activityIndex = _feed[index].activityIndex;
                  if (activityIndex != null) {
                    _index = activityIndex;
                    _selected = null;
                  }
                });
              },
              itemBuilder: (context, index) {
                final slot = _feed[index];
                if (slot.isShort) {
                  final video = _shorts[slot.shortIndex! % _shorts.length];
                  return _ShortsCard(
                    video: video,
                    active: index == _feedIndex,
                    onVerticalSwipe: (details) =>
                        _swipeFromVideo(details, maxFeedIndex),
                  );
                }
                if (slot.isGame) {
                  final kind = slot.game!;
                  final startLevel = _gameProgress[kind] ?? 1;
                  return GameBreakCard(
                    key: ValueKey('game-$index-${kind.name}'),
                    kind: kind,
                    startLevel: startLevel,
                    onLevelCompleted: (level) =>
                        _saveGameProgress(kind, level),
                  );
                }
                final activity = activities[slot.activityIndex!];
                return _ActivityCard(
                  activity: activity,
                  lexicon: _lexicon!,
                  flagged: _flagged.contains(activity.slug),
                  onFlag: () => _flag(activity),
                  selected: index == _feedIndex ? _selected : null,
                  completed: _done.contains(activity.slug),
                  busy: _busy,
                  onSelect: (value) {
                    if (!_busy) setState(() => _selected = value);
                  },
                );
              },
              ),
              ),
            ),
          ),
          Positioned(
            top: 8,
            left: 12,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              _FloatingControl(
                onTap: () => Navigator.of(context).pop(),
                child: const Icon(Icons.arrow_back_ios_new_rounded, size: 17),
              ),
              const SizedBox(width: 9),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xFF10182A).withValues(alpha: 0.92),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white12),
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                      maxWidth: MediaQuery.sizeOf(context).width - 110),
                  child: Text(
                    'LESSON ${current.lessonNumber}  ·  '
                    'CARD ${current.cardNumber}/${current.lessonCardCount}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Color(0xFFF5C85B),
                        fontSize: 11, fontWeight: FontWeight.w800,
                        letterSpacing: 0.5),
                  ),
                ),
              ),
            ]),
          ),
          Positioned(
            top: 8,
            right: 14,
            child: _FloatingControl(
              size: 42,
              child: Text(
                widget.profileName.trim().isEmpty
                    ? '?'
                    : widget.profileName.trim().substring(0, 1).toUpperCase(),
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800,
                    color: Color(0xFFF5C85B)),
              ),
            ),
          ),
          Positioned(
            top: 62,
            left: 20,
            right: 20,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: LinearProgressIndicator(
                value: _done.length / activities.length,
                minHeight: 4,
                backgroundColor: Colors.white24,
                color: const Color(0xFFF5C85B),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

class _FloatingControl extends StatelessWidget {
  const _FloatingControl({required this.child, this.onTap, this.size = 40});

  final Widget child;
  final VoidCallback? onTap;
  final double size;

  @override
  Widget build(BuildContext context) => Material(
    color: const Color(0xFF10182A).withValues(alpha: 0.92),
    shape: const CircleBorder(side: BorderSide(color: Colors.white12)),
    child: InkWell(
      customBorder: const CircleBorder(),
      onTap: onTap,
      child: SizedBox(width: size, height: size,
          child: Center(child: child)),
    ),
  );
}

class _ShortsCard extends StatelessWidget {
  const _ShortsCard({
    required this.video,
    required this.active,
    required this.onVerticalSwipe,
  });

  final YoutubeShort video;
  final bool active;
  final ValueChanged<DragEndDetails> onVerticalSwipe;

  @override
  Widget build(BuildContext context) => Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1D2940),
        borderRadius: BorderRadius.circular(26),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(26),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 94, 18, 22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: LayoutBuilder(builder: (context, size) {
                final width = size.maxWidth < size.maxHeight * 9 / 16
                    ? size.maxWidth : size.maxHeight * 9 / 16;
                return Center(child: SizedBox(width: width,
                  child: ClipRRect(borderRadius: BorderRadius.circular(18),
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onVerticalDragEnd: onVerticalSwipe,
                      child: active
                        ? _EmbeddedShort(key: ValueKey(video.id), videoId: video.id)
                        : Image.network(
                            'https://i.ytimg.com/vi/${video.id}/hqdefault.jpg',
                            fit: BoxFit.cover),
                    ),
                  )),
                );
              })),
              const SizedBox(height: 12),
              Text(video.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
              Text(video.channel, style: const TextStyle(color: Colors.white60)),
            ],
          ),
        ),
      ),
    );
}

class _EmbeddedShort extends StatefulWidget {
  const _EmbeddedShort({super.key, required this.videoId});
  final String videoId;

  @override
  State<_EmbeddedShort> createState() => _EmbeddedShortState();
}

class _EmbeddedShortState extends State<_EmbeddedShort> {
  late final YoutubePlayerController _player;

  @override
  void initState() {
    super.initState();
    _player = YoutubePlayerController.fromVideoId(
      videoId: widget.videoId,
      autoPlay: true,
      params: const YoutubePlayerParams(
        showControls: true,
        showFullscreenButton: false,
        playsInline: true,
      ),
    );
  }

  @override
  void dispose() {
    _player.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => IgnorePointer(
      child: YoutubePlayer(
        controller: _player,
        aspectRatio: 9 / 16,
        autoFullScreen: false,
        enableFullScreenOnVerticalDrag: false,
      ));
}

class _ActivityCard extends StatelessWidget {
  const _ActivityCard({
    required this.activity,
    required this.lexicon,
    required this.flagged,
    required this.onFlag,
    required this.selected,
    required this.completed,
    required this.busy,
    required this.onSelect,
  });

  final Activity activity;
  final Lexicon lexicon;
  final bool flagged;
  final VoidCallback onFlag;
  final int? selected;
  final bool completed;
  final bool busy;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final payload = activity.payload;
    final kind = activity.kind;
    final label = switch (kind) {
      'grammar' => 'GRAMMAR',
      'vocabulary' => 'VOCABULARY',
      'quiz' => 'QUICK CHECK',
      _ => kind.toUpperCase(),
    };
    final icon = switch (kind) {
      'grammar' => Icons.menu_book_rounded,
      'vocabulary' => Icons.translate_rounded,
      'quiz' => Icons.psychology_alt_rounded,
      _ => Icons.auto_stories,
    };
    return Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1D2940),
          borderRadius: BorderRadius.circular(26),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(26, 98, 26, 28),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5C85B).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(icon, color: const Color(0xFFF5C85B)),
              ),
              const SizedBox(width: 12),
              Text(label, style: const TextStyle(
                  color: Color(0xFFF5C85B), fontSize: 12,
                  fontWeight: FontWeight.w800, letterSpacing: 1.5)),
              const Spacer(),
              if (completed) const Icon(Icons.check_circle,
                  color: Color(0xFF70D6AB)),
              IconButton(
                tooltip: flagged ? 'Flagged for review' : 'Flag this content',
                onPressed: flagged ? null : onFlag,
                icon: Icon(flagged ? Icons.flag_rounded : Icons.outlined_flag,
                    color: flagged ? const Color(0xFFFFB684) : Colors.white70),
              ),
            ]),
            const SizedBox(height: 30),
            LexicalText(activity.title, lexicon: lexicon, style: const TextStyle(
                fontSize: 30, fontWeight: FontWeight.w800, height: 1.1)),
            const SizedBox(height: 22),
            Expanded(child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: switch (kind) {
              'grammar' => _GrammarBody(payload: payload, lexicon: lexicon),
              'vocabulary' => _VocabularyBody(payload: payload, lexicon: lexicon),
              'quiz' => _QuizBody(payload: payload, selected: selected,
                  onSelect: onSelect, lexicon: lexicon),
              _ => LexicalText(payload['body']?.toString() ?? '',
                  lexicon: lexicon),
            })),
          ]),
        ),
      );
  }
}

class _GrammarBody extends StatelessWidget {
  const _GrammarBody({required this.payload, required this.lexicon});
  final Map<String, dynamic> payload;
  final Lexicon lexicon;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      LexicalText(payload['body']?.toString() ?? '', lexicon: lexicon,
          style: const TextStyle(fontSize: 18, height: 1.55)),
      if (payload['example'] != null) ...[
        const SizedBox(height: 25),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.07),
            borderRadius: BorderRadius.circular(17),
          ),
          child: LexicalText(payload['example'].toString(), lexicon: lexicon,
              style: const TextStyle(fontSize: 17, color: Color(0xFFF5C85B))),
        ),
      ],
    ],
  );
}

class _VocabularyBody extends StatelessWidget {
  const _VocabularyBody({required this.payload, required this.lexicon});
  final Map<String, dynamic> payload;
  final Lexicon lexicon;

  @override
  Widget build(BuildContext context) {
    final items = payload['items'] as List<dynamic>? ?? [];
    return Column(children: items.map((entry) {
      final item = entry as Map<String, dynamic>;
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.06),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: LexicalText(item['de'].toString(), lexicon: lexicon,
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold))),
            Text(item['en'].toString(),
                style: const TextStyle(color: Color(0xFFF5C85B))),
          ]),
          const SizedBox(height: 7),
          LexicalText(item['example'].toString(), lexicon: lexicon,
              style: const TextStyle(color: Colors.white60)),
        ]),
      );
    }).toList());
  }
}

class _QuizBody extends StatelessWidget {
  const _QuizBody({required this.payload, required this.selected,
      required this.onSelect, required this.lexicon});
  final Map<String, dynamic> payload;
  final int? selected;
  final ValueChanged<int> onSelect;
  final Lexicon lexicon;

  @override
  Widget build(BuildContext context) {
    final options = payload['options'] as List<dynamic>? ?? [];
    final correct = payload['answer'] as int;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      LexicalText(payload['question'].toString(), lexicon: lexicon,
          style: const TextStyle(fontSize: 20, height: 1.4)),
      const SizedBox(height: 20),
      for (var i = 0; i < options.length; i++)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: InkWell(
            onTap: () => onSelect(i),
            borderRadius: BorderRadius.circular(15),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(17),
              decoration: BoxDecoration(
                color: selected == i ? const Color(0xFFF5C85B)
                    .withValues(alpha: 0.18) : Colors.white.withValues(alpha: 0.06),
                border: Border.all(color: selected == i
                    ? const Color(0xFFF5C85B) : Colors.white12),
                borderRadius: BorderRadius.circular(15),
              ),
              child: LexicalText(options[i].toString(), lexicon: lexicon,
                  style: const TextStyle(fontSize: 17)),
            ),
          ),
        ),
      if (selected != null) ...[
        const SizedBox(height: 13),
        Text(selected == correct ? 'Correct! ✓' :
            'Not quite. Correct: ${options[correct]}',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold,
                color: selected == correct ? const Color(0xFF70D6AB)
                    : const Color(0xFFFFB684))),
        const SizedBox(height: 6),
        Text(payload['explanation']?.toString() ?? '',
            style: const TextStyle(color: Colors.white70)),
      ],
    ]);
  }
}
