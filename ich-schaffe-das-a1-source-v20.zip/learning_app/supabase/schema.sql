-- Run in a dedicated Supabase project. Content writes are administrator-only.
create table if not exists public.learning_books (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  edition text not null,
  level text not null check (level in ('A1', 'A2', 'B1', 'B2', 'C1', 'C2')),
  source_status text not null default 'draft' check (source_status in ('draft', 'reviewed', 'published')),
  created_at timestamptz not null default now()
);

create table if not exists public.learning_lessons (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null references public.learning_books(id) on delete cascade,
  slug text not null,
  number integer not null check (number > 0),
  title text not null,
  goal text not null default '',
  unique (book_id, slug),
  unique (book_id, number)
);

create table if not exists public.learning_activities (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.learning_lessons(id) on delete cascade,
  slug text not null unique,
  sequence_number integer not null check (sequence_number > 0),
  kind text not null check (kind in ('grammar', 'vocabulary', 'quiz')),
  title text not null,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  unique (lesson_id, sequence_number)
);

create table if not exists public.learner_activity_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  profile_key text not null,
  book_slug text not null references public.learning_books(slug) on delete cascade,
  activity_slug text not null references public.learning_activities(slug) on delete cascade,
  completed_at timestamptz not null default now(),
  primary key (user_id, profile_key, book_slug, activity_slug)
);

create table if not exists public.learner_answers (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  profile_key text not null,
  book_slug text not null references public.learning_books(slug) on delete cascade,
  activity_slug text not null references public.learning_activities(slug) on delete cascade,
  selected_answer integer not null,
  is_correct boolean not null,
  answered_at timestamptz not null default now(),
  attempt_key text unique
);

create table if not exists public.learner_score_events (
  user_id uuid not null,
  profile_key text not null,
  book_slug text not null,
  activity_slug text not null,
  language_level text not null,
  points integer not null check (points between 0 and 2),
  earned_at timestamptz not null,
  primary key (user_id, profile_key, book_slug, activity_slug),
  foreign key (user_id, profile_key, book_slug, activity_slug)
    references public.learner_activity_progress
      (user_id, profile_key, book_slug, activity_slug) on delete cascade
);

create table if not exists public.learner_profiles (
  user_id uuid not null references auth.users(id) on delete cascade,
  profile_key text not null check (length(trim(profile_key)) > 0),
  display_name text not null check (length(trim(display_name)) > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, profile_key)
);

create table if not exists public.learner_game_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  profile_key text not null check (length(trim(profile_key)) > 0),
  game_slug text not null check (game_slug in ('planks', 'territory', 'lines')),
  highest_level integer not null default 1 check (highest_level between 1 and 20),
  updated_at timestamptz not null default now(),
  primary key (user_id, profile_key, game_slug)
);

create table if not exists public.learning_lexicon (
  book_slug text not null references public.learning_books(slug) on delete cascade,
  lemma text not null,
  word_type text not null check (word_type in ('noun', 'verb')),
  meaning_en text not null,
  article text check (article in ('der', 'die', 'das') or article is null),
  plural text,
  forms jsonb not null default '[]'::jsonb check (jsonb_typeof(forms) = 'array'),
  primary key (book_slug, lemma, word_type)
);

create table if not exists public.learning_content_flags (
  id uuid primary key default gen_random_uuid(),
  book_slug text not null references public.learning_books(slug) on delete cascade,
  activity_slug text not null references public.learning_activities(slug) on delete cascade,
  flagged_at timestamptz not null default now(),
  status text not null default 'open' check (status in ('open', 'fixed')),
  unique (book_slug, activity_slug)
);

create index if not exists learning_content_flags_activity_idx
  on public.learning_content_flags (activity_slug);

create index if not exists learner_answers_user_book_idx
  on public.learner_answers (user_id, profile_key, book_slug, answered_at desc);
create index if not exists learner_activity_progress_activity_idx
  on public.learner_activity_progress (activity_slug);
create index if not exists learner_activity_progress_book_idx
  on public.learner_activity_progress (book_slug);
create index if not exists learner_answers_activity_idx
  on public.learner_answers (activity_slug);
create index if not exists learner_answers_book_idx
  on public.learner_answers (book_slug);
create index if not exists learner_score_events_month_idx
  on public.learner_score_events (user_id, earned_at, profile_key);

alter table public.learning_books enable row level security;
alter table public.learning_lessons enable row level security;
alter table public.learning_activities enable row level security;
alter table public.learner_activity_progress enable row level security;
alter table public.learner_answers enable row level security;
alter table public.learner_score_events enable row level security;
alter table public.learner_profiles enable row level security;
alter table public.learner_game_progress enable row level security;
alter table public.learning_lexicon enable row level security;
alter table public.learning_content_flags enable row level security;

-- Book content is read-only to clients; only published books are visible.
create policy "read published books" on public.learning_books for select
  to anon, authenticated using (source_status = 'published');
create policy "read published lessons" on public.learning_lessons for select
  to anon, authenticated using (
    exists (select 1 from public.learning_books b
      where b.id = book_id and b.source_status = 'published')
  );
create policy "read published activities" on public.learning_activities for select
  to anon, authenticated using (
    exists (select 1 from public.learning_lessons l
      join public.learning_books b on b.id = l.book_id
      where l.id = lesson_id and b.source_status = 'published')
  );
create policy "read published lexicon" on public.learning_lexicon for select
  to anon, authenticated using (
    exists (select 1 from public.learning_books b
      where b.slug = book_slug and b.source_status = 'published')
  );
create policy "learners can flag course content" on public.learning_content_flags
  for insert to anon, authenticated
  with check (length(trim(book_slug)) > 0 and length(trim(activity_slug)) > 0);

create policy "read own progress" on public.learner_activity_progress
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "insert own progress" on public.learner_activity_progress
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "update own progress" on public.learner_activity_progress
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
create policy "delete own progress" on public.learner_activity_progress
  for delete to authenticated using ((select auth.uid()) = user_id);
create policy "read own answers" on public.learner_answers
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "insert own answers" on public.learner_answers
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "delete own answers" on public.learner_answers
  for delete to authenticated using ((select auth.uid()) = user_id);
create policy "read own score events" on public.learner_score_events
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "read own profiles" on public.learner_profiles
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "insert own profiles" on public.learner_profiles
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "update own profiles" on public.learner_profiles
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
create policy "read own game progress" on public.learner_game_progress
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "insert own game progress" on public.learner_game_progress
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "update own game progress" on public.learner_game_progress
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
create policy "delete own game progress" on public.learner_game_progress
  for delete to authenticated using ((select auth.uid()) = user_id);

grant select on public.learning_books, public.learning_lessons,
  public.learning_activities, public.learning_lexicon to anon, authenticated;
grant insert on public.learning_content_flags to anon, authenticated;
grant select, insert, update, delete on public.learner_activity_progress to authenticated;
grant select, insert, delete on public.learner_answers to authenticated;
grant select on public.learner_score_events to authenticated;
grant select, insert, update on public.learner_profiles to authenticated;
grant select, insert, update, delete on public.learner_game_progress to authenticated;
grant usage, select on sequence public.learner_answers_id_seq to authenticated;

create schema if not exists app_private;
revoke all on schema app_private from public, anon, authenticated;

create or replace function app_private.award_activity_points()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  activity_kind text;
  course_level text;
  attempts integer;
  answered_correctly boolean;
  award integer;
begin
  select a.kind, b.level into activity_kind, course_level
    from public.learning_activities a
    join public.learning_lessons l on l.id = a.lesson_id
    join public.learning_books b on b.id = l.book_id
    where a.slug = new.activity_slug and b.slug = new.book_slug;
  if activity_kind = 'quiz' then
    select count(*), coalesce(bool_or(is_correct), false)
      into attempts, answered_correctly
      from public.learner_answers
      where user_id = new.user_id and profile_key = new.profile_key
        and book_slug = new.book_slug and activity_slug = new.activity_slug;
    award := case when not answered_correctly then 0
      when attempts = 1 then 2 when attempts = 2 then 1 else 0 end;
  else
    award := 1;
  end if;
  insert into public.learner_score_events
    (user_id, profile_key, book_slug, activity_slug,
     language_level, points, earned_at)
  values (new.user_id, new.profile_key, new.book_slug, new.activity_slug,
          course_level, award, new.completed_at)
  on conflict do nothing;
  return new;
end;
$$;
revoke all on function app_private.award_activity_points()
  from public, anon, authenticated;
create trigger award_completed_activity_points
  after insert on public.learner_activity_progress
  for each row execute function app_private.award_activity_points();

create or replace view public.learner_profile_points
  with (security_invoker = true) as
select user_id, profile_key, language_level,
  sum(points)::integer as lifetime_points,
  coalesce(sum(points) filter (where earned_at >=
    date_trunc('month', now())), 0)::integer as current_month_points
from public.learner_score_events
group by user_id, profile_key, language_level;
grant select on public.learner_profile_points to authenticated;
