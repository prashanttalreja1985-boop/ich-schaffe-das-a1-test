# Ich schaffe das — A1 test app

A swipe-up German lesson app for iPhone. Google sign-in is optional, and it does
not call an AI service while a learner uses it. Grammar cards come first, then vocabulary,
then quizzes. Swiping up at the current card completes it; quizzes require a
correct answer. An upward swipe advances from the card itself, including when
the lesson text is scrollable. The app reopens at the first unfinished card.

Google sign-in is available from Home and in-course settings. It opens Google's
external sign-in page and returns through `de.ichschaffedas.a1://login-callback/`.
An anonymous Supabase identity can link to Google while retaining its user ID,
progress, and points. `learner_profiles` stores saved names under that account
so another installation can list them. The Google OAuth secret remains in
Deutsch Supabase; it is not in the IPA. The OAuth project is in testing mode
and currently allows the project owner's Google account. Google sign-in does
not provide a personalized YouTube Shorts feed; keyword search remains active.

The home screen asks for a profile name, shows A1 as the available course, and
keeps A1+ Revision greyed out until that profile completes A1. A1+ is a separate
course and database book. The YouTube Reels section accepts comma-separated
interest keywords and has separate per-profile toggles for YouTube and games.
On lesson cards, tap the profile initial to see this month's profile leaders,
switch profiles, change YouTube or game settings, or return home. Switching
profiles resumes at that profile's first unfinished card. Each completed
learning card earns one point; a quiz earns two points on the first answer
attempt, one on the second, and none after that. Deutsch stores the award once
per activity and summarizes lifetime, current-month, and language-level points.
Selecting a saved profile shows a reset action for lesson completions, quiz
attempts, and game levels. It clears device and Supabase progress while keeping
profile settings, and retries the cloud reset on a later session if offline.
When YouTube alone is enabled, matching videos open with three video cards,
followed by one video after every four learning cards. With both modes enabled,
break cards randomly mix matching Shorts and games. Enabling games adds at least
two game-level breaks to each lesson. The games are a 20-level wooden-plank
escape puzzle and a 20-level Lines color-race puzzle; completed levels unlock on
this device for that profile. Videos are filtered by the entered interests; an
empty interest list or a keyword with no catalog match shows no videos. The test
catalog is small and fixed, so it does not search YouTube live. Videos use
YouTube's embedded player inside the card. They may repeat, and some videos may
be unavailable if a creator blocks embedding. Neither YouTube login nor an API
key is used.

## Current content status

`assets/starter_content.json` contains an original expanded A1 course with
10 topic-based lessons, over 1,400 cards, and 400 vocabulary entries. It includes articles,
cases, present and perfect forms, modal and separable verbs, questions, time,
dates, and everyday situations. Repeated quizzes practice articles, meanings,
and verb forms. `tool/video_coverage_0emzztSmKjA.json` maps every minute of the
supplied A1 video to course lessons. Its auto-generated captions mishear some
German words; the course uses corrected, original examples. Listening and
speaking assessment are not yet in this text-based app.

`assets/a1_plus_content.json` is a separate A1+ revision course for use after the
10-lesson A1 course. It contains 14 original revision lessons aligned to the transcript
supplied for the 9.5-hour video. The transcript audit maps all 868 timestamp
markers to one of the 14 chapter lessons; the full transcript text is not bundled.
A1+ has 145 activities and 208 vocabulary entries, with separate database
content and progress and unique activity IDs. Lessons review and extend alphabet and pronunciation,
articles, pronouns and plurals, present/past/Perfekt verb forms, sentence order,
questions, adjective endings, modals, accusative and dative introductions,
prepositions, comparisons, demonstratives, shopping, imperative, health and
appointments. `tool/a1_plus_import.sql` imports this as a **draft** course into
the normalized Supabase course tables. It is installed in the **Deutsch**
Supabase project as a draft, separate from the published A1 course.

This course is not a reproduction of *Netzwerk neu A1* and has not been checked
against the complete book. After the book's edition,
table of contents, and usable source material are supplied, build a coverage map
for every lesson, grammar point, vocabulary set, and exercise goal. Review that map
against the source before marking the book `published`. Use original explanations
and questions unless you have the rights to reproduce the book's text and layout.

## Content and progress

The database separates books, lessons, activities, and the lexical reference.
Each activity row has an ID, lesson ID, `sequence_number`, `kind`, and JSONB
`payload`. The app uses preset card layouts for `grammar`, `vocabulary`, and
`quiz`, selected by `kind`. `learning_lexicon` keeps noun and verb meanings and
inflected German forms keyed to the book slug. Long-press an amber noun or green
verb to open its meaning in an on-screen popover; taps still reach the quiz
answer underneath. It currently holds 207 A1 nouns
and 144 verbs, plus 127 A1+ nouns and 108 verbs. A1+ remains a draft, so only
published A1 material is exposed to the app.

- Without Supabase configuration, the app loads the selected bundled course JSON
  and saves completed cards by profile and course on the device with SharedPreferences.
- With Supabase configuration, it reads a published book, ordered lessons,
  ordered activities, and the matching lexicon. It attempts anonymous sign-in so
  progress and answers can sync without an account screen; if sign-in is
  unavailable, progress stays local. The Deutsch project keeps completed cards
  in `learner_activity_progress`, quiz attempts in `learner_answers`, and game
  level unlocks in `learner_game_progress`. Each row is scoped to Supabase's
  anonymous device user and the selected local profile key, with RLS restricting
  access to that user. Profiles and progress do not transfer to another device
  unless a sign-in or account-linking option is added later.
- Each card has a flag control. A flag is saved locally for the current profile
  and submitted to `learning_content_flags` in Supabase. One open review row is
  kept per course activity, so duplicate taps do not create duplicate reports.
  The table records the course, activity, flag time, and `open`/`fixed` review
  status; it does not require a learner account.
- `supabase/schema.sql` creates the tables and row-level policies. The schema,
  A1 course, and lexicon are deployed to Deutsch; A1+ is loaded as draft. Never
  put a service-role key in the app.
- A book import happens outside the app. Validate a reviewed JSON file and emit SQL:

  ```sh
  python tool/import_book.py assets/starter_content.json tool/starter_import.sql --publish
  ```

  Review and run the emitted SQL in the Supabase SQL editor. Omit `--publish`
  while the coverage audit is incomplete. The importer is idempotent for known
  books, lessons, and activities, but deletion of removed content is a separate
  editorial step. Existing learner progress uses stable activity slugs.

Edit `tool/build_a1_course.js`, then run `node tool/build_a1_course.js` and
`node tool/validate_course.js` to regenerate and check the bundled course. The
first eight starter cards retain their slugs, so earlier progress carries over.

## Build an IPA for Sideloadly

iOS builds require Xcode on macOS. The repository's
`.github/workflows/ich-schaffe-das-ipa.yml` runs the iOS build on a GitHub macOS
runner and uploads `Ich-schaffe-das-A1-unsigned.ipa`. Sideloadly can sign the IPA
with your Apple ID when installing it. Trigger the workflow manually from GitHub
Actions, or push changes under `learning_app/`.

For the bundled course, leave the workflow variables unset. For a published
Supabase course, set repository variables `LEARNING_SUPABASE_URL` and
`LEARNING_SUPABASE_PUBLISHABLE_KEY`, and publish the course under slug
`netzwerk-neu-a1`. Then run the workflow and download its artifact. The build
embeds only the public project URL and publishable key.

Locally on a Mac:

```sh
flutter pub get
flutter analyze
flutter test
flutter build ios --release --no-codesign
mkdir -p build/ipa/Payload
cp -R build/ios/iphoneos/Runner.app build/ipa/Payload/
(cd build/ipa && zip -qr Ich-schaffe-das-A1-unsigned.ipa Payload)
```

This is a testing package, not an App Store signed distribution. The iOS bundle ID
is `de.ichschaffedas.a1` and the display name is **Ich schaffe das**.
