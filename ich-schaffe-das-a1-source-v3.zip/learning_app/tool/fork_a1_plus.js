// Clone the reviewed A1 baseline into a separate draft course. This does not
// claim coverage of the longer Five Minute German video; add only verified
// original material after its transcript or course notes are available.
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const source = path.join(root, 'assets', 'starter_content.json');
const target = path.join(root, 'assets', 'a1_plus_content.json');
const base = JSON.parse(fs.readFileSync(source, 'utf8'));
const copy = structuredClone(base);
copy.book = {
  slug: 'ich-schaffe-das-a1-plus',
  title: 'Ich schaffe das — A1+',
  edition: 'A1 baseline copy; longer-video coverage pending',
  level: 'A1',
};
for (const lesson of copy.lessons) {
  for (const activity of lesson.activities) {
    activity.slug = `a1plus-${activity.slug}`;
  }
}
fs.writeFileSync(target, `${JSON.stringify(copy, null, 2)}\n`);
console.log(`Copied ${copy.lessons.length} A1 lessons into ${target} as a separate draft A1+ course.`);
