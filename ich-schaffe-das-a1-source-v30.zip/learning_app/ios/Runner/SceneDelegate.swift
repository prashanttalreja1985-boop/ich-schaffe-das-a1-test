import Flutter
import UIKit

class SceneDelegate: FlutterSceneDelegate, UIGestureRecognizerDelegate {
  private var shortPan: UIPanGestureRecognizer?

  override func scene(
    _ scene: UIScene,
    willConnectTo session: UISceneSession,
    options connectionOptions: UIScene.ConnectionOptions
  ) {
    super.scene(scene, willConnectTo: session, options: connectionOptions)
    installShortPan()
  }

  override func sceneDidBecomeActive(_ scene: UIScene) {
    super.sceneDidBecomeActive(scene)
    installShortPan()
  }

  private func installShortPan() {
    guard shortPan == nil, let window = window else { return }
    let pan = UIPanGestureRecognizer(target: self, action: #selector(handleShortPan(_:)))
    pan.cancelsTouchesInView = false
    pan.delaysTouchesBegan = false
    pan.delegate = self
    pan.isEnabled = AppDelegate.shortSwipeEnabled
    window.addGestureRecognizer(pan)
    shortPan = pan
  }

  func setShortPanEnabled(_ enabled: Bool) {
    installShortPan()
    shortPan?.isEnabled = enabled
  }

  @objc private func handleShortPan(_ recognizer: UIPanGestureRecognizer) {
    guard let view = recognizer.view else { return }
    let movement = recognizer.translation(in: view)
    let speed = recognizer.velocity(in: view)
    let phase: String
    switch recognizer.state {
    case .began: phase = "start"
    case .changed: phase = "update"
    case .ended: phase = "end"
    case .cancelled, .failed: phase = "cancel"
    default: return
    }
    AppDelegate.shortSwipeChannel?.invokeMethod("shortDrag", arguments: [
      "phase": phase,
      "translation": Double(movement.y),
      "velocity": Double(speed.y),
    ])
  }

  func gestureRecognizer(
    _ gestureRecognizer: UIGestureRecognizer,
    shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer
  ) -> Bool {
    true
  }
}
