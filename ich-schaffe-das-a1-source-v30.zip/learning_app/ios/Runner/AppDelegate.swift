import Flutter
import UIKit
import AVFoundation

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {
  static var shortSwipeChannel: FlutterMethodChannel?
  static var shortSwipeEnabled = false

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
    try? AVAudioSession.sharedInstance().setActive(true)
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)
    let channel = FlutterMethodChannel(
      name: "de.ichschaffedas.a1/short_swipe",
      binaryMessenger: engineBridge.applicationRegistrar.messenger()
    )
    AppDelegate.shortSwipeChannel = channel
    channel.setMethodCallHandler { call, result in
      guard call.method == "setEnabled", let enabled = call.arguments as? Bool else {
        result(FlutterMethodNotImplemented)
        return
      }
      AppDelegate.shortSwipeEnabled = enabled
      for scene in UIApplication.shared.connectedScenes {
        (scene.delegate as? SceneDelegate)?.setShortPanEnabled(enabled)
      }
      result(nil)
    }
  }
}
