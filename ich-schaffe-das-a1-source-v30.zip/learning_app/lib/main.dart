import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'dart:math' show Random, max, min;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

import 'feed_plan.dart';
import 'lexicon.dart';
import 'mini_games.dart';
import 'shorts_catalog.dart';
import 'youtube_search.dart';
part 'auth_gate.dart';

const _supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const _supabaseKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
const _starterReelKeywords = 'travel, football';
const _googleRedirect = 'de.ichschaffedas.a1://login-callback/';
const _shortSwipeChannel = MethodChannel('de.ichschaffedas.a1/short_swipe');
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (_supabaseUrl.isNotEmpty && _supabaseKey.isNotEmpty) {
    await Supabase.initialize(url: _supabaseUrl, publishableKey: _supabaseKey);
  }
  runApp(const LearningApp());
}

class Activity {
  const Activity({
    required this.slug,
    required this.kind,
    required this.title,
    required this.lessonTitle,
    required this.lessonNumber,
    required this.cardNumber,
    required this.lessonCardCount,
    required this.payload,
  });

  final String slug;
  final String kind;
  final String title;
  final String lessonTitle;
  final int lessonNumber;
  final int cardNumber;
  final int lessonCardCount;
  final Map<String, dynamic> payload;

  factory Activity.fromJson(
    Map<String, dynamic> json,
    String lessonTitle,
    int lessonNumber,
    int cardNumber,
    int lessonCardCount,
  ) {
    return Activity(
      slug: json['slug'] as String,
      kind: json['kind'] as String,
      title: json['title'] as String,
      lessonTitle: lessonTitle,
      lessonNumber: lessonNumber,
      cardNumber: cardNumber,
      lessonCardCount: lessonCardCount,
      payload: json,
    );
  }
}

class Curriculum {
  const Curriculum(this.title, this.edition, this.slug, this.activities);

  final String title;
  final String edition;
  final String slug;
  final List<Activity> activities;

  factory Curriculum.fromJson(Map<String, dynamic> data) {
    final book = data['book'] as Map<String, dynamic>;
    final activities = <Activity>[];
    final lessons =
        (data['lessons'] as List<dynamic>).cast<Map<String, dynamic>>()
          ..sort((a, b) => (a['number'] as int).compareTo(b['number'] as int));
    for (final lesson in lessons) {
      final row = lesson;
      final lessonActivities = row['activities'] as List<dynamic>;
      for (var index = 0; index < lessonActivities.length; index++) {
        activities.add(
          Activity.fromJson(
            lessonActivities[index] as Map<String, dynamic>,
            row['title'] as String,
            row['number'] as int,
            index + 1,
            lessonActivities.length,
          ),
        );
      }
    }
    return Curriculum(
      book['title'] as String,
      book['edition'] as String,
      book['slug'] as String,
      activities,
    );
  }
}

class LearningStore {
  LearningStore(this.courseAsset, this.bookSlug, this.profileKey);

  final String courseAsset;
  final String bookSlug;
  final String profileKey;

  SupabaseClient? get _client => _supabaseUrl.isEmpty || _supabaseKey.isEmpty
      ? null
      : Supabase.instance.client;

  Future<Curriculum> load() async {
    final sample = await rootBundle.loadString(courseAsset);
    final fallback = Curriculum.fromJson(
      jsonDecode(sample) as Map<String, dynamic>,
    );
    final client = _client;
    if (client == null) return fallback;
    try {
      final book = await client
          .from('learning_books')
          .select('id,slug,title,edition,level')
          .eq('slug', bookSlug)
          .single();
      final lessons = await client
          .from('learning_lessons')
          .select('id,slug,number,title,goal')
          .eq('book_id', book['id'])
          .order('number');
      final lessonIds = lessons.map((lesson) => lesson['id']).toList();
      final rows = <Map<String, dynamic>>[];
      for (var offset = 0; ; offset += 1000) {
        final page = await client
            .from('learning_activities')
            .select('lesson_id,slug,kind,title,payload,sequence_number')
            .inFilter('lesson_id', lessonIds)
            .order('lesson_id')
            .order('sequence_number')
            .range(offset, offset + 999);
        rows.addAll(page);
        if (page.length < 1000) break;
      }
      final lessonData = lessons.map((lesson) {
        final activities = rows
            .where((row) => row['lesson_id'] == lesson['id'])
            .map(
              (row) => {
                ...(row['payload'] as Map<String, dynamic>),
                'slug': row['slug'],
                'kind': row['kind'],
                'title': row['title'],
              },
            )
            .toList();
        return {...lesson, 'activities': activities};
      }).toList();
      return Curriculum.fromJson({'book': book, 'lessons': lessonData});
    } catch (_) {
      return fallback;
    }
  }

  Future<Lexicon> loadLexicon() async {
    final bundled = jsonDecode(
      await rootBundle.loadString('assets/lexicon.json'),
    ) as Map<String, dynamic>;
    final fallback = Lexicon.fromJson(bundled, bookSlug);
    final client = _client;
    if (client == null) return fallback;
    try {
      final rows = await client
          .from('learning_lexicon')
          .select('book_slug,lemma,word_type,meaning_en,article,forms')
          .eq('book_slug', bookSlug);
      if (rows.isEmpty) return fallback;
      return Lexicon(rows.map((row) => Lexeme.fromJson(row)));
    } catch (_) {
      // A bundled lexicon keeps the course usable before the optional table is
      // installed or published in Supabase.
      return fallback;
    }
  }

  Future<Set<String>> completed(Curriculum curriculum) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'done:$profileKey:${curriculum.slug}';
    final done = prefs.getStringList(key)?.toSet() ?? <String>{};
    final resetReady = await syncPendingProgressReset();
    final client = _client;
    if (resetReady && client != null && client.auth.currentUser != null) {
      try {
        final userId = client.auth.currentUser!.id;
        await _syncAnswers(curriculum, prefs, client, userId);
        final rows = <Map<String, dynamic>>[];
        for (var offset = 0; ; offset += 1000) {
          final page = await client
              .from('learner_activity_progress')
              .select('activity_slug')
              .eq('user_id', userId)
              .eq('profile_key', profileKey)
              .eq('book_slug', curriculum.slug)
              .order('activity_slug')
              .range(offset, offset + 999);
          rows.addAll(page);
          if (page.length < 1000) break;
        }
        final remoteDone = rows
            .map((row) => row['activity_slug'] as String)
            .toSet();
        done.addAll(remoteDone);
        await prefs.setStringList(key, done.toList());
        final validSlugs = curriculum.activities.map((a) => a.slug).toSet();
        final pending = done.intersection(validSlugs).difference(remoteDone);
        if (pending.isNotEmpty) {
          await client.from('learner_activity_progress').upsert([
            for (final slug in pending)
              {
                'user_id': userId,
                'profile_key': profileKey,
                'book_slug': curriculum.slug,
                'activity_slug': slug,
              },
          ], onConflict: 'user_id,profile_key,book_slug,activity_slug');
        }
      } catch (_) {
        // Keep local progress available while the database is offline.
      }
    }
    return done;
  }

  Future<Map<MiniGameKind, int>> gameProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final progress = <MiniGameKind, int>{
      for (final kind in MiniGameKind.values)
        kind: (prefs.getInt('game-level:$profileKey:${kind.name}') ?? 1)
            .clamp(1, 20)
            .toInt(),
    };
    if (!await syncPendingProgressReset()) return progress;
    final client = _client;
    final user = client?.auth.currentUser;
    if (client == null || user == null) return progress;
    try {
      final rows = await client
          .from('learner_game_progress')
          .select('game_slug,highest_level')
          .eq('user_id', user.id)
          .eq('profile_key', profileKey);
      for (final row in rows) {
        final matches = MiniGameKind.values.where(
          (value) => value.name == row['game_slug'],
        );
        if (matches.isEmpty) continue;
        final kind = matches.first;
        final level = (row['highest_level'] as int).clamp(1, 20).toInt();
        progress[kind] = max(progress[kind] ?? 1, level).toInt();
        await prefs.setInt(
          'game-level:$profileKey:${kind.name}',
          progress[kind]!,
        );
      }
      for (final kind in MiniGameKind.values) {
        final level = progress[kind] ?? 1;
        await client.from('learner_game_progress').upsert({
          'user_id': user.id,
          'profile_key': profileKey,
          'game_slug': kind.name,
          'highest_level': level,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        }, onConflict: 'user_id,profile_key,game_slug');
      }
    } catch (_) {
      // Local game progress remains usable when the network or table is absent.
    }
    return progress;
  }

  Future<int> saveGameProgress(MiniGameKind kind, int unlockedLevel) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'game-level:$profileKey:${kind.name}';
    final level = max(
      (prefs.getInt(key) ?? 1).clamp(1, 20).toInt(),
      unlockedLevel.clamp(1, 20).toInt(),
    ).toInt();
    await prefs.setInt(key, level);
    final client = _client;
    final user = client?.auth.currentUser;
    if (client != null && user != null) {
      try {
        await client.from('learner_game_progress').upsert({
          'user_id': user.id,
          'profile_key': profileKey,
          'game_slug': kind.name,
          'highest_level': level,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        }, onConflict: 'user_id,profile_key,game_slug');
      } catch (_) {
        // A later session retries syncing this level from local preferences.
      }
    }
    return level;
  }

  Future<bool> resetProfileProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('reset-pending:$profileKey', true);
    final client = _client;
    final user = client?.auth.currentUser;
    var synced = false;
    if (client != null && user != null) {
      try {
        await _deleteRemoteProgress(client, user.id);
        await prefs.remove('reset-pending:$profileKey');
        synced = true;
      } catch (_) {
        // The reset tombstone retries cloud deletion when this profile returns.
      }
    }
    for (final key in prefs.getKeys().where(
      (key) =>
          key.startsWith('done:$profileKey:') ||
          key.startsWith('answers:$profileKey:') ||
          key.startsWith('game-level:$profileKey:'),
    )) {
      await prefs.remove(key);
    }
    if (prefs.getString('legacy_progress_owner')?.toLowerCase() == profileKey) {
      await prefs.remove('done:original-a1-starter');
      await prefs.setString('legacy_progress_owner', profileKey);
    }
    return synced;
  }

  Future<bool> syncPendingProgressReset() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool('reset-pending:$profileKey') != true) return true;
    final client = _client;
    final user = client?.auth.currentUser;
    if (client == null || user == null) return false;
    try {
      await _deleteRemoteProgress(client, user.id);
      await prefs.remove('reset-pending:$profileKey');
      return true;
    } catch (_) {
      // Retry the tombstone at the next profile session.
      return false;
    }
  }

  Future<void> _deleteRemoteProgress(
    SupabaseClient client,
    String userId,
  ) async {
    for (final table in [
      'learner_activity_progress',
      'learner_answers',
      'learner_game_progress',
    ]) {
      await client
          .from(table)
          .delete()
          .eq('user_id', userId)
          .eq('profile_key', profileKey);
    }
  }

  Future<Set<String>> flagged(Curriculum curriculum) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs
            .getStringList('flagged:$profileKey:${curriculum.slug}')
            ?.toSet() ??
        <String>{};
  }

  Future<bool> flag(Curriculum curriculum, Activity activity) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'flagged:$profileKey:${curriculum.slug}';
    final local = prefs.getStringList(key) ?? <String>[];
    if (!local.contains(activity.slug)) {
      local.add(activity.slug);
      await prefs.setStringList(key, local);
    }
    final client = _client;
    if (client == null) return false;
    try {
      await client
          .from('learning_content_flags')
          .upsert(
            {'book_slug': curriculum.slug, 'activity_slug': activity.slug},
            onConflict: 'book_slug,activity_slug',
            ignoreDuplicates: true,
          );
      return true;
    } catch (_) {
      // Keep the local flag if network access or the review table is unavailable.
      return false;
    }
  }

  Future<bool> complete(
    Curriculum curriculum,
    Activity activity,
    Set<String> done,
    int? selectedAnswer, {
    bool answerSynced = true,
  }) async {
    final client = _client;
    final prefs = await SharedPreferences.getInstance();
    if (selectedAnswer != null &&
        selectedAnswer != activity.payload['answer']) {
      return false;
    }
    done.add(activity.slug);
    await prefs.setStringList(
      'done:$profileKey:${curriculum.slug}',
      done.toList(),
    );
    if (answerSynced && client != null && client.auth.currentUser != null) {
      try {
        final userId = client.auth.currentUser!.id;
        await client.from('learner_activity_progress').upsert({
          'user_id': userId,
          'profile_key': profileKey,
          'book_slug': curriculum.slug,
          'activity_slug': activity.slug,
          'completed_at': DateTime.now().toUtc().toIso8601String(),
        }, onConflict: 'user_id,profile_key,book_slug,activity_slug');
      } catch (_) {
        // A later session retries syncing local completion records.
      }
    }
    return true;
  }

  Future<bool> recordAnswer(
    Curriculum curriculum,
    Activity activity,
    int answer,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'answers:$profileKey:${curriculum.slug}';
    final attempts = prefs.getStringList(key) ?? <String>[];
    attempts.add(
      jsonEncode({
        'attempt_key':
            '${DateTime.now().microsecondsSinceEpoch}-'
            '${Random.secure().nextInt(1 << 32)}',
        'activity_slug': activity.slug,
        'selected_answer': answer,
        'is_correct': answer == activity.payload['answer'],
        'answered_at': DateTime.now().toUtc().toIso8601String(),
      }),
    );
    await prefs.setStringList(key, attempts);
    final client = _client;
    final user = client?.auth.currentUser;
    if (client == null || user == null) return false;
    try {
      await _syncAnswers(curriculum, prefs, client, user.id);
      return true;
    } catch (_) {
      // Attempts stay queued on device until the next connected session.
      return false;
    }
  }

  Future<void> _syncAnswers(
    Curriculum curriculum,
    SharedPreferences prefs,
    SupabaseClient client,
    String userId,
  ) async {
    final key = 'answers:$profileKey:${curriculum.slug}';
    final attempts = prefs.getStringList(key) ?? <String>[];
    final pending = <Map<String, dynamic>>[];
    var changed = false;
    for (var i = 0; i < attempts.length; i++) {
      final attempt = jsonDecode(attempts[i]) as Map<String, dynamic>;
      if (attempt['attempt_key'] == null) {
        attempt['attempt_key'] =
            '$userId:legacy:$profileKey:'
            '${curriculum.slug}:$i';
        attempts[i] = jsonEncode(attempt);
        changed = true;
      }
      pending.add({
        'user_id': userId,
        'profile_key': profileKey,
        'book_slug': curriculum.slug,
        'activity_slug': attempt['activity_slug'],
        'selected_answer': attempt['selected_answer'],
        'is_correct': attempt['is_correct'],
        'answered_at': attempt['answered_at'],
        'attempt_key': attempt['attempt_key'],
      });
    }
    if (changed) await prefs.setStringList(key, attempts);
    for (var offset = 0; offset < pending.length; offset += 100) {
      await client
          .from('learner_answers')
          .upsert(
            pending.skip(offset).take(100).toList(),
            onConflict: 'attempt_key',
            ignoreDuplicates: true,
          );
    }
  }

  Future<List<Map<String, dynamic>>> profilePoints() async {
    final client = _client;
    if (client == null) return [];
    final user = client.auth.currentUser;
    if (user == null) return [];
    try {
      final rows = await client
          .from('learner_profile_points')
          .select(
            'profile_key,language_level,lifetime_points,current_month_points',
          )
          .eq('user_id', user.id);
      return rows;
    } catch (_) {
      return [];
    }
  }
}

class LearningApp extends StatelessWidget {
  const LearningApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ich schaffe das',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF10182A),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFF5C85B),
          brightness: Brightness.dark,
        ),
        textTheme: ThemeData.dark().textTheme.apply(fontFamily: 'Arial'),
      ),
      home: const AuthGate(),
    );
  }
}

class _HomeSection extends StatelessWidget {
  const _HomeSection({
    required this.title,
    required this.icon,
    required this.subtitle,
    required this.child,
  });
  final String title;
  final IconData icon;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: const Color(0xFF1D2940),
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: Colors.white10),
    ),
    child: Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        leading: Icon(icon, color: const Color(0xFFF5C85B)),
        title: Text(
          title,
          style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800),
        ),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.white60)),
        tilePadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
        childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
        children: [child],
      ),
    ),
  );
}

class _GamePreview extends StatelessWidget {
  const _GamePreview({required this.kind});
  final MiniGameKind kind;

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Icon(kind.icon, color: Colors.white70, size: 19),
      const SizedBox(width: 9),
      Expanded(
        child: Text(
          kind.title,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      const Text('20 levels', style: TextStyle(color: Colors.white54)),
    ],
  );
}

class LearningScreen extends StatefulWidget {
  const LearningScreen({
    super.key,
    required this.courseAsset,
    required this.bookSlug,
    required this.profileKey,
    required this.profileName,
    required this.keywords,
    required this.includeReels,
    required this.includeGames,
    this.onCourseCompleted,
    this.onSettingsChanged,
    this.startAtActivity = false,
  });

  final String courseAsset;
  final String bookSlug;
  final String profileKey;
  final String profileName;
  final VoidCallback? onCourseCompleted;
  final VoidCallback? onSettingsChanged;
  final List<String> keywords;
  final bool includeReels;
  final bool includeGames;
  final bool startAtActivity;

  @override
  State<LearningScreen> createState() => _LearningScreenState();
}

class _LearningScreenState extends State<LearningScreen> {
  late final LearningStore _store;
  final _controller = PageController();
  Curriculum? _curriculum;
  Lexicon? _lexicon;
  List<YoutubeShort> _shorts = [];
  List<FeedSlot> _feed = [];
  final Map<MiniGameKind, int> _gameProgress = {};
  final Map<int, int> _completedGameSlots = {};
  Set<String> _done = {};
  Set<String> _flagged = {};
  int _index = 0;
  int _feedIndex = 0;
  int? _selected;
  DateTime? _correctSelectedAt;
  Future<bool>? _answerWrite;
  bool _busy = false;
  Offset? _swipeStart;
  int? _activityDragIndex;
  double _activityDragOffset = 0;
  bool _activityDragging = false;
  String? _bottomHint;
  Timer? _bottomHintTimer;
  String? _error;
  int _nativeMaxFeedIndex = 0;
  DateTime? _lastShortSwipeAt;
  String? _shortDragSource;
  double _shortDragStartPixels = 0;
  int _shortDragStartIndex = 0;

  @override
  void initState() {
    super.initState();
    _store = LearningStore(
      widget.courseAsset,
      widget.bookSlug,
      widget.profileKey,
    );
    if (Platform.isIOS) {
      _shortSwipeChannel.setMethodCallHandler((call) async {
        if (call.method != 'shortDrag' ||
            !mounted ||
            _feed.isEmpty ||
            !_feed[_feedIndex].isShort ||
            call.arguments is! Map) {
          return;
        }
        final args = call.arguments as Map;
        final distance = (args['translation'] as num?)?.toDouble() ?? 0;
        final velocity = (args['velocity'] as num?)?.toDouble() ?? 0;
        switch (args['phase']) {
          case 'start':
            _beginShortDrag('native', distance);
            break;
          case 'update':
            _updateShortDrag('native', distance);
            break;
          case 'end':
            await _endShortDrag('native', distance, velocity);
            break;
          case 'cancel':
            await _endShortDrag('native', 0, 0);
            break;
        }
      });
    }
    _load();
  }

  Future<void> _setNativeShortSwipe(bool enabled) async {
    if (!Platform.isIOS) return;
    try {
      await _shortSwipeChannel.invokeMethod<void>('setEnabled', enabled);
    } catch (_) {
      // Other platforms keep Flutter's video-area drag handler.
    }
  }

  void _showBottomHint(String message) {
    _bottomHintTimer?.cancel();
    setState(() => _bottomHint = message);
    _bottomHintTimer = Timer(const Duration(milliseconds: 1150), () {
      if (mounted) setState(() => _bottomHint = null);
    });
  }

  void _releaseActivityDrag() {
    if (!_activityDragging && _activityDragOffset == 0) return;
    setState(() {
      _activityDragging = false;
      _activityDragOffset = 0;
    });
  }

  Future<void> _load() async {
    try {
      final curriculum = await _store.load();
      final lexicon = await _store.loadLexicon();
      if (curriculum.activities.isEmpty) {
        throw StateError('This book has no published activities yet.');
      }
      final done = await _store.completed(curriculum);
      final flagged = await _store.flagged(curriculum);
      var index = curriculum.activities.indexWhere(
        (a) => !done.contains(a.slug),
      );
      if (index < 0) index = curriculum.activities.length - 1;
      final searchTerms = widget.includeReels
          ? (widget.keywords.isEmpty
                ? parseInterestKeywords(_starterReelKeywords)
                : widget.keywords)
          : <String>[];
      var shorts = widget.includeReels
          ? await searchSessionShorts(searchTerms)
          : <YoutubeShort>[];
      if (widget.includeReels && shorts.isEmpty) {
        shorts = await loadShortsCatalog(searchTerms);
      }
      final gameProgress = widget.includeGames
          ? await _store.gameProgress()
          : <MiniGameKind, int>{};
      final feed = planSessionFeed(
        firstUnfinishedActivity: index,
        activityCount: curriculum.activities.length,
        availableShorts: shorts.length,
        lessonNumbers: curriculum.activities
            .map((a) => a.lessonNumber)
            .toList(),
        reelsEnabled: widget.includeReels,
        gamesEnabled: widget.includeGames,
        randomSeed: DateTime.now().microsecondsSinceEpoch,
      );
      final resumeFeedIndex = widget.startAtActivity
          ? feed.indexWhere((slot) => slot.activityIndex == index)
          : 0;
      if (!mounted) return;
      setState(() {
        _curriculum = curriculum;
        _lexicon = lexicon;
        _shorts = shorts;
        _feed = feed;
        _gameProgress
          ..clear()
          ..addAll(gameProgress);
        _completedGameSlots.clear();
        _done = done;
        _flagged = flagged;
        _index = index;
        _feedIndex = max(0, resumeFeedIndex);
      });
      await _setNativeShortSwipe(_feed[_feedIndex].isShort);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_controller.hasClients) {
          _controller.jumpToPage(max(0, resumeFeedIndex));
        }
      });
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    }
  }

  Future<void> _complete(Activity activity, {bool autoCorrect = false}) async {
    final curriculum = _curriculum!;
    final selected = _selected;
    if (activity.kind == 'quiz' &&
        selected == null &&
        !_done.contains(activity.slug)) {
      _showBottomHint('Choose an answer before continuing.');
      return;
    }
    if (_busy) return;
    final startingFeedIndex = _feedIndex;
    setState(() => _busy = true);
    try {
      final answerSynced = activity.kind == 'quiz'
          ? await (_answerWrite ?? Future<bool>.value(false))
          : true;
      final passed = await _store.complete(
        curriculum,
        activity,
        _done,
        selected,
        answerSynced: answerSynced,
      );
      if (!mounted) return;
      if (!passed) {
        _showBottomHint('Try another answer to unlock the next card.');
        return;
      }
      if (autoCorrect) {
        final selectedAt = _correctSelectedAt ?? DateTime.now();
        final remaining =
            const Duration(milliseconds: 500) -
            DateTime.now().difference(selectedAt);
        if (remaining > Duration.zero) await Future.delayed(remaining);
        if (!mounted || _feedIndex != startingFeedIndex) return;
        setState(() {
          _activityDragIndex = startingFeedIndex;
          _activityDragging = false;
          _activityDragOffset = 30;
        });
        await Future.delayed(const Duration(milliseconds: 160));
        if (!mounted) return;
      }
      if (widget.bookSlug == 'original-a1-starter' &&
          _done.length >= curriculum.activities.length) {
        widget.onCourseCompleted?.call();
        return;
      }
      setState(() {});
      if (_feedIndex < _feed.length - 1) {
        await _controller.nextPage(
          duration: Duration(milliseconds: autoCorrect ? 420 : 330),
          curve: autoCorrect ? Curves.easeInCubic : Curves.easeOutCubic,
        );
      }
      if (mounted) {
        setState(() {
          _selected = null;
          _correctSelectedAt = null;
          _answerWrite = null;
          _activityDragOffset = 0;
          _activityDragIndex = null;
        });
      }
    } catch (error) {
      if (mounted) {
        _showBottomHint('Could not save progress: $error');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _flag(Activity activity) async {
    if (_flagged.contains(activity.slug)) return;
    setState(() {
      _flagged.add(activity.slug);
    });
    final synced = await _store.flag(_curriculum!, activity);
    if (mounted) {
      _showBottomHint(
        synced
            ? 'Flagged for review.'
            : 'Saved on this device; could not sync the review flag.',
      );
    }
  }

  Future<void> _saveGameProgress(MiniGameKind kind, int completedLevel) async {
    final unlocked = min(20, completedLevel + 1).toInt();
    final current = _gameProgress[kind] ?? 1;
    if (unlocked <= current) return;
    final saved = await _store.saveGameProgress(kind, unlocked);
    if (mounted) setState(() => _gameProgress[kind] = saved);
  }

  void _navigateFeed(int direction, int maxFeedIndex) {
    if (!_controller.hasClients) return;
    final target = (_feedIndex + direction).clamp(0, maxFeedIndex).toInt();
    if (target == _feedIndex) return;
    _controller.animateToPage(
      target,
      duration: const Duration(milliseconds: 330),
      curve: Curves.easeOutCubic,
    );
  }

  void _handleShortSwipe(int direction, int maxFeedIndex) {
    final now = DateTime.now();
    final last = _lastShortSwipeAt;
    if (last != null && now.difference(last).inMilliseconds < 500) return;
    _lastShortSwipeAt = now;
    _navigateFeed(direction, maxFeedIndex);
  }

  void _beginShortDrag(String source, double distance) {
    if (!_controller.hasClients ||
        _feed.isEmpty ||
        !_feed[_feedIndex].isShort) {
      return;
    }
    if (_shortDragSource != null) {
      // Native UIKit touches take over if the WebView and Flutter both see a pan.
      if (source != 'native' || _shortDragSource == 'native') return;
    } else {
      _shortDragStartIndex = _feedIndex;
    }
    _shortDragSource = source;
    _shortDragStartPixels = _controller.position.pixels + distance;
  }

  void _updateShortDrag(String source, double distance) {
    if (_shortDragSource == null) _beginShortDrag(source, distance);
    if (_shortDragSource != source || !_controller.hasClients) return;
    final position = _controller.position;
    final lower = max(
      position.minScrollExtent,
      _shortDragStartPixels - position.viewportDimension,
    );
    final upper = min(
      position.maxScrollExtent,
      _shortDragStartPixels + position.viewportDimension,
    );
    _controller.jumpTo(
      (_shortDragStartPixels - distance).clamp(lower, upper).toDouble(),
    );
  }

  Future<void> _endShortDrag(
    String source,
    double distance,
    double velocity,
  ) async {
    if (_shortDragSource != source) return;
    _shortDragSource = null;
    if (!_controller.hasClients) return;
    final direction = distance < -55 || velocity < -600
        ? 1
        : distance > 55 || velocity > 600
        ? -1
        : 0;
    final target = (_shortDragStartIndex + direction)
        .clamp(0, _nativeMaxFeedIndex)
        .toInt();
    await _controller.animateToPage(
      target,
      duration: const Duration(milliseconds: 240),
      curve: Curves.easeOutCubic,
    );
    if (!mounted) return;
    _setCurrentFeedIndex(target);
  }

  void _setCurrentFeedIndex(int index) {
    if (!mounted || index < 0 || index >= _feed.length) return;
    setState(() {
      _feedIndex = index;
      final activityIndex = _feed[index].activityIndex;
      if (activityIndex != null) {
        _index = activityIndex;
        _selected = null;
        _correctSelectedAt = null;
        _answerWrite = null;
      }
    });
    _setNativeShortSwipe(_feed[index].isShort);
  }

  Future<void> _openSettings() async {
    await _setNativeShortSwipe(false);
    if (!mounted) return;
    final result = await Navigator.of(context).push<_LearningSettingsResult>(
      MaterialPageRoute(
        builder: (_) => _LearningSettingsScreen(
          accountId: widget.profileKey,
          accountName: widget.profileName,
          keywords: widget.keywords.join(', '),
          reelsEnabled: widget.includeReels,
          gamesEnabled: widget.includeGames,
        ),
      ),
    );
    if (!mounted) return;
    await _setNativeShortSwipe(_feed.isNotEmpty && _feed[_feedIndex].isShort);
    if (result == null) return;
    widget.onSettingsChanged?.call();
  }

  @override
  void dispose() {
    _bottomHintTimer?.cancel();
    if (Platform.isIOS) {
      _shortSwipeChannel.setMethodCallHandler(null);
      _setNativeShortSwipe(false);
    }
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.cloud_off, size: 48),
                  const SizedBox(height: 18),
                  const Text(
                    'Could not load the course',
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  Text(_error!, textAlign: TextAlign.center),
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: () {
                      setState(() => _error = null);
                      _load();
                    },
                    child: const Text('Try again'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }
    final curriculum = _curriculum;
    if (curriculum == null || _lexicon == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final activities = curriculum.activities;
    final current = activities[_index];
    final unlockIndex = activities.indexWhere((a) => !_done.contains(a.slug));
    final maxIndex = unlockIndex < 0 ? activities.length - 1 : unlockIndex;
    final frontier = unlockIndex < 0
        ? _feed.length - 1
        : _feed.indexWhere((slot) => slot.activityIndex == maxIndex);
    final maxFeedIndex = frontier < 0 ? _feed.length - 1 : frontier;
    _nativeMaxFeedIndex = maxFeedIndex;
    final atLearningFrontier =
        _feedIndex == maxFeedIndex &&
        _feed[_feedIndex].activityIndex == maxIndex &&
        !_done.contains(activities[maxIndex].slug);
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: Listener(
                onPointerDown: (event) {
                  _swipeStart = event.position;
                  if (atLearningFrontier) {
                    _activityDragIndex = _feedIndex;
                  }
                },
                onPointerMove: (event) {
                  final start = _swipeStart;
                  if (start == null || !atLearningFrontier || _busy) return;
                  final upwardDistance = start.dy - event.position.dy;
                  if (upwardDistance <= 0 && !_activityDragging) return;
                  final offset =
                      -min(96.0, max(0.0, upwardDistance * 0.55));
                  if (offset == _activityDragOffset) return;
                  setState(() {
                    _activityDragging = true;
                    _activityDragOffset = offset;
                  });
                },
                onPointerCancel: (_) {
                  _swipeStart = null;
                  _releaseActivityDrag();
                },
                onPointerUp: (event) {
                  final start = _swipeStart;
                  _swipeStart = null;
                  _releaseActivityDrag();
                  if (start != null &&
                      atLearningFrontier &&
                      !_busy &&
                      start.dy - event.position.dy > 56) {
                    _complete(activities[_index]);
                  }
                },
                child: PageView.builder(
                  controller: _controller,
                  scrollDirection: Axis.vertical,
                  physics: _feed[_feedIndex].isShort || _feed[_feedIndex].isGame
                      ? const NeverScrollableScrollPhysics()
                      : const ClampingScrollPhysics(),
                  itemCount: maxFeedIndex + 1,
                  onPageChanged: (index) {
                    if (_shortDragSource != null) return;
                    if (index > maxFeedIndex) {
                      _controller.animateToPage(
                        maxFeedIndex,
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOut,
                      );
                      return;
                    }
                    _setCurrentFeedIndex(index);
                  },
                  itemBuilder: (context, index) {
                    final slot = _feed[index];
                    if (slot.isShort) {
                      final video = _shorts[slot.shortIndex! % _shorts.length];
                      return _ShortsCard(
                        key: ValueKey('short-$index-${video.id}'),
                        video: video,
                        active: index == _feedIndex,
                        onDragStart: () => _beginShortDrag('flutter', 0),
                        onDragUpdate: (distance) =>
                            _updateShortDrag('flutter', distance),
                        onDragEnd: (distance, velocity) =>
                            _endShortDrag('flutter', distance, velocity),
                        onNext: () => _handleShortSwipe(1, maxFeedIndex),
                      );
                    }
                    if (slot.isGame) {
                      final kind = slot.game!;
                      final startLevel = _gameProgress[kind] ?? 1;
                      return GameBreakCard(
                        key: ValueKey('game-$index-${kind.name}'),
                        kind: kind,
                        startLevel: startLevel,
                        completedLevel: _completedGameSlots[index],
                        onLevelCompleted: (level) {
                          setState(() => _completedGameSlots[index] = level);
                          _saveGameProgress(kind, level);
                        },
                        onPreviousCard: () => _navigateFeed(-1, maxFeedIndex),
                        onNextCard: () => _navigateFeed(1, maxFeedIndex),
                      );
                    }
                    final activity = activities[slot.activityIndex!];
                    final card = _ActivityCard(
                      activity: activity,
                      lexicon: _lexicon!,
                      flagged: _flagged.contains(activity.slug),
                      onFlag: () => _flag(activity),
                      selected: index == _feedIndex ? _selected : null,
                      completed: _done.contains(activity.slug),
                      busy: _busy,
                      onSelect: (value) {
                        if (_busy ||
                            _done.contains(activity.slug) ||
                            _selected == value ||
                            _selected == activity.payload['answer']) {
                          return;
                        }
                        setState(() => _selected = value);
                        final previous = _answerWrite;
                        _answerWrite = () async {
                          if (previous != null) await previous;
                          return _store.recordAnswer(
                            curriculum,
                            activity,
                            value,
                          );
                        }();
                        if (value == activity.payload['answer']) {
                          _correctSelectedAt = DateTime.now();
                          _complete(activity, autoCorrect: true);
                        }
                      },
                    );
                    if (index != _activityDragIndex) return card;
                    return AnimatedContainer(
                      duration: _activityDragging
                          ? Duration.zero
                          : const Duration(milliseconds: 170),
                      curve: Curves.easeOutBack,
                      transform: Matrix4.translationValues(
                        0,
                        _activityDragOffset,
                        0,
                      ),
                      child: card,
                    );
                  },
                ),
              ),
            ),
            Positioned(
              top: 8,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 13,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF10182A).withValues(alpha: 0.92),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white12),
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.sizeOf(context).width - 82,
                  ),
                  child: Text(
                    'LESSON ${current.lessonNumber}  ·  '
                    'CARD ${current.cardNumber}/${current.lessonCardCount}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFFF5C85B),
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 8,
              right: 14,
              child: _FloatingControl(
                size: 42,
                onTap: _openSettings,
                child: Text(
                  widget.profileName.trim().isEmpty
                      ? '?'
                      : widget.profileName.trim().substring(0, 1).toUpperCase(),
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFFF5C85B),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 62,
              left: 20,
              right: 20,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: LinearProgressIndicator(
                  value: _done.length / activities.length,
                  minHeight: 4,
                  backgroundColor: Colors.white24,
                  color: const Color(0xFFF5C85B),
                ),
              ),
            ),
            Positioned(
              left: 24,
              right: 24,
              bottom: 22,
              child: IgnorePointer(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 190),
                  transitionBuilder: (child, animation) => SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.25),
                      end: Offset.zero,
                    ).animate(animation),
                    child: FadeTransition(opacity: animation, child: child),
                  ),
                  child: _bottomHint == null
                      ? const SizedBox.shrink(key: ValueKey('hint-empty'))
                      : Container(
                          key: ValueKey(_bottomHint),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 18,
                            vertical: 15,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF5C85B),
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black38,
                                blurRadius: 18,
                                offset: Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Text(
                            _bottomHint!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Color(0xFF172034),
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FloatingControl extends StatelessWidget {
  const _FloatingControl({required this.child, this.onTap, this.size = 40});

  final Widget child;
  final VoidCallback? onTap;
  final double size;

  @override
  Widget build(BuildContext context) => Material(
    color: const Color(0xFF10182A).withValues(alpha: 0.92),
    shape: const CircleBorder(side: BorderSide(color: Colors.white12)),
    child: InkWell(
      customBorder: const CircleBorder(),
      onTap: onTap,
      child: SizedBox(
        width: size,
        height: size,
        child: Center(child: child),
      ),
    ),
  );
}

class _LearningSettingsResult {
  const _LearningSettingsResult();
}

class _LearningSettingsScreen extends StatefulWidget {
  const _LearningSettingsScreen({
    required this.accountId,
    required this.accountName,
    required this.keywords,
    required this.reelsEnabled,
    required this.gamesEnabled,
  });
  final String accountId;
  final String accountName;
  final String keywords;
  final bool reelsEnabled;
  final bool gamesEnabled;

  @override
  State<_LearningSettingsScreen> createState() =>
      _LearningSettingsScreenState();
}

class _LearningSettingsScreenState extends State<_LearningSettingsScreen> {
  late final TextEditingController _keywords;
  late bool _reelsEnabled;
  late bool _gamesEnabled;
  List<Map<String, dynamic>> _scores = [];
  List<Map<String, dynamic>> _leaders = [];

  @override
  void initState() {
    super.initState();
    _keywords = TextEditingController(text: widget.keywords);
    _reelsEnabled = widget.reelsEnabled;
    _gamesEnabled = widget.gamesEnabled;
    _load();
  }

  Future<void> _load() async {
    final scores = await LearningStore(
      '',
      '',
      widget.accountId,
    ).profilePoints();
    if (mounted) setState(() => _scores = scores);
    try {
      final leaders = await Supabase.instance.client.rpc('monthly_leaderboard');
      if (mounted) {
        setState(
          () => _leaders = (leaders as List).cast<Map<String, dynamic>>(),
        );
      }
    } catch (_) {
      // The account's own points remain available if ranking is offline.
    }
  }

  int _points(String column) => _scores.fold(
    0,
    (sum, row) => sum + ((row[column] as num?)?.toInt() ?? 0),
  );

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final key = widget.accountId;
    await prefs.setString('keywords:$key', _keywords.text);
    await prefs.setBool('reels:$key', _reelsEnabled);
    await prefs.setBool('games:$key', _gamesEnabled);
  }

  Future<void> _close() async {
    await _saveSettings();
    if (mounted) Navigator.of(context).pop(const _LearningSettingsResult());
  }

  Future<void> _signOut() async {
    await Supabase.instance.client.auth.signOut();
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _keywords.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    final now = DateTime.now();
    final email = Supabase.instance.client.auth.currentUser?.email;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _close();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Your settings'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded),
            tooltip: 'Back to course',
            onPressed: _close,
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(
              '${months[now.month - 1]} ${now.year} leaders',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 12),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF1D2940),
                borderRadius: BorderRadius.circular(20),
              ),
              child: _leaders.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.all(18),
                      child: Text('No points earned this month yet.'),
                    )
                  : Column(
                      children: [
                        for (final leader in _leaders)
                          ListTile(
                            leading: CircleAvatar(
                              child: Text('${leader['rank']}'),
                            ),
                            title: Text(leader['label'] as String),
                            trailing: Text(
                              '${leader['points']} pts',
                              style: const TextStyle(
                                color: Color(0xFFF5C85B),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                      ],
                    ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFF1D2940),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.accountName,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (email != null)
                    Text(email, style: const TextStyle(color: Colors.white60)),
                  const SizedBox(height: 10),
                  Text('This month: ${_points('current_month_points')} points'),
                  Text('Lifetime: ${_points('lifetime_points')} points'),
                  for (final row in _scores)
                    Text(
                      '${row['language_level']}: ${row['lifetime_points']} lifetime · '
                      '${row['current_month_points']} this month',
                    ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _HomeSection(
              title: 'YouTube',
              icon: Icons.smart_display_rounded,
              subtitle: 'Shorts between cards',
              child: Column(
                children: [
                  TextField(
                    controller: _keywords,
                    decoration: const InputDecoration(
                      labelText: 'Reels keywords',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Include YouTube Shorts'),
                    value: _reelsEnabled,
                    onChanged: (value) => setState(() => _reelsEnabled = value),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _HomeSection(
              title: 'Games',
              icon: Icons.sports_esports_rounded,
              subtitle: 'Puzzles between cards',
              child: Column(
                children: [
                  const _GamePreview(kind: MiniGameKind.planks),
                  const SizedBox(height: 8),
                  const _GamePreview(kind: MiniGameKind.lines),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Include games'),
                    value: _gamesEnabled,
                    onChanged: (value) => setState(() => _gamesEnabled = value),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              onPressed: _signOut,
              icon: const Icon(Icons.logout_rounded),
              label: const Text('Sign out'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ShortsCard extends StatefulWidget {
  const _ShortsCard({
    super.key,
    required this.video,
    required this.active,
    required this.onDragStart,
    required this.onDragUpdate,
    required this.onDragEnd,
    required this.onNext,
  });

  final YoutubeShort video;
  final bool active;
  final VoidCallback onDragStart;
  final ValueChanged<double> onDragUpdate;
  final void Function(double distance, double velocity) onDragEnd;
  final VoidCallback onNext;

  @override
  State<_ShortsCard> createState() => _ShortsCardState();
}

class _ShortsCardState extends State<_ShortsCard> {
  int? _pointer;
  Offset? _start;
  Offset? _lastPosition;
  Duration? _lastTime;
  double _velocity = 0;
  bool _dragging = false;

  void _clearPointer() {
    _pointer = null;
    _start = null;
    _lastPosition = null;
    _lastTime = null;
    _velocity = 0;
    _dragging = false;
  }

  @override
  Widget build(BuildContext context) => Listener(
    behavior: HitTestBehavior.opaque,
    onPointerDown: (event) {
      if (_pointer != null) return;
      _pointer = event.pointer;
      _start = event.position;
      _lastPosition = event.position;
      _lastTime = event.timeStamp;
    },
    onPointerMove: (event) {
      final start = _start;
      if (event.pointer != _pointer || start == null) return;
      final delta = event.position - start;
      if (!_dragging && delta.dy.abs() > 7 && delta.dy.abs() > delta.dx.abs()) {
        _dragging = true;
        widget.onDragStart();
      }
      final lastPosition = _lastPosition;
      final lastTime = _lastTime;
      if (lastPosition != null && lastTime != null) {
        final elapsed = (event.timeStamp - lastTime).inMicroseconds;
        if (elapsed > 0) {
          _velocity = (event.position.dy - lastPosition.dy) * 1000000 / elapsed;
        }
      }
      _lastPosition = event.position;
      _lastTime = event.timeStamp;
      if (_dragging) widget.onDragUpdate(delta.dy);
    },
    onPointerUp: (event) {
      if (event.pointer != _pointer) return;
      if (_dragging) {
        widget.onDragEnd(event.position.dy - _start!.dy, _velocity);
      }
      _clearPointer();
    },
    onPointerCancel: (event) {
      if (event.pointer != _pointer) return;
      if (_dragging) widget.onDragEnd(0, 0);
      _clearPointer();
    },
    child: Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1D2940),
        borderRadius: BorderRadius.circular(26),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(26),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 94, 12, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: widget.active
                      ? _EmbeddedShort(videoId: widget.video.id)
                      : const Center(
                          child: Icon(
                            Icons.smart_display_rounded,
                            size: 72,
                            color: Colors.white38,
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${widget.video.title} · ${widget.video.channel}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: widget.onNext,
                    tooltip: 'Next card',
                    icon: const Icon(Icons.arrow_upward_rounded),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

class _EmbeddedShort extends StatefulWidget {
  const _EmbeddedShort({required this.videoId});
  final String videoId;

  @override
  State<_EmbeddedShort> createState() => _EmbeddedShortState();
}

class _EmbeddedShortState extends State<_EmbeddedShort> {
  late final YoutubePlayerController _player;

  Future<void> _playWithSound() async {
    await _player.unMute();
    await _player.playVideo();
  }

  @override
  void initState() {
    super.initState();
    _player = YoutubePlayerController.fromVideoId(
      videoId: widget.videoId,
      autoPlay: true,
      params: const YoutubePlayerParams(
        mute: false,
        showControls: false,
        showFullscreenButton: false,
        playsInline: true,
      ),
    );
  }

  @override
  void dispose() {
    _player.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Stack(
    children: [
      Positioned.fill(
        child: IgnorePointer(
          child: YoutubePlayer(
            controller: _player,
            aspectRatio: 9 / 16,
            autoFullScreen: false,
            enableFullScreenOnVerticalDrag: false,
          ),
        ),
      ),
      // The touch surface keeps video taps inline; the card's raw pointer
      // listener and the iOS window pan both see vertical movement.
      Positioned.fill(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _playWithSound,
        ),
      ),
      Positioned(
        right: 8,
        bottom: 8,
        child: IconButton.filled(
          tooltip: 'Turn on sound',
          icon: const Icon(Icons.volume_up_rounded),
          onPressed: _playWithSound,
        ),
      ),
    ],
  );
}

class _ActivityCard extends StatelessWidget {
  const _ActivityCard({
    required this.activity,
    required this.lexicon,
    required this.flagged,
    required this.onFlag,
    required this.selected,
    required this.completed,
    required this.busy,
    required this.onSelect,
  });

  final Activity activity;
  final Lexicon lexicon;
  final bool flagged;
  final VoidCallback onFlag;
  final int? selected;
  final bool completed;
  final bool busy;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final payload = activity.payload;
    final kind = activity.kind;
    final label = switch (kind) {
      'grammar' => 'GRAMMAR',
      'vocabulary' => 'VOCABULARY',
      'quiz' => 'QUICK CHECK',
      _ => kind.toUpperCase(),
    };
    final icon = switch (kind) {
      'grammar' => Icons.menu_book_rounded,
      'vocabulary' => Icons.translate_rounded,
      'quiz' => Icons.psychology_alt_rounded,
      _ => Icons.auto_stories,
    };
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1D2940),
        borderRadius: BorderRadius.circular(26),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(26, 98, 26, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5C85B).withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Icon(icon, color: const Color(0xFFF5C85B)),
                ),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: const TextStyle(
                    color: Color(0xFFF5C85B),
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                if (completed)
                  const Icon(Icons.check_circle, color: Color(0xFF70D6AB)),
                IconButton(
                  tooltip: flagged ? 'Flagged for review' : 'Flag this content',
                  onPressed: flagged ? null : onFlag,
                  icon: Icon(
                    flagged ? Icons.flag_rounded : Icons.outlined_flag,
                    color: flagged ? const Color(0xFFFFB684) : Colors.white70,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            LexicalText(
              activity.title,
              lexicon: lexicon,
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w800,
                height: 1.1,
              ),
            ),
            const SizedBox(height: 22),
            Expanded(
              child: SingleChildScrollView(
                physics: const ClampingScrollPhysics(),
                child: switch (kind) {
                  'grammar' => _GrammarBody(payload: payload, lexicon: lexicon),
                  'vocabulary' => _VocabularyBody(
                    payload: payload,
                    lexicon: lexicon,
                  ),
                  'quiz' => _QuizBody(
                    payload: payload,
                    selected: selected,
                    onSelect: onSelect,
                    lexicon: lexicon,
                  ),
                  _ => LexicalText(
                    payload['body']?.toString() ?? '',
                    lexicon: lexicon,
                  ),
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GrammarBody extends StatelessWidget {
  const _GrammarBody({required this.payload, required this.lexicon});
  final Map<String, dynamic> payload;
  final Lexicon lexicon;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      LexicalText(
        payload['body']?.toString() ?? '',
        lexicon: lexicon,
        style: const TextStyle(fontSize: 18, height: 1.55),
      ),
      if (payload['example'] != null) ...[
        const SizedBox(height: 25),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.07),
            borderRadius: BorderRadius.circular(17),
          ),
          child: LexicalText(
            payload['example'].toString(),
            lexicon: lexicon,
            style: const TextStyle(fontSize: 17, color: Color(0xFFF5C85B)),
          ),
        ),
      ],
    ],
  );
}

class _VocabularyBody extends StatelessWidget {
  const _VocabularyBody({required this.payload, required this.lexicon});
  final Map<String, dynamic> payload;
  final Lexicon lexicon;

  @override
  Widget build(BuildContext context) {
    final items = payload['items'] as List<dynamic>? ?? [];
    return Column(
      children: items.map((entry) {
        final item = entry as Map<String, dynamic>;
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: LexicalText(
                      item['de'].toString(),
                      lexicon: lexicon,
                      style: const TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Text(
                    item['en'].toString(),
                    style: const TextStyle(color: Color(0xFFF5C85B)),
                  ),
                ],
              ),
              const SizedBox(height: 7),
              LexicalText(
                item['example'].toString(),
                lexicon: lexicon,
                style: const TextStyle(color: Colors.white60),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _QuizBody extends StatelessWidget {
  const _QuizBody({
    required this.payload,
    required this.selected,
    required this.onSelect,
    required this.lexicon,
  });
  final Map<String, dynamic> payload;
  final int? selected;
  final ValueChanged<int> onSelect;
  final Lexicon lexicon;

  @override
  Widget build(BuildContext context) {
    final options = payload['options'] as List<dynamic>? ?? [];
    final correct = payload['answer'] as int;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        LexicalText(
          payload['question'].toString(),
          lexicon: lexicon,
          style: const TextStyle(fontSize: 20, height: 1.4),
        ),
        const SizedBox(height: 20),
        for (var i = 0; i < options.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              onTap: () => onSelect(i),
              borderRadius: BorderRadius.circular(15),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(17),
                decoration: BoxDecoration(
                  color: selected == i
                      ? const Color(0xFFF5C85B).withValues(alpha: 0.18)
                      : Colors.white.withValues(alpha: 0.06),
                  border: Border.all(
                    color: selected == i
                        ? const Color(0xFFF5C85B)
                        : Colors.white12,
                  ),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: LexicalText(
                  options[i].toString(),
                  lexicon: lexicon,
                  style: const TextStyle(fontSize: 17),
                ),
              ),
            ),
          ),
        if (selected != null) ...[
          const SizedBox(height: 13),
          Text(
            selected == correct
                ? 'Correct! ✓'
                : 'Not quite. Correct: ${options[correct]}',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
              color: selected == correct
                  ? const Color(0xFF70D6AB)
                  : const Color(0xFFFFB684),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            payload['explanation']?.toString() ?? '',
            style: const TextStyle(color: Colors.white70),
          ),
        ],
      ],
    );
  }
}
